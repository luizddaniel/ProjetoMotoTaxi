package edu.univas.projeto.tcc.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.controller.ConnectionBanco;

public class MotoqueiroDAO {

	public void cadastrarMotoqueiro(MotoqueiroTO motoqueiroTO)
			throws DAOException {
		Connection conn = null;
		PreparedStatement ps = null;

		if (motoqueiroTO != null) {
			try {
				conn = ConnectionBanco.getConnection();
				String sql = " INSERT INTO motoqueiro (nome, endereco, numero, num_motoq, bairro, cidade, cep, telefone, data, tipo_sang, cpf, rg, cnh, categoria, moto, renavan, ano_modelo, cilindrada, placa, cor) "
						+ " values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";

				ps = conn.prepareStatement(sql);

				ps.setString(1, motoqueiroTO.getNome());
				ps.setString(2, motoqueiroTO.getEndereco());
				ps.setInt(3, motoqueiroTO.getNumero());
				ps.setInt(4, motoqueiroTO.getNumMotoq());
				ps.setString(5, motoqueiroTO.getBairro());
				ps.setString(6, motoqueiroTO.getCidade());
				ps.setString(7, motoqueiroTO.getCep());
				ps.setString(8, motoqueiroTO.getTelefone());
				ps.setDate(9, new Date(motoqueiroTO.getData().getTime()));
				ps.setString(10, motoqueiroTO.getTipoSang());
				ps.setString(11, motoqueiroTO.getCpf());
				ps.setString(12, motoqueiroTO.getRg());
				ps.setString(13, motoqueiroTO.getCnh());
				ps.setString(14, motoqueiroTO.getCategoria());
				ps.setString(15, motoqueiroTO.getMoto());
				ps.setString(16, motoqueiroTO.getRenavan());
				ps.setString(17, motoqueiroTO.getAnoModelo());
				ps.setString(18, motoqueiroTO.getCilindrada());
				ps.setString(19, motoqueiroTO.getPlacaMoto());
				ps.setString(20, motoqueiroTO.getCor());

				ps.executeUpdate();

				ps.close();
			} catch (SQLException e) {
				throw new DAOException(
						"N�o foi poss�vel realizar o cadastro.\nError: "
								+ e.getMessage());
			}

		} else {
			throw new DAOException("N�o h� dados a serem cadastrados.");
		}

	}

	public ArrayList<MotoqueiroTO> listarMotoqueiros() throws DAOException {

		Connection conn = null;
		Statement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<MotoqueiroTO> result = new ArrayList<MotoqueiroTO>();
			conn = ConnectionBanco.getConnection();

			String sql = "SELECT m.id, m.nome, m.num_motoq, m.telefone, m.moto, m.cor, m.placa, m.tipo_sang FROM motoqueiro AS m ORDER BY m.id";
			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql);

			while (rs.next()) {

				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				int numero = rs.getInt("num_motoq");
				String telefone = rs.getString("telefone");
				String moto = rs.getString("moto");
				String cor = rs.getString("cor");
				String placa = rs.getString("placa");
				String tipo_sang = rs.getString("tipo_sang");

				MotoqueiroTO motoqueiro = new MotoqueiroTO();

				motoqueiro.setId(id);
				motoqueiro.setNome(nome);
				motoqueiro.setNumMotoq(numero);
				motoqueiro.setTelefone(telefone);
				motoqueiro.setMoto(moto);
				motoqueiro.setCor(cor);
				motoqueiro.setPlacaMoto(placa);
				motoqueiro.setTipoSang(tipo_sang);

				result.add(motoqueiro);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}

	}

	public ArrayList<MotoqueiroTO> pesquisarMotoqueiro(java.util.Date data,
			String pesq1, String pesq2, Integer pesq3) throws DAOException {

		String comp = "";

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<MotoqueiroTO> result = new ArrayList<MotoqueiroTO>();
			conn = ConnectionBanco.getConnection();

			if (data != null) {
				String sql = "SELECT m.id, m.nome, m.num_motoq, m.telefone, m.moto, m.cor, m.placa, m.tipo_sang FROM motoqueiro m where m.data = ? ";
				sttm = conn.prepareStatement(sql);
				sttm.setTimestamp(1, new Timestamp(data.getTime()));
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					String nome = rs.getString("nome");
					int numero = rs.getInt("num_motoq");
					String telefone = rs.getString("telefone");
					String moto = rs.getString("moto");
					String cor = rs.getString("cor");
					String placa = rs.getString("placa");
					String tipo_sang = rs.getString("tipo_sang");

					MotoqueiroTO motoqueiro = new MotoqueiroTO();

					motoqueiro.setId(id);
					motoqueiro.setNome(nome);
					motoqueiro.setNumMotoq(numero);
					motoqueiro.setTelefone(telefone);
					motoqueiro.setMoto(moto);
					motoqueiro.setCor(cor);
					motoqueiro.setPlacaMoto(placa);
					motoqueiro.setTipoSang(tipo_sang);

					result.add(motoqueiro);

				}

			} else if (!comp.equals(pesq1)) {
				String sql = "SELECT m.id, m.nome, m.num_motoq, m.telefone, m.moto, m.cor, m.placa, m.tipo_sang FROM motoqueiro m where m.moto like '%"
						+ pesq1 + "%'";

				sttm = conn.prepareStatement(sql);
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					String nome = rs.getString("nome");
					int numero = rs.getInt("num_motoq");
					String telefone = rs.getString("telefone");
					String moto = rs.getString("moto");
					String cor = rs.getString("cor");
					String placa = rs.getString("placa");
					String tipo_sang = rs.getString("tipo_sang");

					MotoqueiroTO motoqueiro = new MotoqueiroTO();

					motoqueiro.setId(id);
					motoqueiro.setNome(nome);
					motoqueiro.setNumMotoq(numero);
					motoqueiro.setTelefone(telefone);
					motoqueiro.setMoto(moto);
					motoqueiro.setCor(cor);
					motoqueiro.setPlacaMoto(placa);
					motoqueiro.setTipoSang(tipo_sang);

					result.add(motoqueiro);

				}

			} else if (!comp.equals(pesq2)) {
				String sql = "SELECT m.id, m.nome, m.num_motoq, m.telefone, m.moto, m.cor, m.placa, m.tipo_sang FROM motoqueiro m where m.nome like '%"
						+ pesq2 + "%'";
				sttm = conn.prepareStatement(sql);
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					String nome = rs.getString("nome");
					int numero = rs.getInt("num_motoq");
					String telefone = rs.getString("telefone");
					String moto = rs.getString("moto");
					String cor = rs.getString("cor");
					String placa = rs.getString("placa");
					String tipo_sang = rs.getString("tipo_sang");

					MotoqueiroTO motoqueiro = new MotoqueiroTO();

					motoqueiro.setId(id);
					motoqueiro.setNome(nome);
					motoqueiro.setNumMotoq(numero);
					motoqueiro.setTelefone(telefone);
					motoqueiro.setMoto(moto);
					motoqueiro.setCor(cor);
					motoqueiro.setPlacaMoto(placa);
					motoqueiro.setTipoSang(tipo_sang);

					result.add(motoqueiro);

				}

			} else if (pesq3 != null) {
				String sql = "SELECT m.id, m.nome, m.num_motoq, m.telefone, m.moto, m.cor, m.placa, m.tipo_sang FROM motoqueiro m where m.num_motoq = "
						+ pesq3;
				sttm = conn.prepareStatement(sql);
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					String nome = rs.getString("nome");
					int numero = rs.getInt("num_motoq");
					String telefone = rs.getString("telefone");
					String moto = rs.getString("moto");
					String cor = rs.getString("cor");
					String placa = rs.getString("placa");
					String tipo_sang = rs.getString("tipo_sang");

					MotoqueiroTO motoqueiro = new MotoqueiroTO();

					motoqueiro.setId(id);
					motoqueiro.setNome(nome);
					motoqueiro.setNumMotoq(numero);
					motoqueiro.setTelefone(telefone);
					motoqueiro.setMoto(moto);
					motoqueiro.setCor(cor);
					motoqueiro.setPlacaMoto(placa);
					motoqueiro.setTipoSang(tipo_sang);

					result.add(motoqueiro);

				}

			}

			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}

	}

	public ArrayList<MotoqueiroTO> listarMotoqueirosDia() throws DAOException {

		java.util.Date dtnasc = null;

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<MotoqueiroTO> result = new ArrayList<MotoqueiroTO>();
			conn = ConnectionBanco.getConnection();
			dtnasc = new java.util.Date();

			String sql = "SELECT m.id, m.nome, m.num_motoq, m.telefone, m.moto, m.cor, m.placa, m.tipo_sang FROM motoqueiro m WHERE "
					+ "m.data = ? ORDER BY m.id";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dtnasc.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				int numero = rs.getInt("num_motoq");
				String telefone = rs.getString("telefone");
				String moto = rs.getString("moto");
				String cor = rs.getString("cor");
				String placa = rs.getString("placa");
				String tipo_sang = rs.getString("tipo_sang");

				MotoqueiroTO motoqueiro = new MotoqueiroTO();

				motoqueiro.setId(id);
				motoqueiro.setNome(nome);
				motoqueiro.setNumMotoq(numero);
				motoqueiro.setTelefone(telefone);
				motoqueiro.setMoto(moto);
				motoqueiro.setCor(cor);
				motoqueiro.setPlacaMoto(placa);
				motoqueiro.setTipoSang(tipo_sang);

				result.add(motoqueiro);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}

	}

	public ArrayList<MotoqueiroTO> listarMotoqueirosCombobox()
			throws DAOException {

		Connection conn = null;
		Statement sttm = null;
		ResultSet rs = null;
		try {
			ArrayList<MotoqueiroTO> result = new ArrayList<MotoqueiroTO>();
			conn = ConnectionBanco.getConnection();
			String sql = "SELECT m.nome, m.num_motoq FROM motoqueiro AS m ORDER BY m.nome";
			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql);

			while (rs.next()) {

				String nome = rs.getString("nome");
				int numero = rs.getInt("num_motoq");

				MotoqueiroTO motoqueiro = new MotoqueiroTO();

				motoqueiro.setNome(nome);
				motoqueiro.setNumMotoq(numero);

				result.add(motoqueiro);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());
		}
	}

	public void excluirMotoqueiro(String codigo) throws DAOException {
		Connection conn = null;
		PreparedStatement ps = null;

		Statement sttm = null;
		ResultSet rs = null;
		MotoqueiroTO motoqueiroTO = null;

		try {
			conn = ConnectionBanco.getConnection();
			String sql1 = "SELECT * FROM motoqueiro m WHERE m.id= " + codigo;

			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql1);

			while (rs.next()) {

				int id = rs.getInt("id");

				motoqueiroTO = new MotoqueiroTO();
				motoqueiroTO.setId(id);

			}

			sttm.close();
			rs.close();

			if (motoqueiroTO.getId() != null) {
				try {

					String sql = " delete from motoqueiro m where m.id = "
							+ motoqueiroTO.getId();
					ps = conn.prepareStatement(sql);
					ps.executeUpdate();
					ps.close();

				} catch (SQLException e) {
					throw new DAOException(
							"N�o foi poss�vel excluir o Motoqueiro.\nError: "
									+ e.getMessage());
				}

			} else {
				throw new DAOException("N�o h� dados a serem exclu�dos.");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,
					"N�o Foi Poss�vel excluir o registro!");

		}
	}

	public MotoqueiroTO buscarMotoqueiro(String codigo) throws DAOException {

		Connection conn = null;
		Statement sttm = null;
		ResultSet rs = null;

		try {
			MotoqueiroTO result = new MotoqueiroTO();
			conn = ConnectionBanco.getConnection();
			String sql = "SELECT * FROM motoqueiro m WHERE m.id= " + codigo;

			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql);

			while (rs.next()) {

				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				String end = rs.getString("endereco");
				int num = rs.getInt("numero");
				int num_motoq = rs.getInt("num_motoq");
				String bairro = rs.getString("bairro");
				String cidade = rs.getString("cidade");
				String cep = rs.getString("cep");
				String telefone = rs.getString("telefone");
				Date data = rs.getDate("data");
				String tipo_sang = rs.getString("tipo_sang");
				String cpf = rs.getString("cpf");
				String rg = rs.getString("rg");
				String cnh = rs.getString("cnh");
				String categoria = rs.getString("categoria");
				String moto = rs.getString("moto");
				String renavan = rs.getString("renavan");
				String ano_modelo = rs.getString("ano_modelo");
				String cilindrada = rs.getString("cilindrada");
				String placa = rs.getString("placa");
				String cor = rs.getString("cor");

				MotoqueiroTO motoqueiro = new MotoqueiroTO();

				motoqueiro.setId(id);
				motoqueiro.setNome(nome);
				motoqueiro.setEndereco(end);
				motoqueiro.setNumero(num);
				motoqueiro.setNumMotoq(num_motoq);
				motoqueiro.setBairro(bairro);
				motoqueiro.setCidade(cidade);
				motoqueiro.setCep(cep);
				motoqueiro.setTelefone(telefone);
				motoqueiro.setData(data);
				motoqueiro.setTipoSang(tipo_sang);
				motoqueiro.setCpf(cpf);
				motoqueiro.setRg(rg);
				motoqueiro.setCnh(cnh);
				motoqueiro.setCategoria(categoria);
				motoqueiro.setMoto(moto);
				motoqueiro.setRenavan(renavan);
				motoqueiro.setAnoModelo(ano_modelo);
				motoqueiro.setCilindrada(cilindrada);
				motoqueiro.setPlacaMoto(placa);
				motoqueiro.setCor(cor);
				result = motoqueiro;

			}
			sttm.close();
			rs.close();

			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());
		}
	}

	public void editarMotoqueiro(MotoqueiroTO motoqueiroTO) throws DAOException {

		Connection conn = null;

		PreparedStatement ps = null;
		if (motoqueiroTO != null) {
			try {
				conn = ConnectionBanco.getConnection();
				String sql = " UPDATE motoqueiro set nome=?, endereco=?, numero=?, num_motoq=?, bairro=?, cidade=?, cep=?, telefone=?, data=?, tipo_sang=?, cpf=?, rg=?, cnh=?, categoria=?, moto=?, renavan=?, ano_modelo=?, cilindrada=?, placa=?, cor=? where id = "
						+ motoqueiroTO.getId();

				ps = conn.prepareStatement(sql);

				ps.setString(1, motoqueiroTO.getNome());
				ps.setString(2, motoqueiroTO.getEndereco());
				ps.setInt(3, motoqueiroTO.getNumero());
				ps.setInt(4, motoqueiroTO.getNumMotoq());
				ps.setString(5, motoqueiroTO.getBairro());
				ps.setString(6, motoqueiroTO.getCidade());
				ps.setString(7, motoqueiroTO.getCep());
				ps.setString(8, motoqueiroTO.getTelefone());
				ps.setDate(9, new Date(motoqueiroTO.getData().getTime()));
				ps.setString(10, motoqueiroTO.getTipoSang());
				ps.setString(11, motoqueiroTO.getCpf());
				ps.setString(12, motoqueiroTO.getRg());
				ps.setString(13, motoqueiroTO.getCnh());
				ps.setString(14, motoqueiroTO.getCategoria());
				ps.setString(15, motoqueiroTO.getMoto());
				ps.setString(16, motoqueiroTO.getRenavan());
				ps.setString(17, motoqueiroTO.getAnoModelo());
				ps.setString(18, motoqueiroTO.getCilindrada());
				ps.setString(19, motoqueiroTO.getPlacaMoto());
				ps.setString(20, motoqueiroTO.getCor());

				ps.executeUpdate();

				ps.close();
			} catch (SQLException e) {
				throw new DAOException(
						"N�o foi poss�vel realizar a atualiza��o do cadastro.\nError: "
								+ e.getMessage());
			}

		} else {
			throw new DAOException("N�o h� dados a serem cadastrados.");
		}
	}

	public ArrayList<MotoqueiroTO> listarValorFretes() throws DAOException {
		java.util.Date dtnasc = null;

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<MotoqueiroTO> result = new ArrayList<MotoqueiroTO>();
			conn = ConnectionBanco.getConnection();
			dtnasc = new java.util.Date();

			String sql = "select f.motoqueiro, sum(valor) as vlr from frete f "
					+ "left outer join motoqueiro o "
					+ "on o.nome = f.motoqueiro where f.data = ? "
					+ "group by f.motoqueiro order by sum(valor) desc";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dtnasc.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				int numero = rs.getInt("num_motoq");
				String telefone = rs.getString("telefone");
				String moto = rs.getString("moto");
				String cor = rs.getString("cor");
				String placa = rs.getString("placa");
				String tipo_sang = rs.getString("tipo_sang");

				MotoqueiroTO motoqueiro = new MotoqueiroTO();

				motoqueiro.setId(id);
				motoqueiro.setNome(nome);
				motoqueiro.setNumMotoq(numero);
				motoqueiro.setTelefone(telefone);
				motoqueiro.setMoto(moto);
				motoqueiro.setCor(cor);
				motoqueiro.setPlacaMoto(placa);
				motoqueiro.setTipoSang(tipo_sang);

				result.add(motoqueiro);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}
	}

	public ArrayList<MotoqueiroTO> listarMotoqueiroMaisServ(
			JDateChooser dtInic, JDateChooser dtFim) throws DAOException {

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<MotoqueiroTO> result = new ArrayList<MotoqueiroTO>();
			conn = ConnectionBanco.getConnection();
			java.util.Date dataInic = dtInic.getDate();
			java.util.Date dataFim = dtFim.getDate();

			String sql = " SELECT m.nome, m.num_motoq, m.moto, m.placa, count(m.nome) as qtd"
					+ " FROM motoqueiro m LEFT OUTER JOIN frete f "
					+ "ON m.nome = f.motoqueiro WHERE "
					+ "f.data between ?"
					+ "  and ? "
					+ "GROUP BY m.nome, m.num_motoq, m.moto, m.placa  "
					+ "ORDER BY count(m.nome) DESC";

			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dataInic.getTime()));
			sttm.setTimestamp(2, new Timestamp(dataFim.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				String motoq = rs.getString("nome");
				int numMotoq = rs.getInt("num_motoq");
				String moto = rs.getString("moto");
				String placa = rs.getString("placa");
				int total = rs.getInt("qtd");

				MotoqueiroTO motoqueiro = new MotoqueiroTO();

				motoqueiro.setNome(motoq);
				motoqueiro.setNumMotoq(numMotoq);
				motoqueiro.setMoto(moto);
				motoqueiro.setPlacaMoto(placa);
				motoqueiro.setNumero(total);
				result.add(motoqueiro);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}

	}

	public ArrayList<MotoqueiroTO> listarMotoqueiroMaisServNoDia()
			throws DAOException {

		java.util.Date data = null;

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<MotoqueiroTO> result = new ArrayList<MotoqueiroTO>();
			conn = ConnectionBanco.getConnection();
			data = new java.util.Date();

			String sql = " SELECT m.nome, m.num_motoq, m.moto, m.placa, count(m.nome) as qtd"
					+ " FROM motoqueiro m LEFT OUTER JOIN frete f "
					+ "ON m.nome = f.motoqueiro WHERE "
					+ "f.data = ? "
					+ "GROUP BY m.nome, m.num_motoq, m.moto, m.placa  "
					+ "ORDER BY count(m.nome) DESC";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(data.getTime()));

			rs = sttm.executeQuery();

			while (rs.next()) {

				String motoq = rs.getString("nome");
				int numMotoq = rs.getInt("num_motoq");
				String moto = rs.getString("moto");
				String placa = rs.getString("placa");
				int total = rs.getInt("qtd");

				MotoqueiroTO motoqueiro = new MotoqueiroTO();

				motoqueiro.setNome(motoq);
				motoqueiro.setNumMotoq(numMotoq);
				motoqueiro.setMoto(moto);
				motoqueiro.setPlacaMoto(placa);
				motoqueiro.setNumero(total);
				result.add(motoqueiro);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}
	}

}
