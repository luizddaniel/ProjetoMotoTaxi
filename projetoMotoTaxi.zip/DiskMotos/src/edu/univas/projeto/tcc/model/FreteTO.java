package edu.univas.projeto.tcc.model;

import java.util.Date;

public class FreteTO {

	private Integer id;
	private Integer numFrete;
	private String horaLig;
	private String horaSaida;
	private String horaCheg;
	private Float valor;
	private Date data;
	private String destino;
	private String motoq;
	private Integer qtd;
	private String mes;
	private Integer numMes;
	
	public Integer getNumMes() {
		return numMes;
	}

	public void setNumMes(Integer numMes) {
		this.numMes = numMes;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public Integer getQtd() {
		return qtd;
	}

	public void setQtd(Integer qtd) {
		this.qtd = qtd;
	}

	public Integer getNumFrete() {
		return numFrete;
	}

	public void setNumFrete(Integer numFrete) {
		this.numFrete = numFrete;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public String getMotoq() {
		return motoq;
	}

	public void setMotoq(String motoq) {
		this.motoq = motoq;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getHoraLig() {
		return horaLig;
	}

	public void setHoraLig(String horaLig) {
		this.horaLig = horaLig;
	}

	public String getHoraSaida() {
		return horaSaida;
	}

	public void setHoraSaida(String horaSaida) {
		this.horaSaida = horaSaida;
	}

	public String getHoraCheg() {
		return horaCheg;
	}

	public void setHoraCheg(String horaCheg) {
		this.horaCheg = horaCheg;
	}

	public Float getValor() {
		return valor;
	}

	public void setValor(Float valor) {
		this.valor = valor;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

}
