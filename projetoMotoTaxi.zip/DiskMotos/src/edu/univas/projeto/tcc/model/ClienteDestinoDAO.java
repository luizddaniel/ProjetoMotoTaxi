package edu.univas.projeto.tcc.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.controller.ConnectionBanco;

public class ClienteDestinoDAO {

	public void cadastrar(ClienteDestinoTO clienteDestinoTO)
			throws DAOException {
		Connection conn = null;
		PreparedStatement ps = null;

		if (clienteDestinoTO != null) {
			try {
				conn = ConnectionBanco.getConnection();
				String sql = " INSERT INTO cliente_destino (nome, tipo, endereco, numero, bairro, cidade, cep, telefone, cnpj_cpf, insc_rg, e_mail, data_cad ) "
						+ " values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";

				ps = conn.prepareStatement(sql);

				ps.setString(1, clienteDestinoTO.getNome());
				ps.setString(2, clienteDestinoTO.getTipo());
				ps.setString(3, clienteDestinoTO.getEndereco());
				ps.setInt(4, clienteDestinoTO.getNumero());
				ps.setString(5, clienteDestinoTO.getBairro());
				ps.setString(6, clienteDestinoTO.getCidade());
				ps.setString(7, clienteDestinoTO.getCep());
				ps.setString(8, clienteDestinoTO.getTelefone());
				ps.setString(9, clienteDestinoTO.getCnpjCpf());
				ps.setString(10, clienteDestinoTO.getInscRg());
				ps.setString(11, clienteDestinoTO.getE_mail());
				ps.setDate(12,
						new Date(clienteDestinoTO.getDataCad().getTime()));

				ps.executeUpdate();

				ps.close();
			} catch (SQLException e) {
				throw new DAOException(
						"N�o foi poss�vel realizar o cadastro.\nError: "
								+ e.getMessage());
			}

		} else {
			throw new DAOException("N�o h� dados a serem cadastrados.");
		}
	}

	public ArrayList<ClienteDestinoTO> listarClientesDestinoDia()
			throws DAOException {

		java.util.Date dtnasc = null;

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<ClienteDestinoTO> result = new ArrayList<ClienteDestinoTO>();
			conn = ConnectionBanco.getConnection();
			dtnasc = new java.util.Date();

			String sql = "SELECT cd.id, cd.nome, cd.endereco, cd.numero, cd.bairro, cd.cidade, cd.cep, cd.telefone,cd.e_mail FROM cliente_destino cd where cd.data_cad = ? ORDER BY cd.id";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dtnasc.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				String endereco = rs.getString("endereco");
				int numero = rs.getInt("numero");
				String bairro = rs.getString("bairro");
				String cidade = rs.getString("cidade");
				String cep = rs.getString("cep");
				String telefone = rs.getString("telefone");
				String e_mail = rs.getString("e_mail");

				ClienteDestinoTO clienteDestino = new ClienteDestinoTO();

				clienteDestino.setId(id);
				clienteDestino.setNome(nome);
				clienteDestino.setEndereco(endereco);
				clienteDestino.setNumero(numero);
				clienteDestino.setBairro(bairro);
				clienteDestino.setCidade(cidade);
				clienteDestino.setCep(cep);
				clienteDestino.setTelefone(telefone);
				clienteDestino.setE_mail(e_mail);
				result.add(clienteDestino);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			e.printStackTrace();
			throw new DAOException("Erro:" + e.getMessage());
		}

	}

	public ArrayList<ClienteDestinoTO> listarClientesDestinoTudo()
			throws DAOException {

		Connection conn = null;
		Statement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<ClienteDestinoTO> result = new ArrayList<ClienteDestinoTO>();
			conn = ConnectionBanco.getConnection();

			String sql = "SELECT cd.id, cd.nome, cd.endereco, cd.numero, cd.bairro, cd.cidade, cd.cep, cd.telefone,cd.e_mail FROM cliente_destino AS cd ORDER BY cd.nome";
			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql);

			while (rs.next()) {

				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				String endereco = rs.getString("endereco");
				int numero = rs.getInt("numero");
				String bairro = rs.getString("bairro");
				String cidade = rs.getString("cidade");
				String cep = rs.getString("cep");
				String telefone = rs.getString("telefone");
				String e_mail = rs.getString("e_mail");

				ClienteDestinoTO clienteDestino = new ClienteDestinoTO();

				clienteDestino.setId(id);
				clienteDestino.setNome(nome);
				clienteDestino.setEndereco(endereco);
				clienteDestino.setNumero(numero);
				clienteDestino.setBairro(bairro);
				clienteDestino.setCidade(cidade);
				clienteDestino.setCep(cep);
				clienteDestino.setTelefone(telefone);
				clienteDestino.setE_mail(e_mail);
				result.add(clienteDestino);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());
		}

	}

	public ArrayList<ClienteDestinoTO> listarClientesDestinoCombobox()
			throws DAOException {

		Connection conn = null;
		Statement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<ClienteDestinoTO> result = new ArrayList<ClienteDestinoTO>();
			conn = ConnectionBanco.getConnection();

			String sql = "SELECT cd.nome FROM cliente_destino AS cd ORDER BY cd.nome";
			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql);

			while (rs.next()) {

				String nome = rs.getString("nome");

				ClienteDestinoTO clienteDestino = new ClienteDestinoTO();

				clienteDestino.setNome(nome);
				result.add(clienteDestino);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());
		}

	}

	public void excluirDestino(String codigo) throws DAOException {
		Connection conn = null;
		PreparedStatement ps = null;
		String i = codigo;
		Statement sttm = null;
		ResultSet rs = null;
		ClienteDestinoTO clienteDestino = null;

		try {
			conn = ConnectionBanco.getConnection();
			String sql1 = "SELECT * FROM cliente_destino cd WHERE cd.id= "
					+ codigo;

			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql1);

			while (rs.next()) {

				int id = rs.getInt("id");

				clienteDestino = new ClienteDestinoTO();
				clienteDestino.setId(id);

			}

			sttm.close();
			rs.close();

			if (clienteDestino.getId() != null) {
				try {

					String sql = " delete from cliente_destino cd where cd.id = "
							+ i;
					ps = conn.prepareStatement(sql);
					ps.executeUpdate();
					ps.close();

				} catch (SQLException e) {
					JOptionPane.showMessageDialog(null, "C�digo " + codigo
							+ " Inexistente!\n N�o foi poss�vel o registro!");
					throw new DAOException(
							"N�o foi poss�vel excluir o registro.\nError: "
									+ e.getMessage());
				}

			} else {
				throw new DAOException("N�o h� dados a serem cadastrados.");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,
					"N�o Foi Poss�vel excluir o registro!");

		}
	}

	public ClienteDestinoTO buscarClienteDestino(String codigo)
			throws DAOException {

		Connection conn = null;
		Statement sttm = null;
		ResultSet rs = null;

		try {
			ClienteDestinoTO result = new ClienteDestinoTO();
			conn = ConnectionBanco.getConnection();
			String sql = "SELECT * FROM cliente_destino cd WHERE cd.id= "
					+ codigo;

			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql);

			while (rs.next()) {

				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				String tipo = rs.getString("tipo");
				String end = rs.getString("endereco");
				int num = rs.getInt("numero");
				String bairro = rs.getString("bairro");
				String cidade = rs.getString("cidade");
				String cep = rs.getString("cep");
				String telefone = rs.getString("telefone");
				String cnpj_cpf = rs.getString("cnpj_cpf");
				String insc_rg = rs.getString("insc_rg");
				String e_mail = rs.getString("e_mail");
				Date data_cad = rs.getDate("data_cad");

				ClienteDestinoTO clienteDestino = new ClienteDestinoTO();

				clienteDestino.setId(id);
				clienteDestino.setNome(nome);
				clienteDestino.setTipo(tipo);
				clienteDestino.setEndereco(end);
				clienteDestino.setNumero(num);
				clienteDestino.setBairro(bairro);
				clienteDestino.setCidade(cidade);
				clienteDestino.setCep(cep);
				clienteDestino.setTelefone(telefone);
				clienteDestino.setCnpjCpf(cnpj_cpf);
				clienteDestino.setInscRg(insc_rg);
				clienteDestino.setE_mail(e_mail);
				clienteDestino.setDataCad(data_cad);
				result = clienteDestino;
			}
			sttm.close();
			rs.close();

			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());
		}

	}

	public void editarClienteDestino(ClienteDestinoTO clienteDestinoTO)
			throws DAOException {
		Connection conn = null;
		PreparedStatement ps = null;

		if (clienteDestinoTO != null) {
			try {
				conn = ConnectionBanco.getConnection();
				String sql = " UPDATE cliente_destino SET nome=?, tipo=?, endereco=?, numero=?, bairro=?, cidade=?, cep=?, telefone=?, cnpj_cpf=?, insc_rg=?, e_mail=?, data_cad=? WHERE id = "
						+ clienteDestinoTO.getId();

				ps = conn.prepareStatement(sql);

				ps.setString(1, clienteDestinoTO.getNome());
				ps.setString(2, clienteDestinoTO.getTipo());
				ps.setString(3, clienteDestinoTO.getEndereco());
				ps.setInt(4, clienteDestinoTO.getNumero());
				ps.setString(5, clienteDestinoTO.getBairro());
				ps.setString(6, clienteDestinoTO.getCidade());
				ps.setString(7, clienteDestinoTO.getCep());
				ps.setString(8, clienteDestinoTO.getTelefone());
				ps.setString(9, clienteDestinoTO.getCnpjCpf());
				ps.setString(10, clienteDestinoTO.getInscRg());
				ps.setString(11, clienteDestinoTO.getE_mail());
				ps.setDate(12,
						new Date(clienteDestinoTO.getDataCad().getTime()));

				ps.executeUpdate();

				ps.close();
			} catch (SQLException e) {
				throw new DAOException(
						"N�o foi poss�vel realizar o cadastro.\nError: "
								+ e.getMessage());
			}

		} else {
			throw new DAOException("N�o h� dados a serem cadastrados.");
		}
	}

	public ArrayList<ClienteDestinoTO> pesquisarClientesDestino(
			java.util.Date data, String pesq1, String pesq2, Integer pesq3)
			throws DAOException {

		String comp = "";

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<ClienteDestinoTO> result = new ArrayList<ClienteDestinoTO>();
			conn = ConnectionBanco.getConnection();

			if (data != null) {
				String sql = "SELECT cd.id, cd.nome, cd.endereco, cd.numero, cd.bairro, cd.cidade, cd.cep, cd.telefone,cd.e_mail FROM cliente_destino cd where cd.data_cad = ? ORDER BY cd.id";
				sttm = conn.prepareStatement(sql);
				sttm.setTimestamp(1, new Timestamp(data.getTime()));
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					String nome = rs.getString("nome");
					String endereco = rs.getString("endereco");
					int numero = rs.getInt("numero");
					String bairro = rs.getString("bairro");
					String cidade = rs.getString("cidade");
					String cep = rs.getString("cep");
					String telefone = rs.getString("telefone");
					String e_mail = rs.getString("e_mail");

					ClienteDestinoTO clienteDestino = new ClienteDestinoTO();

					clienteDestino.setId(id);
					clienteDestino.setNome(nome);
					clienteDestino.setEndereco(endereco);
					clienteDestino.setNumero(numero);
					clienteDestino.setBairro(bairro);
					clienteDestino.setCidade(cidade);
					clienteDestino.setCep(cep);
					clienteDestino.setTelefone(telefone);
					clienteDestino.setE_mail(e_mail);
					result.add(clienteDestino);

				}

			} else if (!comp.equals(pesq1)) {
				String sql = "SELECT cd.id, cd.nome, cd.endereco, cd.numero, cd.bairro, cd.cidade, cd.cep, cd.telefone,cd.e_mail FROM cliente_destino cd "
						+ "where cd.bairro like '%" + pesq1 + "%'";
				sttm = conn.prepareStatement(sql);
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					String nome = rs.getString("nome");
					String endereco = rs.getString("endereco");
					int numero = rs.getInt("numero");
					String bairro = rs.getString("bairro");
					String cidade = rs.getString("cidade");
					String cep = rs.getString("cep");
					String telefone = rs.getString("telefone");
					String e_mail = rs.getString("e_mail");

					ClienteDestinoTO clienteDestino = new ClienteDestinoTO();

					clienteDestino.setId(id);
					clienteDestino.setNome(nome);
					clienteDestino.setEndereco(endereco);
					clienteDestino.setNumero(numero);
					clienteDestino.setBairro(bairro);
					clienteDestino.setCidade(cidade);
					clienteDestino.setCep(cep);
					clienteDestino.setTelefone(telefone);
					clienteDestino.setE_mail(e_mail);
					result.add(clienteDestino);

				}

			} else if (!comp.equals(pesq2)) {

				String sql = "SELECT cd.id, cd.nome, cd.endereco, cd.numero, cd.bairro, cd.cidade, cd.cep, cd.telefone,cd.e_mail FROM cliente_destino cd where cd.nome like '%"
						+ pesq2 + "%'";
				sttm = conn.prepareStatement(sql);
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					String nome = rs.getString("nome");
					String endereco = rs.getString("endereco");
					int numero = rs.getInt("numero");
					String bairro = rs.getString("bairro");
					String cidade = rs.getString("cidade");
					String cep = rs.getString("cep");
					String telefone = rs.getString("telefone");
					String e_mail = rs.getString("e_mail");

					ClienteDestinoTO clienteDestino = new ClienteDestinoTO();

					clienteDestino.setId(id);
					clienteDestino.setNome(nome);
					clienteDestino.setEndereco(endereco);
					clienteDestino.setNumero(numero);
					clienteDestino.setBairro(bairro);
					clienteDestino.setCidade(cidade);
					clienteDestino.setCep(cep);
					clienteDestino.setTelefone(telefone);
					clienteDestino.setE_mail(e_mail);
					result.add(clienteDestino);

				}

			} else if (pesq3 != null) {

				String sql = "SELECT cd.id, cd.nome, cd.endereco, cd.numero, cd.bairro, cd.cidade, cd.cep, cd.telefone,cd.e_mail FROM cliente_destino cd where cd.numero = ?";
				sttm = conn.prepareStatement(sql);
				sttm.setInt(1, pesq3);
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					String nome = rs.getString("nome");
					String endereco = rs.getString("endereco");
					int numero = rs.getInt("numero");
					String bairro = rs.getString("bairro");
					String cidade = rs.getString("cidade");
					String cep = rs.getString("cep");
					String telefone = rs.getString("telefone");
					String e_mail = rs.getString("e_mail");

					ClienteDestinoTO clienteDestino = new ClienteDestinoTO();

					clienteDestino.setId(id);
					clienteDestino.setNome(nome);
					clienteDestino.setEndereco(endereco);
					clienteDestino.setNumero(numero);
					clienteDestino.setBairro(bairro);
					clienteDestino.setCidade(cidade);
					clienteDestino.setCep(cep);
					clienteDestino.setTelefone(telefone);
					clienteDestino.setE_mail(e_mail);
					result.add(clienteDestino);
				}
			}
			if (sttm != null) {

				sttm.close();
			}
			if (rs != null) {

				rs.close();
			}
			return result;

		} catch (SQLException e) {
			e.printStackTrace();
			throw new DAOException("Erro:" + e.getMessage());
		}

	}

	public ArrayList<ClienteDestinoTO> listarClienteMaisSolicServ(
			JDateChooser dtInic, JDateChooser dtFim) throws DAOException {

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<ClienteDestinoTO> result = new ArrayList<ClienteDestinoTO>();
			conn = ConnectionBanco.getConnection();
			java.util.Date dataInic = dtInic.getDate();
			java.util.Date dataFim = dtFim.getDate();

			String sql = " SELECT cd.nome, cd.cidade, cd.telefone, cd.e_mail, cd.cnpj_cpf, count(cd.nome) as qtd "
					+ " FROM cliente_destino cd LEFT OUTER JOIN frete f "
					+ "ON cd.nome = f.destino WHERE cd.bairro IS NOT null "
					+ "and cd.tipo = 'Cliente' and f.data between ? and ? "
					+ "GROUP BY cd.nome, cd.cidade, cd.telefone, cd.e_mail, cd.cnpj_cpf "
					+ "ORDER BY count(cd.nome) DESC";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dataInic.getTime()));
			sttm.setTimestamp(2, new Timestamp(dataFim.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				String nome = rs.getString("nome");
				String cidade = rs.getString("cidade");
				String telefone = rs.getString("telefone");
				String cnpjCpf = rs.getString("cnpj_cpf");
				String email = rs.getString("e_mail");
				int total = rs.getInt("qtd");

				ClienteDestinoTO cliente = new ClienteDestinoTO();

				cliente.setNome(nome);
				cliente.setCidade(cidade);
				cliente.setTelefone(telefone);
				cliente.setCnpjCpf(cnpjCpf);
				cliente.setE_mail(email);
				cliente.setNumero(total);
				result.add(cliente);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}

	}

	public ArrayList<ClienteDestinoTO> listarCliMaisSolicServNoDia()
			throws DAOException {

		java.util.Date data = null;

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<ClienteDestinoTO> result = new ArrayList<ClienteDestinoTO>();
			conn = ConnectionBanco.getConnection();
			data = new java.util.Date();

			String sql = " SELECT cd.nome, cd.cidade, cd.telefone, cd.e_mail, cd.cnpj_cpf, count(cd.nome) as qtd "
					+ " FROM cliente_destino cd LEFT OUTER JOIN frete f "
					+ "ON cd.nome = f.destino WHERE cd.bairro IS NOT null "
					+ "and cd.tipo = 'Cliente' and f.data = ? GROUP BY cd.nome, cd.cidade, cd.telefone, cd.e_mail, cd.cnpj_cpf "
					+ "ORDER BY count(cd.nome) DESC";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(data.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				String nome = rs.getString("nome");
				String cidade = rs.getString("cidade");
				String telefone = rs.getString("telefone");
				String cnpjCpf = rs.getString("cnpj_cpf");
				String email = rs.getString("e_mail");
				int total = rs.getInt("qtd");

				ClienteDestinoTO cliente = new ClienteDestinoTO();

				cliente.setNome(nome);
				cliente.setCidade(cidade);
				cliente.setTelefone(telefone);
				cliente.setCnpjCpf(cnpjCpf);
				cliente.setE_mail(email);
				cliente.setNumero(total);
				result.add(cliente);
			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			e.printStackTrace();
			throw new DAOException("Erro:" + e.getMessage());

		}
	}

	public ArrayList<ClienteDestinoTO> listarBairroMaisSolicServ(
			JDateChooser dtInic, JDateChooser dtFim) throws DAOException {
	
		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<ClienteDestinoTO> result = new ArrayList<ClienteDestinoTO>();
			conn = ConnectionBanco.getConnection();
			java.util.Date dataInic = dtInic.getDate();
			java.util.Date dataFim = dtFim.getDate();

			String sql = " SELECT cd.bairro, cd.cidade, cd.cep, count(cd.nome) as qtd"
					+ " FROM cliente_destino cd LEFT OUTER JOIN frete f "
					+ "ON cd.nome = f.destino WHERE cd.bairro IS NOT null "
					+ "and f.data between ? and ? "
					+ "GROUP BY cd.bairro, cd.cidade, cd.cep  "
					+ "ORDER BY count(cd.nome) DESC";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dataInic.getTime()));
			sttm.setTimestamp(2, new Timestamp(dataFim.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				String bairro = rs.getString("bairro");
				String cidade = rs.getString("cidade");
				String cep = rs.getString("cep");
				int total = rs.getInt("qtd");

				ClienteDestinoTO cliente = new ClienteDestinoTO();

				cliente.setBairro(bairro);
				cliente.setCidade(cidade);
				cliente.setCep(cep);
				cliente.setNumero(total);
				result.add(cliente);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}

	}

	public ArrayList<ClienteDestinoTO> listarBairroMaisSolicServNoDia()
			throws DAOException {

		java.util.Date data = null;

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<ClienteDestinoTO> result = new ArrayList<ClienteDestinoTO>();
			conn = ConnectionBanco.getConnection();
			data = new java.util.Date();

			String sql = " SELECT cd.bairro, cd.cidade, cd.cep, count(cd.nome) as qtd "
					+ " FROM cliente_destino cd LEFT OUTER JOIN frete f "
					+ "ON cd.nome = f.destino WHERE cd.bairro != ' ' "
					+ "and f.data = ? "
					+ "GROUP BY cd.bairro, cd.cidade, cd.cep "
					+ "ORDER BY count(cd.nome) DESC";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(data.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				String bairro = rs.getString("bairro");
				String cidade = rs.getString("cidade");
				String cep = rs.getString("cep");
				int total = rs.getInt("qtd");

				ClienteDestinoTO cliente = new ClienteDestinoTO();

				cliente.setBairro(bairro);
				cliente.setCidade(cidade);
				cliente.setCep(cep);
				cliente.setNumero(total);
				result.add(cliente);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}
	}

}
