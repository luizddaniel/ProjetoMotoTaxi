package edu.univas.projeto.tcc.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.controller.ConnectionBanco;

public class FreteDAO {

	public void cadastrarFrete(FreteTO freteTO) throws DAOException {

		Connection conn = null;
		PreparedStatement ps = null;
		if (freteTO != null) {
			try {
				conn = ConnectionBanco.getConnection();
				String sql = " INSERT INTO "
						+ "frete (num_frete, hora_lig, hora_saida, hora_cheg,"
						+ " valor, data, destino, motoqueiro, mes, id_mes )"
						+ " values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";

				ps = conn.prepareStatement(sql);

				ps.setInt(1, freteTO.getNumFrete());
				ps.setString(2, freteTO.getHoraLig());
				ps.setString(3, freteTO.getHoraSaida());
				ps.setString(4, freteTO.getHoraCheg());
				ps.setFloat(5, freteTO.getValor());
				ps.setDate(6, new Date(freteTO.getData().getTime()));
				ps.setString(7, freteTO.getDestino());
				ps.setString(8, freteTO.getMotoq());
				ps.setString(9, freteTO.getMes());
				ps.setInt(10, freteTO.getNumMes());

				ps.executeUpdate();

				ps.close();
			} catch (SQLException e) {
				throw new DAOException(
						"N�o foi poss�vel realizar o cadastro.\nError: "
								+ e.getMessage());
			}
		} else {
			throw new DAOException("N�o h� dados a serem cadastrados.");
		}
	}

	public ArrayList<FreteTO> listarFretes() throws DAOException {

		java.util.Date dtnasc = null;

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<FreteTO> result = new ArrayList<FreteTO>();
			conn = ConnectionBanco.getConnection();
			dtnasc = new java.util.Date();

			String sql = "SELECT f.id, f.num_frete, f.hora_lig, f.hora_saida, f.hora_cheg, f.valor, f.data, f.destino, f.motoqueiro FROM frete f WHERE "
					+ "f.data = ? ORDER BY f.num_frete desc";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dtnasc.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				int id = rs.getInt("id");
				int num_frete = rs.getInt("num_frete");
				String hl = rs.getString("hora_lig");
				String hs = rs.getString("hora_saida");
				String hc = rs.getString("hora_cheg");
				Float vlr = rs.getFloat("valor");
				Date data = rs.getDate("data");
				String destino = rs.getString("destino");
				String motoq = rs.getString("motoqueiro");

				FreteTO frete = new FreteTO();

				frete.setId(id);
				frete.setHoraLig(hl);
				frete.setHoraSaida(hs);
				frete.setNumFrete(num_frete);
				frete.setHoraCheg(hc);
				frete.setValor(vlr);
				frete.setData(data);
				frete.setDestino(destino);
				frete.setMotoq(motoq);
				result.add(frete);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());
		}

	}

	public ArrayList<FreteTO> listarTudo() throws DAOException {

		Connection conn = null;
		Statement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<FreteTO> result = new ArrayList<FreteTO>();
			conn = ConnectionBanco.getConnection();
			String sql = "SELECT f.id, f.num_frete, f.hora_lig, f.hora_saida, f.hora_cheg, f.valor, f.data, f.destino, f.motoqueiro FROM frete f  ORDER BY f.id";
			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql);

			while (rs.next()) {

				int id = rs.getInt("id");
				int num_frete = rs.getInt("num_frete");
				String hl = rs.getString("hora_lig");
				String hs = rs.getString("hora_saida");
				String hc = rs.getString("hora_cheg");
				Float vlr = rs.getFloat("valor");
				Date data = rs.getDate("data");
				String destino = rs.getString("destino");
				String motoq = rs.getString("motoqueiro");

				FreteTO frete = new FreteTO();

				frete.setId(id);
				frete.setHoraLig(hl);
				frete.setHoraSaida(hs);
				frete.setNumFrete(num_frete);
				frete.setHoraCheg(hc);
				frete.setValor(vlr);
				frete.setData(data);
				frete.setDestino(destino);
				frete.setMotoq(motoq);
				result.add(frete);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());
		}

	}

	public void excluirFrete(String codigo) throws DAOException {
		Connection conn = null;
		PreparedStatement ps = null;
		String i = codigo;
		Statement sttm = null;
		ResultSet rs = null;
		FreteTO freteTO = null;

		try {
			conn = ConnectionBanco.getConnection();
			String sql1 = "SELECT * FROM frete f WHERE f.id= " + codigo;

			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql1);

			while (rs.next()) {

				int id = rs.getInt("id");

				freteTO = new FreteTO();
				freteTO.setId(id);

			}

			sttm.close();
			rs.close();

			if (freteTO.getId() != null) {
				try {

					String sql = " delete from frete f where f.id = " + i;
					ps = conn.prepareStatement(sql);
					ps.executeUpdate();
					ps.close();

				} catch (SQLException e) {
					throw new DAOException(
							"N�o foi poss�vel excluir o frete.\nError: "
									+ e.getMessage());
				}

			} else {
				throw new DAOException("N�o h� dados a serem excluidos.");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,
					"N�o Foi Poss�vel excluir o registro!");

		}
	}

	public FreteTO buscarFrete(String codigo) throws DAOException {

		Connection conn = null;
		Statement sttm = null;
		ResultSet rs = null;

		try {
			FreteTO result = new FreteTO();
			conn = ConnectionBanco.getConnection();
			String sql = "SELECT f.id, f.num_frete, f.hora_lig, f.hora_saida, f.hora_cheg, f.valor, f.data, f.destino, f.motoqueiro FROM frete f WHERE f.id= "
					+ codigo;
			sttm = conn.createStatement();
			rs = sttm.executeQuery(sql);

			while (rs.next()) {

				int id = rs.getInt("id");
				int num_frete = rs.getInt("num_frete");
				String hl = rs.getString("hora_lig");
				String hs = rs.getString("hora_saida");
				String hc = rs.getString("hora_cheg");
				Float vlr = rs.getFloat("valor");
				Date data = rs.getDate("data");
				String destino = rs.getString("destino");
				String motoq = rs.getString("motoqueiro");

				FreteTO frete = new FreteTO();

				frete.setId(id);
				frete.setHoraLig(hl);
				frete.setHoraSaida(hs);
				frete.setNumFrete(num_frete);
				frete.setHoraCheg(hc);
				frete.setValor(vlr);
				frete.setData(data);
				frete.setDestino(destino);
				frete.setMotoq(motoq);
				result = frete;

			}
			sttm.close();
			rs.close();

			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());
		}

	}

	public ArrayList<FreteTO> pesquisarFrete(java.util.Date data, String pesq1,
			String pesq2, Integer pesq3) throws DAOException {

		String comp = "";

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<FreteTO> result = new ArrayList<FreteTO>();
			conn = ConnectionBanco.getConnection();

			if (data != null) {
				String sql = "SELECT f.id, f.num_frete, f.hora_lig, f.hora_saida, f.hora_cheg, f.valor, f.data, f.destino, f.motoqueiro FROM frete f WHERE f.data = ? ORDER BY f.num_frete desc";
				sttm = conn.prepareStatement(sql);
				sttm.setTimestamp(1, new Timestamp(data.getTime()));
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					int num_frete = rs.getInt("num_frete");
					String hl = rs.getString("hora_lig");
					String hs = rs.getString("hora_saida");
					String hc = rs.getString("hora_cheg");
					Float vlr = rs.getFloat("valor");
					Date dat = rs.getDate("data");
					String destino = rs.getString("destino");
					String motoq = rs.getString("motoqueiro");

					FreteTO frete = new FreteTO();

					frete.setId(id);
					frete.setHoraLig(hl);
					frete.setHoraSaida(hs);
					frete.setNumFrete(num_frete);
					frete.setHoraCheg(hc);
					frete.setValor(vlr);
					frete.setData(dat);
					frete.setDestino(destino);
					frete.setMotoq(motoq);
					result.add(frete);

				}

			} else if (!comp.equals(pesq1)) {
				String sql = "SELECT f.id, f.num_frete, f.hora_lig, f.hora_saida, f.hora_cheg, f.valor, f.data, f.destino, f.motoqueiro "
						+ "FROM frete f WHERE f.destino like '%" + pesq1 + "%'";

				sttm = conn.prepareStatement(sql);
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					int num_frete = rs.getInt("num_frete");
					String hl = rs.getString("hora_lig");
					String hs = rs.getString("hora_saida");
					String hc = rs.getString("hora_cheg");
					Float vlr = rs.getFloat("valor");
					Date dat = rs.getDate("data");
					String destino = rs.getString("destino");
					String motoq = rs.getString("motoqueiro");

					FreteTO frete = new FreteTO();

					frete.setId(id);
					frete.setHoraLig(hl);
					frete.setHoraSaida(hs);
					frete.setNumFrete(num_frete);
					frete.setHoraCheg(hc);
					frete.setValor(vlr);
					frete.setData(dat);
					frete.setDestino(destino);
					frete.setMotoq(motoq);
					result.add(frete);

				}

			} else if (!comp.equals(pesq2)) {
				String sql = "SELECT f.id, f.num_frete, f.hora_lig, f.hora_saida, f.hora_cheg, f.valor, f.data, f.destino, f.motoqueiro "
						+ "FROM frete f WHERE f.motoqueiro like '%"
						+ pesq2
						+ "%'";

				sttm = conn.prepareStatement(sql);
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					int num_frete = rs.getInt("num_frete");
					String hl = rs.getString("hora_lig");
					String hs = rs.getString("hora_saida");
					String hc = rs.getString("hora_cheg");
					Float vlr = rs.getFloat("valor");
					Date dat = rs.getDate("data");
					String destino = rs.getString("destino");
					String motoq = rs.getString("motoqueiro");

					FreteTO frete = new FreteTO();

					frete.setId(id);
					frete.setHoraLig(hl);
					frete.setHoraSaida(hs);
					frete.setNumFrete(num_frete);
					frete.setHoraCheg(hc);
					frete.setValor(vlr);
					frete.setData(dat);
					frete.setDestino(destino);
					frete.setMotoq(motoq);
					result.add(frete);

				}
			} else if (pesq3 != null) {
				String sql = "SELECT f.id, f.num_frete, f.hora_lig, f.hora_saida, f.hora_cheg, f.valor, f.data, f.destino, f.motoqueiro "
						+ "FROM frete f WHERE f.num_frete =	" + pesq3;

				sttm = conn.prepareStatement(sql);
				rs = sttm.executeQuery();

				while (rs.next()) {

					int id = rs.getInt("id");
					int num_frete = rs.getInt("num_frete");
					String hl = rs.getString("hora_lig");
					String hs = rs.getString("hora_saida");
					String hc = rs.getString("hora_cheg");
					Float vlr = rs.getFloat("valor");
					Date dat = rs.getDate("data");
					String destino = rs.getString("destino");
					String motoq = rs.getString("motoqueiro");

					FreteTO frete = new FreteTO();

					frete.setId(id);
					frete.setHoraLig(hl);
					frete.setHoraSaida(hs);
					frete.setNumFrete(num_frete);
					frete.setHoraCheg(hc);
					frete.setValor(vlr);
					frete.setData(dat);
					frete.setDestino(destino);
					frete.setMotoq(motoq);
					result.add(frete);

				}

			}
			sttm.close();
			rs.close();

			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());
		}

	}

	public void editarFrete(FreteTO freteTO) throws DAOException {

		Connection conn = null;

		PreparedStatement ps = null;
		if (freteTO != null) {
			try {
				conn = ConnectionBanco.getConnection();
				String sql = " UPDATE frete set num_frete = ?, hora_lig = ?, hora_saida = ?, hora_cheg = ?, valor = ?, data = ?, destino = ?, motoqueiro = ? , mes = ?, id_mes = ? where id = "
						+ freteTO.getId();

				ps = conn.prepareStatement(sql);

				ps.setInt(1, freteTO.getNumFrete());
				ps.setString(2, freteTO.getHoraLig());
				ps.setString(3, freteTO.getHoraSaida());
				ps.setString(4, freteTO.getHoraCheg());
				ps.setFloat(5, freteTO.getValor());
				ps.setDate(6, new Date(freteTO.getData().getTime()));
				ps.setString(7, freteTO.getDestino());
				ps.setString(8, freteTO.getMotoq());
				ps.setString(9, freteTO.getMes());
				ps.setInt(10, freteTO.getNumMes());
				
				ps.executeUpdate();

				ps.close();
			} catch (SQLException e) {
				throw new DAOException(
						"N�o foi poss�vel realizar a atualiza��o do cadastro.\nError: "
								+ e.getMessage());
			}

		} else {
			throw new DAOException("N�o h� dados a serem cadastrados.");
		}
	}

	public ArrayList<FreteTO> listarValorFretes() throws DAOException {

		java.util.Date dtnasc = null;

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<FreteTO> result = new ArrayList<FreteTO>();
			conn = ConnectionBanco.getConnection();
			dtnasc = new java.util.Date();

			String sql = "select f.motoqueiro, sum(valor) as vlr from frete f "
					+ "left outer join motoqueiro o "
					+ "on o.nome = f.motoqueiro where f.data = ?"
					+ "group by f.motoqueiro order by sum(valor) desc";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dtnasc.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				String nome = rs.getString("motoqueiro");
				Float vlrTotal = rs.getFloat("vlr");

				FreteTO frete = new FreteTO();

				frete.setMotoq(nome);
				frete.setValor(vlrTotal);
				result.add(frete);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			e.printStackTrace();
			throw new DAOException("Erro:" + e.getMessage());

		}
	}

	public ArrayList<FreteTO> listarValorFretesTable(JDateChooser dtInic,
			JDateChooser dtFim) throws DAOException {

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<FreteTO> result = new ArrayList<FreteTO>();
			conn = ConnectionBanco.getConnection();
			java.util.Date dataInic = dtInic.getDate();
			java.util.Date dataFim = dtFim.getDate();
			String sql = "select f.motoqueiro, sum(valor) as vlr from frete f "
					+ "left outer join motoqueiro o "
					+ "on o.nome = f.motoqueiro where f.data between ? and ? "
					+ "group by f.motoqueiro order by sum(valor) desc";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dataInic.getTime()));
			sttm.setTimestamp(2, new Timestamp(dataFim.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				String nome = rs.getString("motoqueiro");
				Float vlrTotal = rs.getFloat("vlr");

				FreteTO frete = new FreteTO();

				frete.setMotoq(nome);
				frete.setValor(vlrTotal);
				result.add(frete);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}
	}

	public ArrayList<FreteTO> listarFretesEpocaAnoDia() throws DAOException {

		java.util.Date dtnasc = null;

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<FreteTO> result = new ArrayList<FreteTO>();
			conn = ConnectionBanco.getConnection();
			dtnasc = new java.util.Date();

			String sql = "select f.mes, count(f.data) as qtd from frete f "
					+ "WHERE f.data = ? "
					+ "group by f.mes order by count(f.data) desc";

			sttm = conn.prepareCall(sql);
			sttm.setTimestamp(1, new Timestamp(dtnasc.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				String mes = rs.getString("mes");
				Integer total = rs.getInt("qtd");

				FreteTO frete = new FreteTO();

				frete.setMes(mes);
				frete.setQtd(total);
				result.add(frete);

			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}
	}

	public ArrayList<FreteTO> listarFretesEpocaAno(JDateChooser dtInic,
			JDateChooser dtFim) throws DAOException {

		Connection conn = null;
		PreparedStatement sttm = null;
		ResultSet rs = null;

		try {
			ArrayList<FreteTO> result = new ArrayList<FreteTO>();
			conn = ConnectionBanco.getConnection();
			java.util.Date dataInic = dtInic.getDate();
			java.util.Date dataFim = dtFim.getDate();
			String sql = "select f.id_mes, f.mes, count(f.data) as qtd from frete f "
					+ "where f.data between ? and ? "
					+ "group by f.mes, f.id_mes order by f.id_mes";
			sttm = conn.prepareStatement(sql);
			sttm.setTimestamp(1, new Timestamp(dataInic.getTime()));
			sttm.setTimestamp(2, new Timestamp(dataFim.getTime()));
			rs = sttm.executeQuery();

			while (rs.next()) {

				String mes = rs.getString("mes");
				Integer total = rs.getInt("qtd");
				Integer numMes = rs.getInt("id_mes");
				
				FreteTO frete = new FreteTO();
				frete.setNumMes(numMes);
				frete.setMes(mes);
				frete.setQtd(total);
				result.add(frete);
			}
			sttm.close();
			rs.close();
			return result;

		} catch (SQLException e) {
			throw new DAOException("Erro:" + e.getMessage());

		}
	}
}
