package edu.univas.projeto.tcc.listeners;

import java.util.Date;

public interface ConsultaMotoqueiro {

	public void pesquisar(Date data, String pesq1, String pesq2, Integer pesq3);

	public void incluir();

	public void relacaoTela();

	public void listarTudo();

	public void editar(String codigo);

	public void excluir(String codigo);

	public void fechar();

	public void cancelar();

}
