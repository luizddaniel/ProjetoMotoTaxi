package edu.univas.projeto.tcc.listeners;

import edu.univas.projeto.tcc.model.FreteTO;

public interface DadosFrete {

	public void dadosCancelados();

	public void dadosgravados(FreteTO freteTO);

}
