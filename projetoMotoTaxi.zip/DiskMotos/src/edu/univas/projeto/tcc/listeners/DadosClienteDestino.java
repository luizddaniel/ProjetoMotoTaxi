package edu.univas.projeto.tcc.listeners;

import edu.univas.projeto.tcc.model.ClienteDestinoTO;



public interface DadosClienteDestino {
	
	public void dadosCancelados();
	public void dadosgravados(ClienteDestinoTO clienteDestinoTO);

}
