package edu.univas.projeto.tcc.listeners;

public interface ButtonsCrud {

	public void incluir();

	public void editar(String codigo);

	public void excluir(String codigo);

}
