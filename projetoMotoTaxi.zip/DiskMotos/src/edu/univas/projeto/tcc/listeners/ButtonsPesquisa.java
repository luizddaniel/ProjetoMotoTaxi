package edu.univas.projeto.tcc.listeners;

import java.util.Date;

public interface ButtonsPesquisa {

	public void pesquisar(Date data, String pesq1, String pesq2, Integer pesq3 );
	public void listarTudo();
	public void relacaoTela();
	public void fechar();
}
