package edu.univas.projeto.tcc.listeners;

public interface ButtonsListener {
	
	public void gravar();
	public void cancelar();

}
