package edu.univas.projeto.tcc.listeners;

public interface ButtonsListarListener {
	
	public void fechar();

}
