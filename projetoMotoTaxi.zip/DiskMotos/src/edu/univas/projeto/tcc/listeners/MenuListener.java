package edu.univas.projeto.tcc.listeners;

public interface MenuListener {

	public void cadastrarMot();

	public void cadastrarCliDest();

	public void cadastrarFrete();

	public void relCliMaiSolicServ();

	public void relEpcAnoMaisServ();

	public void relMotMaisServ();

	public void relQtdServSolic();

	public void relBairroMaisSolicServ();

}
