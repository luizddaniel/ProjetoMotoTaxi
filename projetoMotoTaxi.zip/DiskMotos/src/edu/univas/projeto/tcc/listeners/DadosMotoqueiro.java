package edu.univas.projeto.tcc.listeners;

import edu.univas.projeto.tcc.model.MotoqueiroTO;

public interface DadosMotoqueiro {
	
	public void dadosCancelados();
	public void dadosgravados(MotoqueiroTO motoqueiroTO);


}
