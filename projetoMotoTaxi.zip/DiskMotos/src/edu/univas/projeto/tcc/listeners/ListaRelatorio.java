package edu.univas.projeto.tcc.listeners;

import com.toedter.calendar.JDateChooser;

public interface ListaRelatorio {

	public void listar(JDateChooser dtInic, JDateChooser dtFim);
	public void listarTable(JDateChooser dtInic, JDateChooser dtFim);
	
	public void fechar();

}
