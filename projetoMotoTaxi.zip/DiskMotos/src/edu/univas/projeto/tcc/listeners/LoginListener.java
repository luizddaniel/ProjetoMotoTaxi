package edu.univas.projeto.tcc.listeners;

public interface LoginListener {

	public void logar();

}
