package edu.univas.projeto.tcc.listeners;

import edu.univas.projeto.tcc.model.UsuarioTO;


public interface DadosLogin {
	
	public void dadosLogin(UsuarioTO usuario);

}
