package edu.univas.projeto.tcc.listeners;

import edu.univas.projeto.tcc.model.ClienteDestinoTO;
import edu.univas.projeto.tcc.model.FreteTO;
import edu.univas.projeto.tcc.model.MotoqueiroTO;

public interface ListarListener {

	public void listarFrete(FreteTO freteTO);

	public void listarCliente(ClienteDestinoTO clienteDestinoTO);

	public void listarMotoqueiro(MotoqueiroTO motoqueiroTO);

}
