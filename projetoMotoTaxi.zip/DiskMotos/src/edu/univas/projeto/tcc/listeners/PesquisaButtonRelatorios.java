package edu.univas.projeto.tcc.listeners;

import com.toedter.calendar.JDateChooser;

public interface PesquisaButtonRelatorios {

	public void pesquisar(JDateChooser dtInic, JDateChooser dtFim);

	public void pesquisarTale(JDateChooser dtInic, JDateChooser dtFim);

	public void fechar();

}
