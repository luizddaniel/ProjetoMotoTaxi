package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import edu.univas.projeto.tcc.listeners.ButtonsCrud;
import edu.univas.projeto.tcc.listeners.ButtonsListarListener;
import edu.univas.projeto.tcc.listeners.ButtonsPesquisa;
import edu.univas.projeto.tcc.listeners.ConsultaFrete;
import edu.univas.projeto.tcc.model.FreteTO;

public class FrameConsultaFrete extends JFrame {

	private static final long serialVersionUID = 7217142567346284990L;

	private TitledBorder titledBorder;

	private PanelDadosListaFrete panelDadosListaFrete;
	private PanelListaButtons panelListaButtons;
	private PanelButtonsCrud panelButtonsCrud;
	private PanelButtonsPesqFrete panelButtonsPesqFrete;

	private GridBagConstraints panelListaDadosConstraints;
	private GridBagConstraints panelListaButtonsConstraints;
	private GridBagConstraints panelButtonsCrudConstraints;
	private GridBagConstraints panelButtonsPesquisaConstraints;

	private ArrayList<ConsultaFrete> listeners = new ArrayList<ConsultaFrete>();

	public FrameConsultaFrete() {

		super("Consulta Frete ");

		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		initialize();
		pack();
		// setSize(new Dimension(800, 600));
		setResizable(false);
		setLocationRelativeTo(null);
	}

	private void initialize() {

		setLayout(new GridBagLayout());

		add(getPanelButtonsPesqFrete(), getPanelButtonsPesquisaConstraints());
		add(getPanelButtonsCrud(), getPanelButtonsCrudConstraints());
		add(getPanelDadosListaFrete(), getPanelDadosListaFreteConstraints());
		add(getPanelListaButtons(), getPanelListaButtonsConstraints());
	}

	private TitledBorder getTitledBorderPesquisa() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Pesquisar ");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderButtons() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Cadastro ");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderTable() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Dados Frete");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

	private GridBagConstraints getPanelDadosListaFreteConstraints() {
		if (panelListaDadosConstraints == null) {
			panelListaDadosConstraints = createConstraintsPrototype();
			panelListaDadosConstraints.gridx = 0;
			panelListaDadosConstraints.gridy = 2;
		}
		return panelListaDadosConstraints;
	}

	private GridBagConstraints getPanelListaButtonsConstraints() {
		if (panelListaButtonsConstraints == null) {
			panelListaButtonsConstraints = createConstraintsPrototype();
			panelListaButtonsConstraints.gridx = 0;
			panelListaButtonsConstraints.gridy = 3;
		}

		return panelListaButtonsConstraints;
	}

	private GridBagConstraints getPanelButtonsCrudConstraints() {
		if (panelButtonsCrudConstraints == null) {
			panelButtonsCrudConstraints = createConstraintsPrototype();
			panelButtonsCrudConstraints.gridx = 0;
			panelButtonsCrudConstraints.gridy = 1;
		}

		return panelButtonsCrudConstraints;
	}

	private GridBagConstraints getPanelButtonsPesquisaConstraints() {
		if (panelButtonsPesquisaConstraints == null) {
			panelButtonsPesquisaConstraints = createConstraintsPrototype();
			panelButtonsPesquisaConstraints.gridx = 0;
			panelButtonsPesquisaConstraints.gridy = 0;
		}
		return panelButtonsPesquisaConstraints;
	}

	private PanelDadosListaFrete getPanelDadosListaFrete() {
		if (panelDadosListaFrete == null) {
			panelDadosListaFrete = new PanelDadosListaFrete();
			panelDadosListaFrete.setBorder(getTitledBorderTable());
		}
		return panelDadosListaFrete;
	}

	private PanelListaButtons getPanelListaButtons() {
		if (panelListaButtons == null) {
			panelListaButtons = new PanelListaButtons();
			panelListaButtons
					.addButtonsListarListener(new ButtonsListarListener() {

						@Override
						public void fechar() {
							for (ConsultaFrete listener : listeners) {
								listener.fechar();
							}

						}
					});

		}
		return panelListaButtons;
	}

	private PanelButtonsCrud getPanelButtonsCrud() {
		if (panelButtonsCrud == null) {
			panelButtonsCrud = new PanelButtonsCrud();
			panelButtonsCrud.setBorder(getTitledBorderButtons());
			panelButtonsCrud.addButtonsCrud(new ButtonsCrud() {

				@Override
				public void editar(String codigo) {
					panelButtonsCrud.limpa();
					for (ConsultaFrete listener : listeners) {
						listener.editar(codigo);
					}

				}

				@Override
				public void excluir(String codigo) {
					panelButtonsCrud.limpa();
					for (ConsultaFrete listener : listeners) {
						listener.excluir(codigo);
					}

				}

				@Override
				public void incluir() {
					for (ConsultaFrete listener : listeners) {
						listener.incluir();
					}

				}

			});
		}

		return panelButtonsCrud;
	}

	private PanelButtonsPesqFrete getPanelButtonsPesqFrete() {
		if (panelButtonsPesqFrete == null) {
			panelButtonsPesqFrete = new PanelButtonsPesqFrete();
			panelButtonsPesqFrete.setBorder(getTitledBorderPesquisa());
			panelButtonsPesqFrete.addButtonsPesquisa(new ButtonsPesquisa() {

				@Override
				public void fechar() {
					for (ConsultaFrete listener : listeners) {
						listener.cancelar();
					}
				}

				@Override
				public void listarTudo() {
					for (ConsultaFrete listener : listeners) {
						listener.listarTudo();
					}

				}

				@Override
				public void relacaoTela() {
					for (ConsultaFrete listener : listeners) {
						listener.relacaoTela();
					}

				}

				@Override
				public void pesquisar(Date data, String pesq1, String pesq2,
						Integer pesq3) {
					panelButtonsPesqFrete.limpa();
					for (ConsultaFrete listener : listeners) {
						listener.pesquisar(data, pesq1, pesq2, pesq3);
					}

				}

			});
		}
		return panelButtonsPesqFrete;
	}

	public void setDadosFrete(ArrayList<FreteTO> fretes) {
		getPanelDadosListaFrete().setFreteTable(fretes);
	}

	public void limpaDadosFrete() {
		getPanelDadosListaFrete().limparTable();
	}

	public void setDadosFreteTO(FreteTO frete) {
		getPanelDadosListaFrete().setFreteTableModel(frete);
	}

	public void addFrete(ButtonsCrud buttonsCrud) {
		getPanelButtonsCrud().addButtonsCrud(buttonsCrud);

	}

	public void addConsultaFrete(ConsultaFrete listener) {
		listeners.add(listener);
		getPanelDadosListaFrete().addConsultaFrete(listener);
	}
}
