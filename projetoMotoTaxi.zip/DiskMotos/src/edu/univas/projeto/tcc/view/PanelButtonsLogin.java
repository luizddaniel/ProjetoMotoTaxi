package edu.univas.projeto.tcc.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import edu.univas.projeto.tcc.listeners.LoginListener;

public class PanelButtonsLogin extends JPanel {

	private static final long serialVersionUID = -3028233194715422213L;

	private JButton okButton;

	private ArrayList<LoginListener> listeners = new ArrayList<LoginListener>();

	public PanelButtonsLogin() {
		super();
		initialize();
	}

	private void initialize() {
		add(getOkButton());

	}

	private JButton getOkButton() {
		if (okButton == null) {
			URL pathToImage = getClass().getResource(
					"/edu/univas/projeto/tcc/files/confirma.png");
			okButton = new JButton("Login", new ImageIcon(pathToImage));

			okButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					for (LoginListener listener : listeners) {
						listener.logar();
					}
				}

			});
		}
		return okButton;
	}

	public void addButtonsLoginListener(LoginListener listener) {
		if (listener != null) {
			listeners.add(listener);
		}
	}

}
