package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.ListaRelatorio;
import edu.univas.projeto.tcc.listeners.PesquisaButtonRelatorios;
import edu.univas.projeto.tcc.model.MotoqueiroTO;

public class FrameRelatoriosMotoqMaisRealizouServ extends JFrame {

	private static final long serialVersionUID = -8050866604475969851L;

	private PanelDadosListaQtdServPorMotoq panelListaQtdeServPorMotoq;
	private PanelButtonRelatorios panelRelatorios;
	private TitledBorder titledBorder;

	private GridBagConstraints panelListaRelatorioMotoqueiroConstraints;
	private GridBagConstraints panelRelatoriosConstraints;

	private ArrayList<ListaRelatorio> listeners = new ArrayList<ListaRelatorio>();

	public FrameRelatoriosMotoqMaisRealizouServ() {
		super("Rela��o de Motoqueiros que Mais Prestou Servi�os ");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
	}

	private void initialize() {

		setLayout(new GridBagLayout());

		add(getPanelListaRelatorioMotoqueiro(),
				getPanelListaRelatorioMotoqueiroConstraints());
		add(getPanelRelatorios(), getPanelRelatoriosConstraints());

	}

	private TitledBorder getTitledBorderDados() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Dados Motoqueiros");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderButtons() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Pesquisar");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

	private PanelDadosListaQtdServPorMotoq getPanelListaRelatorioMotoqueiro() {
		if (panelListaQtdeServPorMotoq == null) {
			panelListaQtdeServPorMotoq = new PanelDadosListaQtdServPorMotoq();
			panelListaQtdeServPorMotoq.setBorder(getTitledBorderDados());
		}
		return panelListaQtdeServPorMotoq;
	}

	private PanelButtonRelatorios getPanelRelatorios() {
		if (panelRelatorios == null) {
			panelRelatorios = new PanelButtonRelatorios();
			panelRelatorios.setBorder(getTitledBorderButtons());
			panelRelatorios.addButtonsRelatorio(new PesquisaButtonRelatorios() {

				@Override
				public void fechar() {
					for (ListaRelatorio listener : listeners) {
						listener.fechar();
					}

				}

				@Override
				public void pesquisar(JDateChooser dtInic, JDateChooser dtFim) {
					for (ListaRelatorio listener : listeners) {
						listener.listar(dtInic, dtFim);
					}

				}

				@Override
				public void pesquisarTale(JDateChooser dtInic,
						JDateChooser dtFim) {
					for (ListaRelatorio listener : listeners) {
						listener.listarTable(dtInic, dtFim);

					}
				}
			});
		}

		return panelRelatorios;
	}

	private GridBagConstraints getPanelListaRelatorioMotoqueiroConstraints() {
		if (panelListaRelatorioMotoqueiroConstraints == null) {
			panelListaRelatorioMotoqueiroConstraints = createConstraintsPrototype();
			panelListaRelatorioMotoqueiroConstraints.gridx = 0;
			panelListaRelatorioMotoqueiroConstraints.gridy = 1;
		}
		return panelListaRelatorioMotoqueiroConstraints;
	}

	private GridBagConstraints getPanelRelatoriosConstraints() {
		if (panelRelatoriosConstraints == null) {
			panelRelatoriosConstraints = createConstraintsPrototype();
			panelRelatoriosConstraints.gridx = 0;
			panelRelatoriosConstraints.gridy = 0;
		}

		return panelRelatoriosConstraints;
	}

	public void addRelatorioMotoq(ListaRelatorio listener) {
		listeners.add(listener);
		getPanelListaRelatorioMotoqueiro().addListaRelatorioMotoq(listener);
	}

	public void setRelatorioQtdeServPorMotoq(ArrayList<MotoqueiroTO> motoqs) {
		getPanelListaRelatorioMotoqueiro().setMotoqueiroTableRelatorio(motoqs);
	}

	public void limpaDadosTable() {
		getPanelListaRelatorioMotoqueiro().limparTable();

	}

}
