package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.DadosMotoqueiro;
import edu.univas.projeto.tcc.model.MotoqueiroTO;

public class PanelDadosMotoqueiro extends JPanel {

	private static final long serialVersionUID = 6741932651913690111L;

	private JLabel nomeLabel;
	private JTextField nomeTextField;

	private JLabel numMotLabel;
	private JTextField numMotTextField;

	private JLabel enderecoLabel;
	private JTextField enderecoTextField;

	private JLabel numeroLabel;
	private JTextField numeroTextField;

	private JLabel bairroLabel;
	private JTextField bairroTextField;

	private JLabel cidadeLabel;
	private JTextField cidadeTextField;

	private JLabel cepLabel;
	private JTextField cepTextField;

	private JLabel telefoneLabel;
	private JFormattedTextField telefoneTextField;

	private JLabel cpfLabel;
	private JTextField cpfTextField;

	private JLabel rgLabel;
	private JTextField rgTextField;

	private JLabel dtCadastroLabel;
	private JDateChooser dtCadstroChooserField;

	private JLabel tipoSangLabel;
	private JTextField tipoSangTextField;

	private JTextField idTextField;

	private JLabel motoLabel;
	private JTextField motoTextField;

	private JLabel renavanLabel;
	private JTextField renavanTextField;

	private JLabel anoModLabel;
	private JFormattedTextField anoModTextField;

	private JLabel corLabel;
	private JTextField corTextField;

	private JLabel cilindradaLabel;
	private JTextField cilindradaTextField;

	private JLabel placaLabel;
	private JTextField placaTextField;

	private JLabel cnhLabel;
	private JTextField cnhTextField;

	private JLabel categoriaLabel;
	private JTextField categoriaTextField;

	// -----------------Constraints----------------------------------------
	private GridBagConstraints motoLabelConstraints;
	private GridBagConstraints renavanLabelConstraints;
	private GridBagConstraints anoModLabelConstraints;
	private GridBagConstraints corLabelConstraints;
	private GridBagConstraints cilindradaLabelConstraints;
	private GridBagConstraints placaLabelConstraints;
	private GridBagConstraints cnhLabelConstraints;
	private GridBagConstraints categoriaLabelConstraints;

	private GridBagConstraints motoTextFieldConstraints;
	private GridBagConstraints renavanTextFieldConstraints;
	private GridBagConstraints anoModTextFieldConstraints;
	private GridBagConstraints corTextFieldConstraints;
	private GridBagConstraints cilindradaTextFieldConstraints;
	private GridBagConstraints placaTextFieldConstraints;
	private GridBagConstraints cnhTextFieldConstraints;
	private GridBagConstraints categoriaTextFieldConstraints;

	// --------------------------------------------------------
	private GridBagConstraints nomeLabelConstraints;
	private GridBagConstraints numMotLabelConstraints;
	private GridBagConstraints enderecoLabelConstraints;
	private GridBagConstraints numeroLabelConstraints;
	private GridBagConstraints bairroLabelConstraints;
	private GridBagConstraints cidadeLabelConstraints;
	private GridBagConstraints cepLabelConstraints;
	private GridBagConstraints telefoneLabelConstraints;
	private GridBagConstraints cpfLabelConstraints;
	private GridBagConstraints rgLabelConstraints;
	private GridBagConstraints dtcadastroLabelConstraints;
	private GridBagConstraints tipoSangLabelConstraints;

	private GridBagConstraints nomeTextFieldConstraints;
	private GridBagConstraints numMotTextFieldConstraints;
	private GridBagConstraints enderecoTextFieldConstraints;
	private GridBagConstraints numeroTextFieldConstraints;
	private GridBagConstraints bairroTextFieldConstraints;
	private GridBagConstraints cidadeTextFieldConstraints;
	private GridBagConstraints cepTextFieldConstraints;
	private GridBagConstraints telefoneTextFieldConstraints;
	private GridBagConstraints cpfTextFieldConstraints;
	private GridBagConstraints rgTextFieldConstraints;
	private GridBagConstraints dtcadastroTextFieldConstraints;
	private GridBagConstraints tipoSangTextFieldConstraints;

	private MotoqueiroTO motoqueiroTO;

	private ArrayList<DadosMotoqueiro> listeners = new ArrayList<DadosMotoqueiro>();

	public PanelDadosMotoqueiro() {
		super();
		initialize();
	}

	private void initialize() {
		setLayout(new GridBagLayout());

		add(getNomeLabel(), getNomeLabelConstraints());
		add(getNomeTextField(), getNomeTextFieldConstraints());

		add(getNumMotLabel(), getNumMotLabelConstraints());
		add(getNumMotTextField(), getNumMotTextFieldConstraints());

		add(getEnderecoLabel(), getEnderecoLabelConstraints());
		add(getEnderecoTextField(), getEnderecoTextFieldConstraints());

		add(getNumeroLabel(), getNumeroLabelConstraints());
		add(getNumeroTextField(), getNumeroTextFieldConstraints());

		add(getBairroLabel(), getBairroLabelConstraints());
		add(getBairroTextField(), getBairroTextFieldConstraints());

		add(getCidadeLabel(), getCidadeLabelConstraints());
		add(getCidadeTextField(), getCidadeTextFieldConstraints());

		add(getCepLabel(), getCepLabelConstraints());
		add(getCepTextField(), getCepTextFieldConstraints());

		add(getTelefoneLabel(), getTelefoneLabelConstraints());
		add(getTelefoneTextField(), getTelefoneTextFieldConstraints());

		add(getCpfLabel(), getCpfLabelConstraints());
		add(getCpfTextField(), getCpfTextFieldConstraints());

		add(getRgLabel(), getRgLabelConstraints());
		add(getRgTextField(), getRgTextFieldConstraints());

		add(getDtcadastroLabel(), getDtcadastroLabelConstraints());
		add(getDtcadstroTextField(), getDtcadastroTextFieldConstraints());

		add(getTipoSangLabel(), getTipoSangLabelConstraints());
		add(getTiposangTextField(), getTipoSangTextFieldConstraints());

		add(getIdTextField());
		// ----------------------------------
		add(getMotoLabel(), getMotoLabelConstraints());
		add(getMotoTextField(), getMotoTextFieldConstraints());

		add(getRenavanLabel(), getRenavanLabelConstraints());
		add(getRenavanTextField(), getRenavanTextFieldConstraints());

		add(getAnoModLabel(), getAnoModLabelConstraints());
		add(getAnoModTextField(), getAnoModTextFieldConstraints());

		add(getCorLabel(), getCorLabelConstraints());
		add(getCorTextField(), getCorTextFieldConstraints());

		add(getCilindradaLabel(), getCilindradaLabelConstraints());
		add(getCilindradaTextField(), getCilindradaTextFieldConstraints());

		add(getPlacaLabel(), getPlacaLabelConstraints());
		add(getPlacaTextField(), getPlacaTextFieldConstraints());

		add(getCnhLabel(), getCnhLabelConstraints());
		add(getCnhTextField(), getCnhTextFieldConstraints());

		add(getCategoriaLabel(), getCategoriaLabelConstraints());
		add(getCategoriaTextField(), getCategoriaTextFieldConstraints());

	}

	private JLabel getNomeLabel() {
		if (nomeLabel == null) {
			nomeLabel = new JLabel();
			nomeLabel.setText("Nome: ");
		}
		return nomeLabel;
	}

	private JTextField getNomeTextField() {
		if (nomeTextField == null) {
			nomeTextField = new JTextField();
		}
		return nomeTextField;
	}

	private JTextField getIdTextField() {
		if (idTextField == null) {
			idTextField = new JTextField();
			idTextField.setVisible(false);
		}

		return idTextField;
	}

	private JLabel getNumMotLabel() {
		if (numMotLabel == null) {
			numMotLabel = new JLabel();
			numMotLabel.setText("N�mero Motoqueiro: ");

		}
		return numMotLabel;
	}

	private JTextField getNumMotTextField() {
		if (numMotTextField == null) {
			numMotTextField = new JTextField();
		}
		return numMotTextField;
	}

	private JLabel getEnderecoLabel() {
		if (enderecoLabel == null) {
			enderecoLabel = new JLabel();
			enderecoLabel.setText("Endere�o: ");

		}
		return enderecoLabel;
	}

	private JTextField getEnderecoTextField() {
		if (enderecoTextField == null) {
			enderecoTextField = new JTextField();
		}
		return enderecoTextField;
	}

	private JLabel getNumeroLabel() {
		if (numeroLabel == null) {
			numeroLabel = new JLabel();
			numeroLabel.setText("Numero: ");

		}
		return numeroLabel;
	}

	private JTextField getNumeroTextField() {
		if (numeroTextField == null) {
			numeroTextField = new JTextField();
		}
		return numeroTextField;
	}

	private JLabel getBairroLabel() {
		if (bairroLabel == null) {
			bairroLabel = new JLabel();
			bairroLabel.setText("Bairro: ");

		}
		return bairroLabel;
	}

	private JTextField getBairroTextField() {
		if (bairroTextField == null) {
			bairroTextField = new JTextField();
		}
		return bairroTextField;
	}

	private JLabel getCidadeLabel() {
		if (cidadeLabel == null) {
			cidadeLabel = new JLabel();
			cidadeLabel.setText("Cidade: ");

		}
		return cidadeLabel;
	}

	private JTextField getCidadeTextField() {
		if (cidadeTextField == null) {
			cidadeTextField = new JTextField();
		}
		return cidadeTextField;
	}

	private JLabel getCepLabel() {
		if (cepLabel == null) {
			cepLabel = new JLabel();
			cepLabel.setText("CEP: ");

		}
		return cepLabel;
	}

	private JTextField getCepTextField() {
		if (cepTextField == null) {
			cepTextField = new JTextField();
		}
		return cepTextField;
	}

	private JLabel getTelefoneLabel() {
		if (telefoneLabel == null) {
			telefoneLabel = new JLabel();
			telefoneLabel.setText("Telefone: ");

		}
		return telefoneLabel;
	}

	private JFormattedTextField getTelefoneTextField() {
		if (telefoneTextField == null) {
			telefoneTextField = new JFormattedTextField(getFormatterTelefone());
		}
		return telefoneTextField;
	}

	private JLabel getCpfLabel() {
		if (cpfLabel == null) {
			cpfLabel = new JLabel();
			cpfLabel.setText("CPF: ");

		}
		return cpfLabel;
	}

	private JTextField getCpfTextField() {
		if (cpfTextField == null) {
			cpfTextField = new JTextField();
		}
		return cpfTextField;
	}

	private JLabel getRgLabel() {
		if (rgLabel == null) {
			rgLabel = new JLabel();
			rgLabel.setText("Identidade/RG: ");

		}
		return rgLabel;
	}

	private JTextField getRgTextField() {
		if (rgTextField == null) {
			rgTextField = new JTextField();
		}
		return rgTextField;
	}

	private JLabel getDtcadastroLabel() {
		if (dtCadastroLabel == null) {
			dtCadastroLabel = new JLabel();
			dtCadastroLabel.setText("Data Cadastro: ");

		}
		return dtCadastroLabel;
	}

	private JLabel getTipoSangLabel() {
		if (tipoSangLabel == null) {
			tipoSangLabel = new JLabel();
			tipoSangLabel.setText("Tipo Sang.: ");
		}
		return tipoSangLabel;
	}

	private JTextField getTiposangTextField() {
		if (tipoSangTextField == null) {
			tipoSangTextField = new JTextField();
		}
		return tipoSangTextField;
	}

	private JDateChooser getDtcadstroTextField() {
		if (dtCadstroChooserField == null) {
			dtCadstroChooserField = new JDateChooser();
		}
		return dtCadstroChooserField;
	}

	private JLabel getMotoLabel() {
		if (motoLabel == null) {
			motoLabel = new JLabel();
			motoLabel.setText("Moto: ");
		}
		return motoLabel;
	}

	private JTextField getMotoTextField() {
		if (motoTextField == null) {
			motoTextField = new JTextField();
		}

		return motoTextField;
	}

	private JLabel getRenavanLabel() {
		if (renavanLabel == null) {
			renavanLabel = new JLabel();
			renavanLabel.setText("Renavan: ");
		}

		return renavanLabel;
	}

	private JTextField getRenavanTextField() {
		if (renavanTextField == null) {
			renavanTextField = new JTextField();
		}

		return renavanTextField;
	}

	private JLabel getAnoModLabel() {
		if (anoModLabel == null) {
			anoModLabel = new JLabel();
			anoModLabel.setText("Ano/Modelo: ");
		}

		return anoModLabel;
	}

	private JTextField getAnoModTextField() {
		if (anoModTextField == null) {
			anoModTextField = new JFormattedTextField(getFormatterAno_Modelo());
		}

		return anoModTextField;
	}

	private JLabel getCorLabel() {
		if (corLabel == null) {
			corLabel = new JLabel();
			corLabel.setText("Cor: ");
		}

		return corLabel;
	}

	private JTextField getCorTextField() {
		if (corTextField == null) {
			corTextField = new JTextField();
		}

		return corTextField;
	}

	private JLabel getCilindradaLabel() {
		if (cilindradaLabel == null) {
			cilindradaLabel = new JLabel();
			cilindradaLabel.setText("Cilindrada: ");
		}

		return cilindradaLabel;
	}

	private JTextField getCilindradaTextField() {
		if (cilindradaTextField == null) {
			cilindradaTextField = new JTextField();
		}

		return cilindradaTextField;
	}

	private JLabel getPlacaLabel() {
		if (placaLabel == null) {
			placaLabel = new JLabel();
			placaLabel.setText("Placa: ");
		}

		return placaLabel;
	}

	private JTextField getPlacaTextField() {
		if (placaTextField == null) {
			placaTextField = new JTextField();
		}

		return placaTextField;
	}

	private JLabel getCnhLabel() {
		if (cnhLabel == null) {
			cnhLabel = new JLabel();
			cnhLabel.setText("CNH: ");
		}

		return cnhLabel;
	}

	private JTextField getCnhTextField() {
		if (cnhTextField == null) {
			cnhTextField = new JTextField();
		}

		return cnhTextField;
	}

	private JLabel getCategoriaLabel() {
		if (categoriaLabel == null) {
			categoriaLabel = new JLabel();
			categoriaLabel.setText("Categoria: ");
		}

		return categoriaLabel;
	}

	private JTextField getCategoriaTextField() {
		if (categoriaTextField == null) {
			categoriaTextField = new JTextField();
		}

		return categoriaTextField;
	}

	private GridBagConstraints getTipoSangLabelConstraints() {
		if (tipoSangLabelConstraints == null) {
			tipoSangLabelConstraints = createConstraintsPrototype();
			tipoSangLabelConstraints.gridx = 3;
			tipoSangLabelConstraints.gridy = 5;
		}

		return tipoSangLabelConstraints;
	}

	private GridBagConstraints getTipoSangTextFieldConstraints() {
		if (tipoSangTextFieldConstraints == null) {
			tipoSangTextFieldConstraints = createConstraintsPrototype();
			tipoSangTextFieldConstraints.gridx = 4;
			tipoSangTextFieldConstraints.gridy = 5;
			tipoSangTextFieldConstraints.ipadx = 100;
		}
		return tipoSangTextFieldConstraints;
	}

	private GridBagConstraints getMotoLabelConstraints() {
		if (motoLabelConstraints == null) {
			motoLabelConstraints = createConstraintsPrototype();
			motoLabelConstraints.gridx = 0;
			motoLabelConstraints.gridy = 6;
		}
		return motoLabelConstraints;
	}

	private GridBagConstraints getRenavanLabelConstraints() {
		if (renavanLabelConstraints == null) {
			renavanLabelConstraints = createConstraintsPrototype();
			renavanLabelConstraints.gridx = 2;
			renavanLabelConstraints.gridy = 6;
		}
		return renavanLabelConstraints;
	}

	private GridBagConstraints getAnoModLabelConstraints() {
		if (anoModLabelConstraints == null) {
			anoModLabelConstraints = createConstraintsPrototype();
			anoModLabelConstraints.gridx = 4;
			anoModLabelConstraints.gridy = 6;
		}
		return anoModLabelConstraints;
	}

	private GridBagConstraints getCorLabelConstraints() {
		if (corLabelConstraints == null) {
			corLabelConstraints = createConstraintsPrototype();
			corLabelConstraints.gridx = 0;
			corLabelConstraints.gridy = 7;
		}
		return corLabelConstraints;
	}

	private GridBagConstraints getCilindradaLabelConstraints() {
		if (cilindradaLabelConstraints == null) {
			cilindradaLabelConstraints = createConstraintsPrototype();
			cilindradaLabelConstraints.gridx = 2;
			cilindradaLabelConstraints.gridy = 7;
		}
		return cilindradaLabelConstraints;
	}

	private GridBagConstraints getPlacaLabelConstraints() {
		if (placaLabelConstraints == null) {
			placaLabelConstraints = createConstraintsPrototype();
			placaLabelConstraints.gridx = 4;
			placaLabelConstraints.gridy = 7;
		}
		return placaLabelConstraints;
	}

	private GridBagConstraints getCnhLabelConstraints() {
		if (cnhLabelConstraints == null) {
			cnhLabelConstraints = createConstraintsPrototype();
			cnhLabelConstraints.gridx = 0;
			cnhLabelConstraints.gridy = 8;
		}
		return cnhLabelConstraints;
	}

	private GridBagConstraints getCategoriaLabelConstraints() {
		if (categoriaLabelConstraints == null) {
			categoriaLabelConstraints = createConstraintsPrototype();
			categoriaLabelConstraints.gridx = 2;
			categoriaLabelConstraints.gridy = 8;
		}
		return categoriaLabelConstraints;
	}

	private GridBagConstraints getMotoTextFieldConstraints() {
		if (motoTextFieldConstraints == null) {
			motoTextFieldConstraints = createConstraintsPrototype();
			motoTextFieldConstraints.gridx = 1;
			motoTextFieldConstraints.gridy = 6;
			motoTextFieldConstraints.ipadx = 100;
		}

		return motoTextFieldConstraints;
	}

	private GridBagConstraints getRenavanTextFieldConstraints() {
		if (renavanTextFieldConstraints == null) {
			renavanTextFieldConstraints = createConstraintsPrototype();
			renavanTextFieldConstraints.gridx = 3;
			renavanTextFieldConstraints.gridy = 6;
			renavanTextFieldConstraints.ipadx = 100;
		}

		return renavanTextFieldConstraints;
	}

	private GridBagConstraints getAnoModTextFieldConstraints() {
		if (anoModTextFieldConstraints == null) {
			anoModTextFieldConstraints = createConstraintsPrototype();
			anoModTextFieldConstraints.gridx = 5;
			anoModTextFieldConstraints.gridy = 6;
			anoModTextFieldConstraints.ipadx = 100;
		}

		return anoModTextFieldConstraints;
	}

	private GridBagConstraints getCorTextFieldConstraints() {
		if (corTextFieldConstraints == null) {
			corTextFieldConstraints = createConstraintsPrototype();
			corTextFieldConstraints.gridx = 1;
			corTextFieldConstraints.gridy = 7;
			corTextFieldConstraints.ipadx = 100;
		}

		return corTextFieldConstraints;
	}

	private GridBagConstraints getCilindradaTextFieldConstraints() {
		if (cilindradaTextFieldConstraints == null) {
			cilindradaTextFieldConstraints = createConstraintsPrototype();
			cilindradaTextFieldConstraints.gridx = 3;
			cilindradaTextFieldConstraints.gridy = 7;
			cilindradaTextFieldConstraints.ipadx = 100;
		}

		return cilindradaTextFieldConstraints;
	}

	private GridBagConstraints getPlacaTextFieldConstraints() {
		if (placaTextFieldConstraints == null) {
			placaTextFieldConstraints = createConstraintsPrototype();
			placaTextFieldConstraints.gridx = 5;
			placaTextFieldConstraints.gridy = 7;
			placaTextFieldConstraints.ipadx = 100;
		}

		return placaTextFieldConstraints;
	}

	private GridBagConstraints getCnhTextFieldConstraints() {
		if (cnhTextFieldConstraints == null) {
			cnhTextFieldConstraints = createConstraintsPrototype();
			cnhTextFieldConstraints.gridx = 1;
			cnhTextFieldConstraints.gridy = 8;
			cnhTextFieldConstraints.ipadx = 100;
		}

		return cnhTextFieldConstraints;
	}

	private GridBagConstraints getCategoriaTextFieldConstraints() {
		if (categoriaTextFieldConstraints == null) {
			categoriaTextFieldConstraints = createConstraintsPrototype();
			categoriaTextFieldConstraints.gridx = 3;
			categoriaTextFieldConstraints.gridy = 8;
			categoriaTextFieldConstraints.ipadx = 100;
		}

		return categoriaTextFieldConstraints;
	}

	private GridBagConstraints getNomeLabelConstraints() {
		if (nomeLabelConstraints == null) {
			nomeLabelConstraints = createConstraintsPrototype();
			nomeLabelConstraints.gridx = 0;
			nomeLabelConstraints.gridy = 0;
		}
		return nomeLabelConstraints;
	}

	private GridBagConstraints getEnderecoLabelConstraints() {
		if (enderecoLabelConstraints == null) {
			enderecoLabelConstraints = createConstraintsPrototype();
			enderecoLabelConstraints.gridx = 0;
			enderecoLabelConstraints.gridy = 1;
		}
		return enderecoLabelConstraints;
	}

	private GridBagConstraints getNumeroLabelConstraints() {
		if (numeroLabelConstraints == null) {
			numeroLabelConstraints = createConstraintsPrototype();
			numeroLabelConstraints.gridx = 4;
			numeroLabelConstraints.gridy = 1;
		}
		return numeroLabelConstraints;
	}

	private GridBagConstraints getBairroLabelConstraints() {
		if (bairroLabelConstraints == null) {
			bairroLabelConstraints = createConstraintsPrototype();
			bairroLabelConstraints.gridx = 0;
			bairroLabelConstraints.gridy = 2;
		}
		return bairroLabelConstraints;
	}

	private GridBagConstraints getCidadeLabelConstraints() {
		if (cidadeLabelConstraints == null) {
			cidadeLabelConstraints = createConstraintsPrototype();
			cidadeLabelConstraints.gridx = 3;
			cidadeLabelConstraints.gridy = 2;
		}
		return cidadeLabelConstraints;
	}

	private GridBagConstraints getCepLabelConstraints() {
		if (cepLabelConstraints == null) {
			cepLabelConstraints = createConstraintsPrototype();
			cepLabelConstraints.gridx = 0;
			cepLabelConstraints.gridy = 3;
		}
		return cepLabelConstraints;
	}

	private GridBagConstraints getTelefoneLabelConstraints() {
		if (telefoneLabelConstraints == null) {
			telefoneLabelConstraints = createConstraintsPrototype();
			telefoneLabelConstraints.gridx = 3;
			telefoneLabelConstraints.gridy = 3;
		}
		return telefoneLabelConstraints;
	}

	private GridBagConstraints getCpfLabelConstraints() {
		if (cpfLabelConstraints == null) {
			cpfLabelConstraints = createConstraintsPrototype();
			cpfLabelConstraints.gridx = 0;
			cpfLabelConstraints.gridy = 4;
		}
		return cpfLabelConstraints;
	}

	private GridBagConstraints getRgLabelConstraints() {
		if (rgLabelConstraints == null) {
			rgLabelConstraints = createConstraintsPrototype();
			rgLabelConstraints.gridx = 3;
			rgLabelConstraints.gridy = 4;
		}
		return rgLabelConstraints;
	}

	private GridBagConstraints getNumMotLabelConstraints() {
		if (numMotLabelConstraints == null) {
			numMotLabelConstraints = createConstraintsPrototype();
			numMotLabelConstraints.gridx = 4;
			numMotLabelConstraints.gridy = 0;
		}
		return numMotLabelConstraints;
	}

	private GridBagConstraints getDtcadastroLabelConstraints() {
		if (dtcadastroLabelConstraints == null) {
			dtcadastroLabelConstraints = createConstraintsPrototype();
			dtcadastroLabelConstraints.gridx = 0;
			dtcadastroLabelConstraints.gridy = 5;
		}
		return dtcadastroLabelConstraints;
	}

	private GridBagConstraints getNomeTextFieldConstraints() {
		if (nomeTextFieldConstraints == null) {
			nomeTextFieldConstraints = createConstraintsPrototype();
			nomeTextFieldConstraints.gridx = 1;
			nomeTextFieldConstraints.gridy = 0;
			nomeTextFieldConstraints.gridwidth = 3;
		}
		return nomeTextFieldConstraints;
	}

	private GridBagConstraints getEnderecoTextFieldConstraints() {
		if (enderecoTextFieldConstraints == null) {
			enderecoTextFieldConstraints = createConstraintsPrototype();
			enderecoTextFieldConstraints.gridx = 1;
			enderecoTextFieldConstraints.gridy = 1;
			enderecoTextFieldConstraints.gridwidth = 3;
		}
		return enderecoTextFieldConstraints;
	}

	private GridBagConstraints getNumeroTextFieldConstraints() {
		if (numeroTextFieldConstraints == null) {
			numeroTextFieldConstraints = createConstraintsPrototype();
			numeroTextFieldConstraints.gridx = 5;
			numeroTextFieldConstraints.gridy = 1;
			numeroTextFieldConstraints.ipadx = 100;
		}
		return numeroTextFieldConstraints;
	}

	private GridBagConstraints getBairroTextFieldConstraints() {
		if (bairroTextFieldConstraints == null) {
			bairroTextFieldConstraints = createConstraintsPrototype();
			bairroTextFieldConstraints.gridx = 1;
			bairroTextFieldConstraints.gridy = 2;
			bairroTextFieldConstraints.gridwidth = 2;
			bairroTextFieldConstraints.ipadx = 200;
		}
		return bairroTextFieldConstraints;
	}

	private GridBagConstraints getCidadeTextFieldConstraints() {
		if (cidadeTextFieldConstraints == null) {
			cidadeTextFieldConstraints = createConstraintsPrototype();
			cidadeTextFieldConstraints.gridx = 4;
			cidadeTextFieldConstraints.gridy = 2;
			cidadeTextFieldConstraints.gridwidth = 2;
		}
		return cidadeTextFieldConstraints;
	}

	private GridBagConstraints getCepTextFieldConstraints() {
		if (cepTextFieldConstraints == null) {
			cepTextFieldConstraints = createConstraintsPrototype();
			cepTextFieldConstraints.gridx = 1;
			cepTextFieldConstraints.gridy = 3;
			cepTextFieldConstraints.gridwidth = 2;
		}
		return cepTextFieldConstraints;
	}

	private GridBagConstraints getTelefoneTextFieldConstraints() {
		if (telefoneTextFieldConstraints == null) {
			telefoneTextFieldConstraints = createConstraintsPrototype();
			telefoneTextFieldConstraints.gridx = 4;
			telefoneTextFieldConstraints.gridy = 3;
			telefoneTextFieldConstraints.gridwidth = 2;
		}
		return telefoneTextFieldConstraints;
	}

	private GridBagConstraints getCpfTextFieldConstraints() {
		if (cpfTextFieldConstraints == null) {
			cpfTextFieldConstraints = createConstraintsPrototype();
			cpfTextFieldConstraints.gridx = 1;
			cpfTextFieldConstraints.gridy = 4;
			cpfTextFieldConstraints.gridwidth = 2;
		}
		return cpfTextFieldConstraints;
	}

	private GridBagConstraints getRgTextFieldConstraints() {
		if (rgTextFieldConstraints == null) {
			rgTextFieldConstraints = createConstraintsPrototype();
			rgTextFieldConstraints.gridx = 4;
			rgTextFieldConstraints.gridy = 4;
			rgTextFieldConstraints.gridwidth = 2;
		}
		return rgTextFieldConstraints;
	}

	private GridBagConstraints getNumMotTextFieldConstraints() {
		if (numMotTextFieldConstraints == null) {
			numMotTextFieldConstraints = createConstraintsPrototype();
			numMotTextFieldConstraints.gridx = 5;
			numMotTextFieldConstraints.gridy = 0;
			numMotTextFieldConstraints.ipadx = 100;
		}
		return numMotTextFieldConstraints;
	}

	private GridBagConstraints getDtcadastroTextFieldConstraints() {
		if (dtcadastroTextFieldConstraints == null) {
			dtcadastroTextFieldConstraints = createConstraintsPrototype();
			dtcadastroTextFieldConstraints.gridx = 1;
			dtcadastroTextFieldConstraints.gridy = 5;
			dtcadastroTextFieldConstraints.gridwidth = 2;
		}
		return dtcadastroTextFieldConstraints;
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

	private MaskFormatter getFormatterTelefone() {
		try {
			MaskFormatter formatter = new MaskFormatter();
			formatter.setMask("(##)####-####");
			formatter.setPlaceholderCharacter('_');
			return formatter;
		} catch (ParseException e) {
			return new MaskFormatter();
		}
	}

	private MaskFormatter getFormatterAno_Modelo() {
		try {
			MaskFormatter formatter = new MaskFormatter();
			formatter.setMask("####/####");
			formatter.setPlaceholderCharacter('_');
			return formatter;
		} catch (ParseException e) {
			return new MaskFormatter();
		}
	}

	public MotoqueiroTO getMotoqueiroTO() {
		if (motoqueiroTO == null) {
			motoqueiroTO = new MotoqueiroTO();
		}

		motoqueiroTO.setNome(getNomeTextField().getText());
		motoqueiroTO.setEndereco(getEnderecoTextField().getText());
		motoqueiroTO.setBairro(getBairroTextField().getText());
		motoqueiroTO.setCidade(getCidadeTextField().getText());
		motoqueiroTO.setCep(getCepTextField().getText());
		motoqueiroTO.setTelefone(getTelefoneTextField().getText());
		motoqueiroTO.setCpf(getCpfTextField().getText());
		motoqueiroTO.setRg(getRgTextField().getText());
		motoqueiroTO.setMoto(getMotoTextField().getText());
		motoqueiroTO.setRenavan(getRenavanTextField().getText());
		motoqueiroTO.setAnoModelo(getAnoModTextField().getText());
		motoqueiroTO.setCor(getCorTextField().getText());
		motoqueiroTO.setCilindrada(getCilindradaTextField().getText());
		motoqueiroTO.setPlacaMoto(getPlacaTextField().getText());
		motoqueiroTO.setCnh(getCnhTextField().getText());
		motoqueiroTO.setCategoria(getCategoriaTextField().getText());
		motoqueiroTO.setTipoSang(getTiposangTextField().getText());
		motoqueiroTO.setData(getDtcadstroTextField().getDate());

		if (!lernumero(motoqueiroTO) || !lerNum_Mot(motoqueiroTO)) {
			return null;
		}
		return motoqueiroTO;
	}

	public void setMotoqueiroTO(MotoqueiroTO motoquerioTO) {

		getIdTextField().setText(Integer.toString(motoquerioTO.getId()));
		getNomeTextField().setText(motoquerioTO.getNome());
		getEnderecoTextField().setText(motoquerioTO.getEndereco());
		getNumeroTextField()
				.setText(Integer.toString(motoquerioTO.getNumero()));
		getNumMotTextField().setText(
				Integer.toString(motoquerioTO.getNumMotoq()));
		getBairroTextField().setText(motoquerioTO.getBairro());
		getCidadeTextField().setText(motoquerioTO.getCidade());
		getCepTextField().setText(motoquerioTO.getCep());
		getTelefoneTextField().setText(motoquerioTO.getTelefone());
		getCpfTextField().setText(motoquerioTO.getCpf());
		getRgTextField().setText(motoquerioTO.getRg());
		getMotoTextField().setText(motoquerioTO.getMoto());
		getRenavanTextField().setText(motoquerioTO.getRenavan());
		getAnoModTextField().setText(motoquerioTO.getAnoModelo());
		getCorTextField().setText(motoquerioTO.getCor());
		getCilindradaTextField().setText(motoquerioTO.getCilindrada());
		getPlacaTextField().setText(motoquerioTO.getPlacaMoto());
		getCnhTextField().setText(motoquerioTO.getCnh());
		getCategoriaTextField().setText(motoquerioTO.getCategoria());
		getTiposangTextField().setText(motoquerioTO.getTipoSang());
		getDtcadstroTextField().setDate(motoquerioTO.getData());
	}

	public MotoqueiroTO getEditarMotoqueiroTO() {
		if (motoqueiroTO == null) {
			motoqueiroTO = new MotoqueiroTO();
		}
		motoqueiroTO.setId(Integer.parseInt(getIdTextField().getText()));
		motoqueiroTO.setNome(getNomeTextField().getText());
		motoqueiroTO.setEndereco(getEnderecoTextField().getText());
		motoqueiroTO.setBairro(getBairroTextField().getText());
		motoqueiroTO.setCidade(getCidadeTextField().getText());
		motoqueiroTO.setCep(getCepTextField().getText());
		motoqueiroTO.setTelefone(getTelefoneTextField().getText());
		motoqueiroTO.setCpf(getCpfTextField().getText());
		motoqueiroTO.setRg(getRgTextField().getText());
		motoqueiroTO.setMoto(getMotoTextField().getText());
		motoqueiroTO.setRenavan(getRenavanTextField().getText());
		motoqueiroTO.setAnoModelo(getAnoModTextField().getText());
		motoqueiroTO.setCor(getCorTextField().getText());
		motoqueiroTO.setCilindrada(getCilindradaTextField().getText());
		motoqueiroTO.setPlacaMoto(getPlacaTextField().getText());
		motoqueiroTO.setCnh(getCnhTextField().getText());
		motoqueiroTO.setCategoria(getCategoriaTextField().getText());
		motoqueiroTO.setTipoSang(getTiposangTextField().getText());
		motoqueiroTO.setData(getDtcadstroTextField().getDate());

		if (!lernumero(motoqueiroTO) || !lerNum_Mot(motoqueiroTO)) {
			return null;
		}
		return motoqueiroTO;

	}

	private boolean lernumero(MotoqueiroTO motoqueiroTO) {

		String num = "";

		try {
			num = getNumeroTextField().getText();
			Integer numero = Integer.parseInt(num);
			motoqueiroTO.setNumero(numero);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,
					"Favor � obrigat�rio preencher o campo numero da casa");
			return false;
		}
		return true;
	}

	public void setData() {
		getDtcadstroTextField().setDate(new Date());
		getAnoModTextField().setText("2011/2011");
		getCategoriaTextField().setText("A");
		getCepTextField().setText("37550-000");
		getCilindradaTextField().setText("125cc");
		getCidadeTextField().setText("Pouso Alegre");
	}

	private boolean lerNum_Mot(MotoqueiroTO motoqueiroTO) {

		String num = "";

		try {
			num = getNumMotTextField().getText();
			Integer numero = Integer.parseInt(num);
			motoqueiroTO.setNumMotoq(numero);
		} catch (Exception e) {
			JOptionPane
					.showMessageDialog(null,
							"Favor � obrigat�rio preencher o campo numero do motoqueiro");
			return false;
		}
		return true;
	}

	public void addDadosMotoqueiro(DadosMotoqueiro listener) {
		listeners.add(listener);
	}

}
