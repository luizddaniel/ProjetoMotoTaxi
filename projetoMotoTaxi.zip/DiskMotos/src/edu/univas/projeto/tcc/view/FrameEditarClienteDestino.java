package edu.univas.projeto.tcc.view;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import edu.univas.projeto.tcc.listeners.ButtonsListener;
import edu.univas.projeto.tcc.listeners.DadosClienteDestino;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;

public class FrameEditarClienteDestino extends JFrame {

	private static final long serialVersionUID = 5666635636392297892L;

	private PanelDadosClienteDestino panelDadosClienteDestino;
	private PanelButtons panelButtons;
	private TitledBorder titledBorder;

	private ArrayList<DadosClienteDestino> listeners = new ArrayList<DadosClienteDestino>();

	public FrameEditarClienteDestino() {

		super("Editar Corridas ");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		initialize();

		pack();

		setLocationRelativeTo(null);

	}

	private void initialize() {

		add(getPanelDadosClienteDestino(), BorderLayout.CENTER);
		add(getPanelButtons(), BorderLayout.SOUTH);

	}

	private TitledBorder getTitledBorderDados() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory
				.createTitledBorder(loweredetched, "Dados ");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderButtons() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched, "");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	public PanelDadosClienteDestino getPanelDadosClienteDestino() {
		if (panelDadosClienteDestino == null) {
			panelDadosClienteDestino = new PanelDadosClienteDestino();
			panelDadosClienteDestino.setBorder(getTitledBorderDados());
		}
		return panelDadosClienteDestino;
	}

	private PanelButtons getPanelButtons() {
		if (panelButtons == null) {
			panelButtons = new PanelButtons();
			panelButtons.setBorder(getTitledBorderButtons());
			panelButtons.addButtonsListener(new ButtonsListener() {

				@Override
				public void cancelar() {
					for (DadosClienteDestino listener : listeners) {
						listener.dadosCancelados();
					}

				}

				@Override
				public void gravar() {

					ClienteDestinoTO clienteDestinoTO = getPanelDadosClienteDestino()
							.getEditarClienteDestinoTO();
					if (clienteDestinoTO != null) {
						for (DadosClienteDestino listener : listeners) {
							listener.dadosgravados(clienteDestinoTO);
						}

					}

				}

			});
		}
		return panelButtons;
	}

	public void addDadosEdicaoFrete(DadosClienteDestino listener) {
		listeners.add(listener);
		getPanelDadosClienteDestino().addDadosClienteDest(listener);
	}

}
