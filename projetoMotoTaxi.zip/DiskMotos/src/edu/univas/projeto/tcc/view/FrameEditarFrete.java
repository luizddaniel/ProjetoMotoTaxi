package edu.univas.projeto.tcc.view;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import edu.univas.projeto.tcc.listeners.ButtonsListener;
import edu.univas.projeto.tcc.listeners.DadosFrete;
import edu.univas.projeto.tcc.model.FreteTO;

public class FrameEditarFrete extends JFrame {

	private static final long serialVersionUID = 233226304495596032L;

	private PanelFinalizarFrete panelFinalizarFrete;
	private PanelButtons panelButtons;
	private TitledBorder titledBorder;

	private ArrayList<DadosFrete> listeners = new ArrayList<DadosFrete>();

	public FrameEditarFrete() {
		super("Editar Fretes ");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		initialize();

		pack();

		setLocationRelativeTo(null);

	}

	private void initialize() {

		add(getPanelDadosFrete(), BorderLayout.CENTER);
		add(getPanelButtons(), BorderLayout.SOUTH);

	}

	private TitledBorder getTitledBorderDados() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory
				.createTitledBorder(loweredetched, "Dados ");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderButtons() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched, "");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	public PanelFinalizarFrete getPanelDadosFrete() {
		if (panelFinalizarFrete == null) {
			panelFinalizarFrete = new PanelFinalizarFrete();
			panelFinalizarFrete.setBorder(getTitledBorderDados());
		}
		return panelFinalizarFrete;
	}

	private PanelButtons getPanelButtons() {
		if (panelButtons == null) {
			panelButtons = new PanelButtons();
			panelButtons.setBorder(getTitledBorderButtons());
			panelButtons.addButtonsListener(new ButtonsListener() {

				@Override
				public void cancelar() {
					for (DadosFrete listener : listeners) {
						listener.dadosCancelados();
					}

				}

				@Override
				public void gravar() {
					FreteTO freteTO = getPanelDadosFrete().getEditarFreteTO();
					if (freteTO != null) {
						for (DadosFrete listener : listeners) {
							listener.dadosgravados(freteTO);
						}

					}

				}

			});
		}
		return panelButtons;
	}

	public void addDadosEdicaoFrete(DadosFrete listener) {
		listeners.add(listener);
		getPanelDadosFrete().addDadosFrete(listener);
	}

}
