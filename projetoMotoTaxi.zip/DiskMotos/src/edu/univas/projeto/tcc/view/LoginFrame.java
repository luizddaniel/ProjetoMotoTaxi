package edu.univas.projeto.tcc.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import edu.univas.projeto.tcc.listeners.DadosLogin;
import edu.univas.projeto.tcc.listeners.LoginListener;
import edu.univas.projeto.tcc.model.UsuarioTO;

public class LoginFrame extends JFrame {

	private static final long serialVersionUID = 1L;

	private PanelDadosLogin panelDadosLogin;
	private PanelButtonsLogin panelButtonsLogin;
	private TitledBorder titledBorder;

	private ArrayList<DadosLogin> loginListeners = new ArrayList<DadosLogin>();

	public LoginFrame() {
		super("Login");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		initialize();
		setSize(new Dimension(220, 160));

	}

	private void initialize() {
		add(getPanelDadosLogin(), BorderLayout.CENTER);
		add(getPanelButtonsLogin(), BorderLayout.SOUTH);

	}

	private TitledBorder getTitledBorderDados() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory
				.createTitledBorder(loweredetched, "Login ");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderButtons() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched, "");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private PanelDadosLogin getPanelDadosLogin() {
		if (panelDadosLogin == null) {
			panelDadosLogin = new PanelDadosLogin();
			panelDadosLogin.setBorder(getTitledBorderDados());

		}
		return panelDadosLogin;
	}

	private PanelButtonsLogin getPanelButtonsLogin() {
		if (panelButtonsLogin == null) {
			panelButtonsLogin = new PanelButtonsLogin();
			panelButtonsLogin.setBorder(getTitledBorderButtons());
			panelButtonsLogin.addButtonsLoginListener(new LoginListener() {

				@Override
				public void logar() {
					UsuarioTO usuarioTO = panelDadosLogin.getUsuarioTO();
					for (DadosLogin listener : loginListeners) {
						listener.dadosLogin(usuarioTO);
					}
				}

			});
		}
		return panelButtonsLogin;
	}

	public void addLoginListener(DadosLogin listener) {
		loginListeners.add(listener);
	}

}
