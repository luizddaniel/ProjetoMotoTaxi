package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import edu.univas.projeto.tcc.listeners.ButtonsCrud;
import edu.univas.projeto.tcc.listeners.ButtonsListarListener;
import edu.univas.projeto.tcc.listeners.ButtonsPesquisa;
import edu.univas.projeto.tcc.listeners.ConsultaMotoqueiro;
import edu.univas.projeto.tcc.model.MotoqueiroTO;

public class FrameConsultaMotoqueiro extends JFrame {

	private static final long serialVersionUID = -9058620370714082608L;

	private TitledBorder titledBorder;
	private PanelDadosListaMotoqueiro panelDadosListaMotoqueiro;
	private PanelListaButtons panelListaButtons;
	private PanelButtonsCrud panelButtonsCrud;
	private PanelButtonsPesqMotoq panelButtonsPesqMotoq;

	private GridBagConstraints panelListaDadosConstraints;
	private GridBagConstraints panelListaButtonsConstraints;
	private GridBagConstraints panelButtonsCrudConstraints;
	private GridBagConstraints panelButtonsPesquisaConstraints;

	private ArrayList<ConsultaMotoqueiro> listeners = new ArrayList<ConsultaMotoqueiro>();

	public FrameConsultaMotoqueiro() {

		super("Consulta Motoqueiro ");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
	}

	private void initialize() {

		setLayout(new GridBagLayout());

		add(getPanelButtonsPesquisa(), getPanelButtonsPesquisaConstraints());
		add(getPanelButtonsCrud(), getPanelButtonsCrudConstraints());
		add(getPanelDadosListaMotoqueiro(),
				getPanelDadosListaMotoqueiroConstraints());
		add(getPanelListaButtons(), getPanelListaButtonsConstraints());
	}

	private TitledBorder getTitledBorderPesquisa() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Pesquisar ");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderButtons() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Cadastro ");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderTable() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Dados Motoqueiro");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

	private GridBagConstraints getPanelDadosListaMotoqueiroConstraints() {
		if (panelListaDadosConstraints == null) {
			panelListaDadosConstraints = createConstraintsPrototype();
			panelListaDadosConstraints.gridx = 0;
			panelListaDadosConstraints.gridy = 2;
		}
		return panelListaDadosConstraints;
	}

	private GridBagConstraints getPanelListaButtonsConstraints() {
		if (panelListaButtonsConstraints == null) {
			panelListaButtonsConstraints = createConstraintsPrototype();
			panelListaButtonsConstraints.gridx = 0;
			panelListaButtonsConstraints.gridy = 3;
		}

		return panelListaButtonsConstraints;
	}

	private GridBagConstraints getPanelButtonsCrudConstraints() {
		if (panelButtonsCrudConstraints == null) {
			panelButtonsCrudConstraints = createConstraintsPrototype();
			panelButtonsCrudConstraints.gridx = 0;
			panelButtonsCrudConstraints.gridy = 1;
		}

		return panelButtonsCrudConstraints;
	}

	private GridBagConstraints getPanelButtonsPesquisaConstraints() {
		if (panelButtonsPesquisaConstraints == null) {
			panelButtonsPesquisaConstraints = createConstraintsPrototype();
			panelButtonsPesquisaConstraints.gridx = 0;
			panelButtonsPesquisaConstraints.gridy = 0;
		}
		return panelButtonsPesquisaConstraints;
	}

	private PanelDadosListaMotoqueiro getPanelDadosListaMotoqueiro() {
		if (panelDadosListaMotoqueiro == null) {
			panelDadosListaMotoqueiro = new PanelDadosListaMotoqueiro();
			panelDadosListaMotoqueiro.setBorder(getTitledBorderTable());
		}
		return panelDadosListaMotoqueiro;
	}

	private PanelListaButtons getPanelListaButtons() {
		if (panelListaButtons == null) {
			panelListaButtons = new PanelListaButtons();
			panelListaButtons
					.addButtonsListarListener(new ButtonsListarListener() {

						@Override
						public void fechar() {
							for (ConsultaMotoqueiro listener : listeners) {
								listener.fechar();
							}

						}
					});

		}
		return panelListaButtons;
	}

	private PanelButtonsCrud getPanelButtonsCrud() {
		if (panelButtonsCrud == null) {
			panelButtonsCrud = new PanelButtonsCrud();
			panelButtonsCrud.setBorder(getTitledBorderButtons());
			panelButtonsCrud.addButtonsCrud(new ButtonsCrud() {

				@Override
				public void editar(String codigo) {
					panelButtonsCrud.limpa();
					for (ConsultaMotoqueiro listener : listeners) {
						listener.editar(codigo);
					}

				}

				@Override
				public void excluir(String codigo) {
					panelButtonsCrud.limpa();
					for (ConsultaMotoqueiro listener : listeners) {
						listener.excluir(codigo);
					}

				}

				@Override
				public void incluir() {
					for (ConsultaMotoqueiro listener : listeners) {
						listener.incluir();
					}

				}

			});
		}

		return panelButtonsCrud;
	}

	private PanelButtonsPesqMotoq getPanelButtonsPesquisa() {
		if (panelButtonsPesqMotoq == null) {
			panelButtonsPesqMotoq = new PanelButtonsPesqMotoq();
			panelButtonsPesqMotoq.setBorder(getTitledBorderPesquisa());
			panelButtonsPesqMotoq.addButtonsPesquisa(new ButtonsPesquisa() {

				@Override
				public void fechar() {
					for (ConsultaMotoqueiro listener : listeners) {
						listener.cancelar();
					}
				}

				@Override
				public void listarTudo() {
					for (ConsultaMotoqueiro listener : listeners) {
						listener.listarTudo();
					}

				}

				@Override
				public void relacaoTela() {
					for (ConsultaMotoqueiro listener : listeners) {
						listener.relacaoTela();
					}

				}

				@Override
				public void pesquisar(Date data, String pesq1, String pesq2,
						Integer pesq3) {
					panelButtonsPesqMotoq.limpa();
					for (ConsultaMotoqueiro listener : listeners) {
						listener.pesquisar(data, pesq1, pesq2, pesq3);
					}

				}

			});
		}
		return panelButtonsPesqMotoq;
	}

	public void setDadosMotoqueiro(ArrayList<MotoqueiroTO> motoqueiros) {
		getPanelDadosListaMotoqueiro().setMotoqueiroTable(motoqueiros);
	}

	public void limpaTable() {
		getPanelDadosListaMotoqueiro().limparTable();
	}

	public void addFrete(ButtonsCrud buttonsCrud) {
		getPanelButtonsCrud().addButtonsCrud(buttonsCrud);

	}

	public void addConsultaMotoqueiro(ConsultaMotoqueiro listener) {
		listeners.add(listener);
		getPanelDadosListaMotoqueiro().addConsultaMotoqueiro(listener);
	}
}
