package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.ButtonsPesquisa;

public class PanelButtonsPesquisaCliente extends JPanel {

	private static final long serialVersionUID = -7423581374456464251L;

	private JLabel pesquisarDataLabel;
	private JLabel pesquisarDestinoLabel;
	private JLabel pesquisarMotoqLabel;
	private JLabel pesquisarNumMotoqLabel;
	private JDateChooser dateChooserField;
	private JTextField pesquisarDestinoField;
	private JTextField pesquisarMotoqField;
	private JTextField pesquisarNumMotoqField;
	private JButton pesquisarButton;
	private JButton listarTudoButton;
	private JButton relacaoTelaButton;
	private JButton fecharButton;

	private GridBagConstraints pesquisarDataLabelConstraints;
	private GridBagConstraints pesquisarDestinoLabelConstraints;
	private GridBagConstraints pesquisarMotoqLabelConstraints;
	private GridBagConstraints pesquisarNumMotoqLabelConstraints;
	private GridBagConstraints dateChooserFieldConstraints;
	private GridBagConstraints pesquisarDestinoFieldConstraints;
	private GridBagConstraints pesquisarMotoqFieldConstraints;
	private GridBagConstraints pesquisarNumMotoqFieldConstraints;
	private GridBagConstraints pesquisarButtonConstraints;
	private GridBagConstraints listarTudoButtonConstraints;
	private GridBagConstraints relacaoTelaButtonConstraints;
	private GridBagConstraints fecharButtonConstraints;

	private ArrayList<ButtonsPesquisa> listeners = new ArrayList<ButtonsPesquisa>();

	public PanelButtonsPesquisaCliente() {
		super();
		initialize();
	}

	private void initialize() {
		setLayout(new GridBagLayout());

		add(getPesquisarButton(), getPesquisarButtonConstraints());
		add(getPesquisarDataLabel(), getPesquisarDataLabelConstraints());
		add(getPesquisarDestinoLabel(), getPesquisarDestinoLabelConstraints());
		add(getPesquisarMotoqLabel(), getPesquisarMotoqLabelConstraints());
		add(getPesquisarNumMotoqLabel(), getPesquisarNumMotoqLabelConstraints());
		add(getDateChooserField(), getDateChooserFieldConstraints());
		add(getPesquisarDestinoField(), getPesquisarDestinoFieldConstraints());
		add(getPesquisarMotoqField(), getPesquisarMotoqFieldConstraints());
		add(getPesquisarNumMotoqField(), getPesquisarNumMotoqFieldConstraints());
		add(getListarTudoButton(), getListarTudoButtonConstraints());
		add(getRelacaoTelaButton(), getRelacaoTelaButtonConstraints());
		add(getFecharButton(), getFecharButtonConstraints());

	}

	private JButton getPesquisarButton() {
		if (pesquisarButton == null) {

			URL pathToImage = getClass().getResource(
					"/edu/univas/projeto/tcc/files/pesquisar.png");
			pesquisarButton = new JButton("Pesquisa ", new ImageIcon(
					pathToImage));
			pesquisarButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for (ButtonsPesquisa listener : listeners) {
						listener.pesquisar(getDateChooserField().getDate(),
								getPesquisarDestinoField().getText(),
								getPesquisarMotoqField().getText(),
								lerNum_Frete(getPesquisarNumMotoqField()
										.getText()));
					}
				}
			});
		}

		return pesquisarButton;
	}

	private Integer lerNum_Frete(String numFrete) {

		String num = "";

		if (num.equals(numFrete)) {
			return null;
		} else {
			Integer numero = Integer.parseInt(numFrete);
			return numero;
		}
	}

	private JButton getListarTudoButton() {
		if (listarTudoButton == null) {
			URL pathToImage = getClass().getResource(
					"/edu/univas/projeto/tcc/files/listar.png");
			listarTudoButton = new JButton("Listar Tudo", new ImageIcon(
					pathToImage));
			listarTudoButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for (ButtonsPesquisa listener : listeners) {
						listener.listarTudo();
					}
				}
			});
		}

		return listarTudoButton;
	}

	private JButton getRelacaoTelaButton() {
		if (relacaoTelaButton == null) {

			URL pathToImage = getClass().getResource(
					"/edu/univas/projeto/tcc/files/rela.png");
			relacaoTelaButton = new JButton("Rela��o Cad. do Dia",
					new ImageIcon(pathToImage));
			relacaoTelaButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for (ButtonsPesquisa listener : listeners) {
						listener.relacaoTela();
					}
				}
			});
		}

		return relacaoTelaButton;
	}

	private JButton getFecharButton() {
		if (fecharButton == null) {

			URL pathToImage = getClass().getResource(
					"/edu/univas/projeto/tcc/files/fechar.png");
			fecharButton = new JButton("Cancelar", new ImageIcon(pathToImage));
			fecharButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for (ButtonsPesquisa listener : listeners) {
						listener.fechar();
					}
				}
			});
		}

		return fecharButton;
	}

	private JLabel getPesquisarDataLabel() {
		if (pesquisarDataLabel == null) {
			pesquisarDataLabel = new JLabel();
			pesquisarDataLabel.setText("Data Cadastro: ");

		}
		return pesquisarDataLabel;
	}

	private JLabel getPesquisarDestinoLabel() {
		if (pesquisarDestinoLabel == null) {
			pesquisarDestinoLabel = new JLabel();
			pesquisarDestinoLabel.setText("Bairro: ");

		}

		return pesquisarDestinoLabel;
	}

	private JLabel getPesquisarMotoqLabel() {
		if (pesquisarMotoqLabel == null) {
			pesquisarMotoqLabel = new JLabel();
			pesquisarMotoqLabel.setText("Nome Cliente: ");

		}

		return pesquisarMotoqLabel;
	}

	private JDateChooser getDateChooserField() {
		if (dateChooserField == null) {
			dateChooserField = new JDateChooser();

		}

		return dateChooserField;
	}

	private JTextField getPesquisarDestinoField() {
		if (pesquisarDestinoField == null) {
			pesquisarDestinoField = new JTextField();
		}

		return pesquisarDestinoField;
	}

	private JTextField getPesquisarMotoqField() {
		if (pesquisarMotoqField == null) {
			pesquisarMotoqField = new JTextField();

		}

		return pesquisarMotoqField;
	}

	private GridBagConstraints getPesquisarDataLabelConstraints() {
		if (pesquisarDataLabelConstraints == null) {
			pesquisarDataLabelConstraints = createConstraintsPrototype();
			pesquisarDataLabelConstraints.gridx = 2;
			pesquisarDataLabelConstraints.gridy = 0;
		}
		return pesquisarDataLabelConstraints;
	}

	private GridBagConstraints getPesquisarDestinoLabelConstraints() {
		if (pesquisarDestinoLabelConstraints == null) {
			pesquisarDestinoLabelConstraints = createConstraintsPrototype();
			pesquisarDestinoLabelConstraints.gridx = 0;
			pesquisarDestinoLabelConstraints.gridy = 0;
		}

		return pesquisarDestinoLabelConstraints;
	}

	private GridBagConstraints getPesquisarMotoqLabelConstraints() {
		if (pesquisarMotoqLabelConstraints == null) {
			pesquisarMotoqLabelConstraints = createConstraintsPrototype();
			pesquisarMotoqLabelConstraints.gridx = 0;
			pesquisarMotoqLabelConstraints.gridy = 1;
		}

		return pesquisarMotoqLabelConstraints;
	}

	private GridBagConstraints getDateChooserFieldConstraints() {
		if (dateChooserFieldConstraints == null) {
			dateChooserFieldConstraints = createConstraintsPrototype();
			dateChooserFieldConstraints.gridx = 3;
			dateChooserFieldConstraints.gridy = 0;
			dateChooserFieldConstraints.ipadx = 15;
		}

		return dateChooserFieldConstraints;
	}

	private GridBagConstraints getPesquisarDestinoFieldConstraints() {
		if (pesquisarDestinoFieldConstraints == null) {
			pesquisarDestinoFieldConstraints = createConstraintsPrototype();
			pesquisarDestinoFieldConstraints.gridx = 1;
			pesquisarDestinoFieldConstraints.gridy = 0;
		}

		return pesquisarDestinoFieldConstraints;
	}

	private GridBagConstraints getPesquisarMotoqFieldConstraints() {
		if (pesquisarMotoqFieldConstraints == null) {
			pesquisarMotoqFieldConstraints = createConstraintsPrototype();
			pesquisarMotoqFieldConstraints.gridx = 1;
			pesquisarMotoqFieldConstraints.gridy = 1;
			pesquisarMotoqFieldConstraints.ipadx = 80;
		}

		return pesquisarMotoqFieldConstraints;
	}

	private GridBagConstraints getPesquisarButtonConstraints() {
		if (pesquisarButtonConstraints == null) {
			pesquisarButtonConstraints = createConstraintsPrototype();
			pesquisarButtonConstraints.gridx = 4;
			pesquisarButtonConstraints.gridy = 0;
		}

		return pesquisarButtonConstraints;
	}

	private GridBagConstraints getListarTudoButtonConstraints() {
		if (listarTudoButtonConstraints == null) {
			listarTudoButtonConstraints = createConstraintsPrototype();
			listarTudoButtonConstraints.gridx = 5;
			listarTudoButtonConstraints.gridy = 0;
		}

		return listarTudoButtonConstraints;
	}

	private GridBagConstraints getRelacaoTelaButtonConstraints() {
		if (relacaoTelaButtonConstraints == null) {
			relacaoTelaButtonConstraints = createConstraintsPrototype();
			relacaoTelaButtonConstraints.gridx = 4;
			relacaoTelaButtonConstraints.gridy = 1;
		}

		return relacaoTelaButtonConstraints;
	}

	private GridBagConstraints getFecharButtonConstraints() {
		if (fecharButtonConstraints == null) {
			fecharButtonConstraints = createConstraintsPrototype();
			fecharButtonConstraints.gridx = 5;
			fecharButtonConstraints.gridy = 1;
		}

		return fecharButtonConstraints;
	}

	private JLabel getPesquisarNumMotoqLabel() {
		if (pesquisarNumMotoqLabel == null) {
			pesquisarNumMotoqLabel = new JLabel();
			pesquisarNumMotoqLabel.setText("N� Casa/Estabelecimento: ");
		}
		return pesquisarNumMotoqLabel;
	}

	private JTextField getPesquisarNumMotoqField() {
		if (pesquisarNumMotoqField == null) {
			pesquisarNumMotoqField = new JTextField();

		}
		return pesquisarNumMotoqField;
	}

	private GridBagConstraints getPesquisarNumMotoqLabelConstraints() {
		if (pesquisarNumMotoqLabelConstraints == null) {
			pesquisarNumMotoqLabelConstraints = createConstraintsPrototype();
			pesquisarNumMotoqLabelConstraints.gridx = 2;
			pesquisarNumMotoqLabelConstraints.gridy = 1;
		}

		return pesquisarNumMotoqLabelConstraints;
	}

	private GridBagConstraints getPesquisarNumMotoqFieldConstraints() {
		if (pesquisarNumMotoqFieldConstraints == null) {
			pesquisarNumMotoqFieldConstraints = createConstraintsPrototype();
			pesquisarNumMotoqFieldConstraints.gridx = 3;
			pesquisarNumMotoqFieldConstraints.gridy = 1;
			pesquisarNumMotoqFieldConstraints.ipadx = 80;
		}

		return pesquisarNumMotoqFieldConstraints;
	}

	public void addButtonsPesquisa(ButtonsPesquisa listener) {
		if (listener != null) {
			listeners.add(listener);
		}
	}

	public void limpa() {
		getPesquisarDestinoField().setText("");
		getPesquisarMotoqField().setText("");
		getPesquisarNumMotoqField().setText("");
		getDateChooserField().setDate(null);
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

}
