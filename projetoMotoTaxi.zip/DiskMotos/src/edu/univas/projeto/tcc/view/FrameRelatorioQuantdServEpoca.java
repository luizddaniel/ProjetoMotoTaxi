package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.ListaRelatorio;
import edu.univas.projeto.tcc.listeners.PesquisaButtonRelatorios;
import edu.univas.projeto.tcc.model.FreteTO;

public class FrameRelatorioQuantdServEpoca extends JFrame {

	private static final long serialVersionUID = 7543041276301417984L;

	private PanelDadosListaQtdeEpocaAno panelDadosListaQtdeEpocaAno;
	private PanelButtonRelatorios panelRelatorios;
	private TitledBorder titledBorder;

	private GridBagConstraints panelListaRelatorioMotoqueiroConstraints;
	private GridBagConstraints panelRelatoriosConstraints;

	private ArrayList<ListaRelatorio> listeners = new ArrayList<ListaRelatorio>();

	public FrameRelatorioQuantdServEpoca() {
		super("Rela��o de Quantidade Fretes por M�s ");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);

	}

	private void initialize() {

		setLayout(new GridBagLayout());

		add(getPanelListaQtdeEpocaAno(),
				getPanelListaRelatorioMotoqueiroConstraints());
		add(getPanelRelatorios(), getPanelRelatoriosConstraints());

	}

	private TitledBorder getTitledBorderPesquisa() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Pesquisar");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderTable() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Dados dos Fretes");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

	private PanelDadosListaQtdeEpocaAno getPanelListaQtdeEpocaAno() {
		if (panelDadosListaQtdeEpocaAno == null) {
			panelDadosListaQtdeEpocaAno = new PanelDadosListaQtdeEpocaAno();
			panelDadosListaQtdeEpocaAno.setBorder(getTitledBorderTable());
		}
		return panelDadosListaQtdeEpocaAno;
	}

	private PanelButtonRelatorios getPanelRelatorios() {
		if (panelRelatorios == null) {
			panelRelatorios = new PanelButtonRelatorios();
			panelRelatorios.setBorder(getTitledBorderPesquisa());
			panelRelatorios.addButtonsRelatorio(new PesquisaButtonRelatorios() {

				@Override
				public void fechar() {
					for (ListaRelatorio listener : listeners) {
						listener.fechar();
					}

				}

				@Override
				public void pesquisar(JDateChooser dtInic, JDateChooser dtFim) {
					for (ListaRelatorio listener : listeners) {
						listener.listar(dtInic, dtFim);
					}

				}

				@Override
				public void pesquisarTale(JDateChooser dtInic,
						JDateChooser dtFim) {
					for (ListaRelatorio listener : listeners) {
						listener.listarTable(dtInic, dtFim);
					}

				}

			});
		}

		return panelRelatorios;
	}

	private GridBagConstraints getPanelListaRelatorioMotoqueiroConstraints() {
		if (panelListaRelatorioMotoqueiroConstraints == null) {
			panelListaRelatorioMotoqueiroConstraints = createConstraintsPrototype();
			panelListaRelatorioMotoqueiroConstraints.gridx = 0;
			panelListaRelatorioMotoqueiroConstraints.gridy = 1;
		}
		return panelListaRelatorioMotoqueiroConstraints;
	}

	private GridBagConstraints getPanelRelatoriosConstraints() {
		if (panelRelatoriosConstraints == null) {
			panelRelatoriosConstraints = createConstraintsPrototype();
			panelRelatoriosConstraints.gridx = 0;
			panelRelatoriosConstraints.gridy = 0;
		}

		return panelRelatoriosConstraints;
	}

	public void addRelatorioFretes(ListaRelatorio listener) {
		listeners.add(listener);
		getPanelListaQtdeEpocaAno().addListaRelatorioFretes(listener);
	}

	public void setRelatorioFrete(ArrayList<FreteTO> motoqs) {
		getPanelListaQtdeEpocaAno().setFretesTableRelatorio(motoqs);
	}

	public void limpaDadosTable() {
		getPanelListaQtdeEpocaAno().limparTable();
	}

}