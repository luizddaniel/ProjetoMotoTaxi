package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.DadosFrete;
import edu.univas.projeto.tcc.model.ClienteDestinoDAO;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;
import edu.univas.projeto.tcc.model.DAOException;
import edu.univas.projeto.tcc.model.FreteTO;
import edu.univas.projeto.tcc.model.MotoqueiroDAO;
import edu.univas.projeto.tcc.model.MotoqueiroTO;

public class PanelDadosFrete extends JPanel {

	private static final long serialVersionUID = -184778272193343536L;

	private JLabel numFreteLabel;
	private JTextField numFreteTextField;

	private JLabel dataLabel;
	private JDateChooser dataChooserField;

	private JLabel destinoLabel;
	private JComboBox destinoTextField;

	private JLabel motoqueiroLabel;
	private JComboBox motoqueiroTextField;

	private JLabel horaLigLabel;
	private JTextField horaLigTextField;

	private JLabel horaSaidaLabel;
	private JTextField horaSaidaTextField;

	private JLabel horaChegLabel;
	private JTextField horaChegTextField;

	private JLabel valorLabel;
	private JTextField valorTextField;

	private JTextField idTextField;

	// ----------------------------------------------------

	private GridBagConstraints numFreteLabelConstraints;
	private GridBagConstraints dataLabelConstraints;
	private GridBagConstraints destinoLabelConstraints;
	private GridBagConstraints motoqueiroLabelConstraints;
	private GridBagConstraints horaLigLabelConstraints;
	private GridBagConstraints horaSaidaLabelConstraints;
	private GridBagConstraints horaChegLabelConstraints;
	private GridBagConstraints valorLabelConstraints;

	private GridBagConstraints numFreteTextFieldConstraints;
	private GridBagConstraints dataTextFieldConstraints;
	private GridBagConstraints destinoTextFieldConstraints;
	private GridBagConstraints motoqueiroTextFieldConstraints;
	private GridBagConstraints horaLigTextFieldConstraints;
	private GridBagConstraints horaSaidaTextFieldConstraints;
	private GridBagConstraints horaChegTextFieldConstraints;
	private GridBagConstraints valorTextFieldConstraints;

	private FreteTO freteTO;

	private ArrayList<DadosFrete> listeners = new ArrayList<DadosFrete>();

	public PanelDadosFrete() {
		super();
		initialize();
	}

	private void initialize() {
		setLayout(new GridBagLayout());

		add(getNumFreteLabel(), getNumFreteLabelConstraints());
		add(getNumFreteTextField(), getNumFreteTextFieldConstraints());

		add(getDataLabel(), getDataLabelConstraints());
		add(getDataTextField(), getDataTextFieldConstraints());

		add(getDestinoLabel(), getDestinoLabelConstraints());
		add(getDestinoTextField(), getDestinoTextFieldConstraints());

		add(getMotoqueiroLabel(), getMotoqueiroLabelConstraints());
		add(getMotoqueiroTextField(), getMotoqueiroTextFieldConstraints());

		add(getHoraLigLabel(), getHoraLigLabelConstraints());
		add(getHoraLigTextField(), getHoraLigTextFieldConstraints());

		add(getHoraSaidaLabel(), getHoraSaidaLabelConstraints());
		add(getHoraSaidaTextField(), getHoraSaidaTextFieldConstraints());

		add(getHoraChegLabel(), getHoraChegLabelConstraints());
		add(getHoraChegTextField(), getHoraChegTextFieldConstraints());

		add(getValorLabel(), getValorLabelConstraints());
		add(getValorTextField(), getValorTextFieldConstraints());

		add(getIdTextField());

	}

	private JTextField getIdTextField() {
		if (idTextField == null) {
			idTextField = new JTextField();
			idTextField.setVisible(false);
		}
		return idTextField;
	}

	private JLabel getNumFreteLabel() {
		if (numFreteLabel == null) {
			numFreteLabel = new JLabel();
			numFreteLabel.setText("N�mero Frete: ");
		}
		return numFreteLabel;
	}

	private JTextField getNumFreteTextField() {
		if (numFreteTextField == null) {
			numFreteTextField = new JTextField();

		}
		return numFreteTextField;
	}

	private JLabel getDataLabel() {
		if (dataLabel == null) {
			dataLabel = new JLabel();
			dataLabel.setText("Data: ");
		}
		return dataLabel;
	}

	private JDateChooser getDataTextField() {
		if (dataChooserField == null) {
			dataChooserField = new JDateChooser();
		}
		return dataChooserField;
	}

	private JLabel getDestinoLabel() {
		if (destinoLabel == null) {
			destinoLabel = new JLabel();
			destinoLabel.setText("Destino: ");
		}
		return destinoLabel;
	}

	private JComboBox getDestinoTextField() {
		Object[] itens = null;
		ArrayList<String> lista = new ArrayList<String>();
		if (destinoTextField == null) {
			ArrayList<ClienteDestinoTO> destinos;
			try {
				destinos = new ClienteDestinoDAO()
						.listarClientesDestinoCombobox();
				for (ClienteDestinoTO cliente_destino : destinos) {
					lista.add(cliente_destino.getNome());
				}
			} catch (DAOException e) {
				e.printStackTrace();
			}
			itens = lista.toArray();
			destinoTextField = new JComboBox(itens);
		}
		return destinoTextField;
	}

	private JLabel getMotoqueiroLabel() {
		if (motoqueiroLabel == null) {
			motoqueiroLabel = new JLabel();
			motoqueiroLabel.setText("Motoqueiro: ");
		}
		return motoqueiroLabel;
	}

	private JComboBox getMotoqueiroTextField() {
		Object[] itens = null;
		ArrayList<String> lista = new ArrayList<String>();
		if (motoqueiroTextField == null) {
			ArrayList<MotoqueiroTO> motoqs;
			try {
				motoqs = new MotoqueiroDAO().listarMotoqueirosCombobox();
				for (MotoqueiroTO motoqueiro : motoqs) {
					lista.add(motoqueiro.getNome());
				}
			} catch (DAOException e) {
				e.printStackTrace();
			}
			itens = lista.toArray();
			motoqueiroTextField = new JComboBox(itens);
		}
		return motoqueiroTextField;
	}

	private JLabel getHoraLigLabel() {
		if (horaLigLabel == null) {
			horaLigLabel = new JLabel();
			horaLigLabel.setText("Hora Liga��o: ");
		}
		return horaLigLabel;
	}

	private JTextField getHoraLigTextField() {
		if (horaLigTextField == null) {
			horaLigTextField = new JFormattedTextField(getFormatterHoras());
		}
		return horaLigTextField;
	}

	private JLabel getHoraSaidaLabel() {
		if (horaSaidaLabel == null) {
			horaSaidaLabel = new JLabel();
			horaSaidaLabel.setText("Hora Sa�da: ");
		}
		return horaSaidaLabel;
	}

	private JTextField getHoraSaidaTextField() {
		if (horaSaidaTextField == null) {
			horaSaidaTextField = new JFormattedTextField(getFormatterHoras());
		}
		return horaSaidaTextField;
	}

	private JLabel getHoraChegLabel() {
		if (horaChegLabel == null) {
			horaChegLabel = new JLabel();
			horaChegLabel.setVisible(false);
			// hora_chegLabel.setText("Hora Chegada: ");
		}
		return horaChegLabel;
	}

	private JTextField getHoraChegTextField() {
		if (horaChegTextField == null) {
			horaChegTextField = new JFormattedTextField(getFormatterHoras());
			horaChegTextField.setVisible(false);
		}
		return horaChegTextField;
	}

	private JLabel getValorLabel() {
		if (valorLabel == null) {
			valorLabel = new JLabel();
			// valorLabel.setText("Valor: ");
			valorLabel.setVisible(false);
		}
		return valorLabel;
	}

	private JTextField getValorTextField() {
		if (valorTextField == null) {
			valorTextField = new JTextField();
			valorTextField.setVisible(false);
		}
		return valorTextField;
	}

	private GridBagConstraints getNumFreteLabelConstraints() {
		if (numFreteLabelConstraints == null) {
			numFreteLabelConstraints = createConstraintsPrototype();
			numFreteLabelConstraints.gridx = 0;
			numFreteLabelConstraints.gridy = 0;
		}
		return numFreteLabelConstraints;
	}

	private GridBagConstraints getDataLabelConstraints() {
		if (dataLabelConstraints == null) {
			dataLabelConstraints = createConstraintsPrototype();
			dataLabelConstraints.gridx = 2;
			dataLabelConstraints.gridy = 0;
		}
		return dataLabelConstraints;
	}

	private GridBagConstraints getDestinoLabelConstraints() {
		if (destinoLabelConstraints == null) {
			destinoLabelConstraints = createConstraintsPrototype();
			destinoLabelConstraints.gridx = 0;
			destinoLabelConstraints.gridy = 1;
		}
		return destinoLabelConstraints;
	}

	private GridBagConstraints getMotoqueiroLabelConstraints() {
		if (motoqueiroLabelConstraints == null) {
			motoqueiroLabelConstraints = createConstraintsPrototype();
			motoqueiroLabelConstraints.gridx = 2;
			motoqueiroLabelConstraints.gridy = 1;
		}
		return motoqueiroLabelConstraints;
	}

	private GridBagConstraints getHoraLigLabelConstraints() {
		if (horaLigLabelConstraints == null) {
			horaLigLabelConstraints = createConstraintsPrototype();
			horaLigLabelConstraints.gridx = 0;
			horaLigLabelConstraints.gridy = 2;
		}
		return horaLigLabelConstraints;
	}

	private GridBagConstraints getHoraSaidaLabelConstraints() {
		if (horaSaidaLabelConstraints == null) {
			horaSaidaLabelConstraints = createConstraintsPrototype();
			horaSaidaLabelConstraints.gridx = 2;
			horaSaidaLabelConstraints.gridy = 2;
		}
		return horaSaidaLabelConstraints;
	}

	private GridBagConstraints getHoraChegLabelConstraints() {
		if (horaChegLabelConstraints == null) {
			horaChegLabelConstraints = createConstraintsPrototype();
			horaChegLabelConstraints.gridx = 0;
			horaChegLabelConstraints.gridy = 3;
		}
		return horaChegLabelConstraints;
	}

	private GridBagConstraints getValorLabelConstraints() {
		if (valorLabelConstraints == null) {
			valorLabelConstraints = createConstraintsPrototype();
			valorLabelConstraints.gridx = 2;
			valorLabelConstraints.gridy = 3;
		}
		return valorLabelConstraints;
	}

	private GridBagConstraints getNumFreteTextFieldConstraints() {
		if (numFreteTextFieldConstraints == null) {
			numFreteTextFieldConstraints = createConstraintsPrototype();
			numFreteTextFieldConstraints.gridx = 1;
			numFreteTextFieldConstraints.gridy = 0;
			numFreteTextFieldConstraints.ipadx = 100;
		}
		return numFreteTextFieldConstraints;
	}

	private GridBagConstraints getDataTextFieldConstraints() {
		if (dataTextFieldConstraints == null) {
			dataTextFieldConstraints = createConstraintsPrototype();
			dataTextFieldConstraints.gridx = 3;
			dataTextFieldConstraints.gridy = 0;
			dataTextFieldConstraints.ipadx = 100;
		}
		return dataTextFieldConstraints;
	}

	private GridBagConstraints getDestinoTextFieldConstraints() {
		if (destinoTextFieldConstraints == null) {
			destinoTextFieldConstraints = createConstraintsPrototype();
			destinoTextFieldConstraints.gridx = 1;
			destinoTextFieldConstraints.gridy = 1;
			destinoTextFieldConstraints.ipadx = 100;
		}
		return destinoTextFieldConstraints;
	}

	private GridBagConstraints getMotoqueiroTextFieldConstraints() {
		if (motoqueiroTextFieldConstraints == null) {
			motoqueiroTextFieldConstraints = createConstraintsPrototype();
			motoqueiroTextFieldConstraints.gridx = 3;
			motoqueiroTextFieldConstraints.gridy = 1;
			motoqueiroTextFieldConstraints.ipadx = 100;
		}
		return motoqueiroTextFieldConstraints;
	}

	private GridBagConstraints getHoraLigTextFieldConstraints() {
		if (horaLigTextFieldConstraints == null) {
			horaLigTextFieldConstraints = createConstraintsPrototype();
			horaLigTextFieldConstraints.gridx = 1;
			horaLigTextFieldConstraints.gridy = 2;
			horaLigTextFieldConstraints.ipadx = 100;
		}
		return horaLigTextFieldConstraints;
	}

	private GridBagConstraints getHoraSaidaTextFieldConstraints() {
		if (horaSaidaTextFieldConstraints == null) {
			horaSaidaTextFieldConstraints = createConstraintsPrototype();
			horaSaidaTextFieldConstraints.gridx = 3;
			horaSaidaTextFieldConstraints.gridy = 2;
			horaSaidaTextFieldConstraints.ipadx = 100;
		}
		return horaSaidaTextFieldConstraints;
	}

	private GridBagConstraints getHoraChegTextFieldConstraints() {
		if (horaChegTextFieldConstraints == null) {
			horaChegTextFieldConstraints = createConstraintsPrototype();
			horaChegTextFieldConstraints.gridx = 1;
			horaChegTextFieldConstraints.gridy = 3;
			horaChegTextFieldConstraints.ipadx = 100;
		}
		return horaChegTextFieldConstraints;
	}

	private GridBagConstraints getValorTextFieldConstraints() {
		if (valorTextFieldConstraints == null) {
			valorTextFieldConstraints = createConstraintsPrototype();
			valorTextFieldConstraints.gridx = 3;
			valorTextFieldConstraints.gridy = 3;
			valorTextFieldConstraints.ipadx = 100;
		}
		return valorTextFieldConstraints;
	}

	private MaskFormatter getFormatterHoras() {
		try {
			MaskFormatter formatter = new MaskFormatter();
			formatter.setMask("##:##");
			formatter.setPlaceholderCharacter('_');
			return formatter;
		} catch (ParseException e) {
			return new MaskFormatter();
		}
	}

	public FreteTO getFreteTO() {
		// Float vlr = null;

		if (freteTO == null) {
			freteTO = new FreteTO();

		}
		freteTO.setMotoq((String) getMotoqueiroTextField().getSelectedItem());
		freteTO.setDestino((String) getDestinoTextField().getSelectedItem());
		freteTO.setHoraLig(getHoraLigTextField().getText());
		freteTO.setHoraSaida(getHoraSaidaTextField().getText());
		freteTO.setHoraCheg(getHoraChegTextField().getText());
		freteTO.setData(getDataTextField().getDate());
		freteTO.setValor(Float.valueOf(0));
		apresentaMes(freteTO);
		apresentaNumMes(freteTO);
		if (!lerNum_Frete(freteTO)) {
			return null;
		}

		return freteTO;
	}

	public FreteTO getEditarFreteTO() {
		if (freteTO == null) {
			freteTO = new FreteTO();
		}
		freteTO.setId(Integer.parseInt(getIdTextField().getText()));
		freteTO.setMotoq((String) getMotoqueiroTextField().getSelectedItem());
		freteTO.setDestino((String) getDestinoTextField().getSelectedItem());
		freteTO.setHoraLig(getHoraLigTextField().getText());
		freteTO.setHoraSaida(getHoraSaidaTextField().getText());
		freteTO.setHoraCheg(getHoraChegTextField().getText());
		freteTO.setData(getDataTextField().getDate());
		apresentaMes(freteTO);
		apresentaNumMes(freteTO);

		if (!lerNum_Frete(freteTO) || !lerValor(freteTO)) {
			return null;
		}

		return freteTO;
	}

	public void apresentaMes(FreteTO freteTO) {
		String mes = null;

		Date dataMes = getDataTextField().getDate();
		SimpleDateFormat format = new SimpleDateFormat("MMMM - yyyy");
		mes = format.format(dataMes);
		freteTO.setMes(mes);

	}

	public void apresentaNumMes(FreteTO freteTO) {
		String mes = null;

		Date dataMes = getDataTextField().getDate();
		SimpleDateFormat format = new SimpleDateFormat("MM");
		mes = format.format(dataMes);
		freteTO.setNumMes(Integer.parseInt(mes));

	}

	public void setDataHoras() {

		SimpleDateFormat format = new SimpleDateFormat("HH:mm");

		Date horas = null;

		horas = new Date();
		String hora = format.format(horas);

		getHoraLigTextField().setText(hora);
		//getHoraSaidaTextField().setText(hora);
		getDataTextField().setDate(new Date());

	}

	public void setFreteTO(FreteTO frete) {

		getIdTextField().setText(Integer.toString(frete.getId()));
		getNumFreteTextField().setText(Integer.toString(frete.getNumFrete()));
		getHoraLigTextField().setText(frete.getHoraLig());
		getHoraSaidaTextField().setText(frete.getHoraSaida());
		getHoraChegTextField().setText(frete.getHoraCheg());
		getDestinoTextField().setSelectedItem(frete.getDestino());
		getMotoqueiroTextField().setSelectedItem(frete.getMotoq());
		getValorTextField().setText(Float.toString(frete.getValor()));
		getDataTextField().setDate(frete.getData());

	}

	private boolean lerNum_Frete(FreteTO freteTO) {

		String num = "";

		try {
			num = getNumFreteTextField().getText();
			Integer numero = Integer.parseInt(num);
			freteTO.setNumFrete(numero);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,
					"Favor � obrigat�rio preencher o campo numero do frete");
			return false;
		}
		return true;
	}

	private boolean lerValor(FreteTO freteTO) {

		String num = "";

		try {
			num = getValorTextField().getText();
			Float numero = Float.parseFloat(num);
			freteTO.setValor(numero);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "O valor informado " + num
					+ " n�o � v�lido.\n Informe um valor correto!");
			return false;
		}
		return true;
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

	public void addDadosFrete(DadosFrete listener) {
		listeners.add(listener);
	}
}
