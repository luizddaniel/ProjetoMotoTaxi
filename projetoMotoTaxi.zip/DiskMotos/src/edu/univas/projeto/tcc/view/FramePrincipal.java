package edu.univas.projeto.tcc.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;

import edu.univas.projeto.tcc.listeners.MenuListener;

public class FramePrincipal extends JFrame {

	private static final long serialVersionUID = 7548144117551668423L;

	private JMenuBar mainmenuBar;
	private JMenu cadastromenu;
	private JMenu relatoriomenu;
	private JMenuItem clientesItem;
	private JMenuItem motoqueiroItem;
	private JMenuItem corridaItem;
	private JMenuItem cliMaisSolicServItem;
	private JMenuItem epAnoMaisServItem;
	private JMenuItem motMaisServItem;
	private JMenuItem qtdServSolicItem;
	private JMenuItem bairroMaisSolicServItem;
	private JMenuItem sairItem;
	private JLabel label;

	private ArrayList<MenuListener> menuListeners = new ArrayList<MenuListener>();

	public FramePrincipal() {

		super("Sistema Disk Motos");

		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		initialize();
		setSize(new Dimension(800, 600));
		setResizable(false);

		setLocationRelativeTo(null);
	}

	private void initialize() {
		add(getLabel(), BorderLayout.BEFORE_FIRST_LINE);
		setJMenuBar(getmainMenuBar());

	}

	private JLabel getLabel() {
		if (label == null) {
			URL pathToImage = getClass().getResource(
					"/edu/univas/projeto/tcc/files/");
			label = new JLabel(new ImageIcon(pathToImage));
		}
		return label;
	}

	private JMenuBar getmainMenuBar() {
		if (mainmenuBar == null) {
			mainmenuBar = new JMenuBar();
			mainmenuBar.add(getCadastromenu());
			mainmenuBar.add(getRelatoriomenu());
		}
		return mainmenuBar;
	}

	private JMenu getCadastromenu() {
		if (cadastromenu == null) {
			cadastromenu = new JMenu();
			cadastromenu.setText("Cadastros");
			cadastromenu.add(getClientesItem());
			cadastromenu.add(new JSeparator());
			cadastromenu.add(getCorridaItem());
			cadastromenu.add(new JSeparator());
			cadastromenu.add(getMotoqueiroItem());
			cadastromenu.add(new JSeparator());
			cadastromenu.add(getSairItem());
		}
		return cadastromenu;
	}

	private JMenu getRelatoriomenu() {
		if (relatoriomenu == null) {
			relatoriomenu = new JMenu();
			relatoriomenu.setText("Relat�rios");
			relatoriomenu.add(getCli_m_s_servItem());
			relatoriomenu.add(new JSeparator());
			relatoriomenu.add(getEp_ano_m_servItem());
			relatoriomenu.add(new JSeparator());
			relatoriomenu.add(getMot_m_servItem());
			relatoriomenu.add(new JSeparator());
			relatoriomenu.add(getQtd_serv_solicItem());
			relatoriomenu.add(new JSeparator());
			relatoriomenu.add(getBairro_m_s_servItem());

		}
		return relatoriomenu;
	}

	private JMenuItem getClientesItem() {
		if (clientesItem == null) {
			clientesItem = new JMenuItem();
			clientesItem.setText("Clientes / Destinos");
			clientesItem.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					for (MenuListener listener : menuListeners) {
						listener.cadastrarCliDest();
					}
				}

			});
		}
		return clientesItem;
	}

	private JMenuItem getMotoqueiroItem() {
		if (motoqueiroItem == null) {
			motoqueiroItem = new JMenuItem();
			motoqueiroItem.setText("Motoqueiros");
			motoqueiroItem.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					for (MenuListener listener : menuListeners) {
						listener.cadastrarMot();
					}

				}

			});
		}
		return motoqueiroItem;
	}

	private JMenuItem getCorridaItem() {
		if (corridaItem == null) {
			corridaItem = new JMenuItem();
			corridaItem.setText("Fretes");
			corridaItem.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					for (MenuListener listener : menuListeners) {
						listener.cadastrarFrete();
					}

				}

			});
		}
		return corridaItem;
	}

	private JMenuItem getCli_m_s_servItem() {
		if (cliMaisSolicServItem == null) {
			cliMaisSolicServItem = new JMenuItem();
			cliMaisSolicServItem.setText("Cliente que mais solicitou o servi�o");
			cliMaisSolicServItem.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					for (MenuListener listener : menuListeners) {
						listener.relCliMaiSolicServ();
					}

				}

			});
		}
		return cliMaisSolicServItem;
	}

	private JMenuItem getEp_ano_m_servItem() {
		if (epAnoMaisServItem == null) {
			epAnoMaisServItem = new JMenuItem();
			epAnoMaisServItem.setText("�poca do ano que teve mais servi�o");
			epAnoMaisServItem.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					for (MenuListener listener : menuListeners) {
						listener.relEpcAnoMaisServ();
					}

				}

			});
		}
		return epAnoMaisServItem;
	}

	private JMenuItem getMot_m_servItem() {
		if (motMaisServItem == null) {
			motMaisServItem = new JMenuItem();
			motMaisServItem
					.setText("Valor total de fretes agrupado por motoqueiro");
			motMaisServItem.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					for (MenuListener listener : menuListeners) {
						listener.relMotMaisServ();
					}

				}

			});
		}
		return motMaisServItem;
	}

	private JMenuItem getQtd_serv_solicItem() {
		if (qtdServSolicItem == null) {
			qtdServSolicItem = new JMenuItem();
			qtdServSolicItem
					.setText("Quantidade de servi�os prestados agrupado por motoqueiro");
			qtdServSolicItem.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					for (MenuListener listener : menuListeners) {
						listener.relQtdServSolic();
					}

				}

			});
		}

		return qtdServSolicItem;
	}

	private JMenuItem getBairro_m_s_servItem() {
		if (bairroMaisSolicServItem == null) {
			bairroMaisSolicServItem = new JMenuItem();
			bairroMaisSolicServItem
					.setText("Bairro que teve maior solicita��o de servi�o");
			bairroMaisSolicServItem.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					for (MenuListener listener : menuListeners) {
						listener.relBairroMaisSolicServ();
					}

				}

			});
		}
		return bairroMaisSolicServItem;
	}

	private JMenuItem getSairItem() {
		if (sairItem == null) {
			sairItem = new JMenuItem();
			sairItem.setText("Sair");
			sairItem.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					if (JOptionPane.showConfirmDialog(FramePrincipal.this,
							"Sair da aplica��o?", "Sistema Disk Motos",
							JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
						System.exit(0);
					}

				}
			});
		}

		return sairItem;
	}

	public void addMenuListener(MenuListener listener) {
		menuListeners.add(listener);
	}
}
