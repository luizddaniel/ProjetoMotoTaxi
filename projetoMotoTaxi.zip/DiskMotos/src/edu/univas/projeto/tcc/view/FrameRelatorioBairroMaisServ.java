package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.ListaRelatorio;
import edu.univas.projeto.tcc.listeners.PesquisaButtonRelatorios;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;

public class FrameRelatorioBairroMaisServ extends JFrame {

	private static final long serialVersionUID = -194174990802941429L;
	private PanelDadosListaBairroMais panelListaBairro;
	private PanelButtonRelatorios panelRelatorios;
	private TitledBorder titledBorder;

	private GridBagConstraints panelDadosListaBairroConstraints;
	private GridBagConstraints panelRelatoriosConstraints;

	private ArrayList<ListaRelatorio> listeners = new ArrayList<ListaRelatorio>();

	public FrameRelatorioBairroMaisServ() {
		super("Rela��o Bairros Mais Solicitado ");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		initialize();
		pack();
		setResizable(false);
		setLocationRelativeTo(null);

	}

	private void initialize() {

		setLayout(new GridBagLayout());

		add(getPanelListaBairro(), getPanelListaBairroConstraints());
		add(getPanelRelatorios(), getPanelRelatoriosConstraints());

	}

	private TitledBorder getTitledBorderPesquisa() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Pesquisar");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderTable() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched,
				"Dados dos Bairros");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

	private PanelDadosListaBairroMais getPanelListaBairro() {
		if (panelListaBairro == null) {
			panelListaBairro = new PanelDadosListaBairroMais();
			panelListaBairro.setBorder(getTitledBorderTable());
		}
		return panelListaBairro;
	}

	private PanelButtonRelatorios getPanelRelatorios() {
		if (panelRelatorios == null) {
			panelRelatorios = new PanelButtonRelatorios();
			panelRelatorios.setBorder(getTitledBorderPesquisa());
			panelRelatorios.addButtonsRelatorio(new PesquisaButtonRelatorios() {

				@Override
				public void fechar() {
					for (ListaRelatorio listener : listeners) {
						listener.fechar();
					}

				}

				@Override
				public void pesquisar(JDateChooser dtInic, JDateChooser dtFim) {
					for (ListaRelatorio listener : listeners) {
						listener.listar(dtInic, dtFim);
					}

				}

				@Override
				public void pesquisarTale(JDateChooser dtInic,
						JDateChooser dtFim) {
					for (ListaRelatorio listener : listeners) {
						listener.listarTable(dtInic, dtFim);
					}

				}

			});
		}

		return panelRelatorios;
	}

	private GridBagConstraints getPanelListaBairroConstraints() {
		if (panelDadosListaBairroConstraints == null) {
			panelDadosListaBairroConstraints = createConstraintsPrototype();
			panelDadosListaBairroConstraints.gridx = 0;
			panelDadosListaBairroConstraints.gridy = 1;
		}
		return panelDadosListaBairroConstraints;
	}

	private GridBagConstraints getPanelRelatoriosConstraints() {
		if (panelRelatoriosConstraints == null) {
			panelRelatoriosConstraints = createConstraintsPrototype();
			panelRelatoriosConstraints.gridx = 0;
			panelRelatoriosConstraints.gridy = 0;
		}

		return panelRelatoriosConstraints;
	}

	public void addRelatorioBairro(ListaRelatorio listener) {
		listeners.add(listener);
		getPanelListaBairro().addListaRelatorioMotoq(listener);
	}

	public void setRelatorioBairro(ArrayList<ClienteDestinoTO> cliDest) {
		getPanelListaBairro().setBairroTableRelatorio(cliDest);
	}

	public void limpaDadosTable() {
		getPanelListaBairro().limparTable();

	}

}
