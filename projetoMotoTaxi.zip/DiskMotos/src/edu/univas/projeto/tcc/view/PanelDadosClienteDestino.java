package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.DadosClienteDestino;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;

public class PanelDadosClienteDestino extends JPanel {

	private static final long serialVersionUID = 7993654755801213711L;

	private JLabel tipoLabel;
	private JComboBox tipoComboBox;

	private JLabel nomeLabel;
	private JTextField nomeTextField;

	private JLabel enderecoLabel;
	private JTextField enderecoTextField;

	private JLabel numeroLabel;
	private JTextField numeroTextField;

	private JLabel bairroLabel;
	private JTextField bairroTextField;

	private JLabel cidadeLabel;
	private JTextField cidadeTextField;

	private JLabel cepLabel;
	private JTextField cepTextField;

	private JLabel telefoneLabel;
	private JFormattedTextField telefoneTextField;

	private JLabel cnpjCpfLabel;
	private JTextField cnpjCpfTextField;

	private JLabel ieRgLabel;
	private JTextField ieRgTextField;

	private JLabel emailLabel;
	private JTextField emailTextField;

	private JLabel dtcadastroLabel;
	private JDateChooser dtcadstroTextField;

	private JTextField idTextField;
	// --------------------------------------------------------
	private GridBagConstraints nomeLabelConstraints;
	private GridBagConstraints enderecoLabelConstraints;
	private GridBagConstraints numeroLabelConstraints;
	private GridBagConstraints bairroLabelConstraints;
	private GridBagConstraints cidadeLabelConstraints;
	private GridBagConstraints cepLabelConstraints;
	private GridBagConstraints telefoneLabelConstraints;
	private GridBagConstraints cnpjCpfLabelConstraints;
	private GridBagConstraints ieRgLabelConstraints;
	private GridBagConstraints emailLabelConstraints;
	private GridBagConstraints dtcadastroLabelConstraints;
	private GridBagConstraints tipoLabelConstraints;

	private GridBagConstraints tipoComboBoxConstraints;
	private GridBagConstraints nomeTextFieldConstraints;
	private GridBagConstraints enderecoTextFieldConstraints;
	private GridBagConstraints numeroTextFieldConstraints;
	private GridBagConstraints bairroTextFieldConstraints;
	private GridBagConstraints cidadeTextFieldConstraints;
	private GridBagConstraints cepTextFieldConstraints;
	private GridBagConstraints telefoneTextFieldConstraints;
	private GridBagConstraints cnpjCpfTextFieldConstraints;
	private GridBagConstraints ieRgTextFieldConstraints;
	private GridBagConstraints emailTextFieldConstraints;
	private GridBagConstraints dtcadastroTextFieldConstraints;
	// -------------------------------------------------------------------------

	private ClienteDestinoTO clienteDestinoTO;

	private ArrayList<DadosClienteDestino> listeners = new ArrayList<DadosClienteDestino>();

	public PanelDadosClienteDestino() {
		super();
		initialize();
	}

	private void initialize() {
		setLayout(new GridBagLayout());

		add(getTipoLabel(), getTipoLabelConstraints());
		add(getTipoComboBox(), getTipoComboBoxConstraints());

		add(getNomeLabel(), getNomeLabelConstraints());
		add(getNomeTextField(), getNomeTextFieldConstraints());

		add(getEnderecoLabel(), getEnderecoLabelConstraints());
		add(getEnderecoTextField(), getEnderecoTextFieldConstraints());

		add(getNumeroLabel(), getNumeroLabelConstraints());
		add(getNumeroTextField(), getNumeroTextFieldConstraints());

		add(getBairroLabel(), getBairroLabelConstraints());
		add(getBairroTextField(), getBairroTextFieldConstraints());

		add(getCidadeLabel(), getCidadeLabelConstraints());
		add(getCidadeTextField(), getCidadeTextFieldConstraints());

		add(getCepLabel(), getCepLabelConstraints());
		add(getCepTextField(), getCepTextFieldConstraints());

		add(getTelefoneLabel(), getTelefoneLabelConstraints());
		add(getTelefoneTextField(), getTelefoneTextFieldConstraints());

		add(getCnpjCpfLabel(), getCnpjCpfLabelConstraints());
		add(getCnpjCpfTextField(), getCnpjCpfTextFieldConstraints());

		add(getIeRgLabel(), getIeRgLabelConstraints());
		add(getIeRgTextField(), getIeRgTextFieldConstraints());

		add(getEmailLabel(), getEmailLabelConstraints());
		add(getEmailTextField(), getEmailTextFieldConstraints());

		add(getDtcadastroLabel(), getDtcadastroLabelConstraints());
		add(getDtcadstroTextField(), getDtcadastroTextFieldConstraints());

		add(getIdTextField());
	}

	private JLabel getTipoLabel() {
		if (tipoLabel == null) {
			tipoLabel = new JLabel();
			tipoLabel.setText("Tipo: ");
		}
		return tipoLabel;
	}

	private JComboBox getTipoComboBox() {
		if (tipoComboBox == null) {
			String[] itens = new String[] { "Cliente", "Destino" };

			tipoComboBox = new JComboBox(itens);
		}
		return tipoComboBox;
	}

	private JLabel getNomeLabel() {
		if (nomeLabel == null) {
			nomeLabel = new JLabel();
			nomeLabel.setText("Nome/Destino: ");
		}
		return nomeLabel;
	}

	private JTextField getNomeTextField() {
		if (nomeTextField == null) {
			nomeTextField = new JTextField();
		}
		return nomeTextField;
	}

	private JTextField getIdTextField() {
		if (idTextField == null) {
			idTextField = new JTextField();
			idTextField.setVisible(false);
		}
		return idTextField;
	}

	private JLabel getEnderecoLabel() {
		if (enderecoLabel == null) {
			enderecoLabel = new JLabel();
			enderecoLabel.setText("Endere�o: ");

		}
		return enderecoLabel;
	}

	private JTextField getEnderecoTextField() {
		if (enderecoTextField == null) {
			enderecoTextField = new JTextField();
		}
		return enderecoTextField;
	}

	private JLabel getNumeroLabel() {
		if (numeroLabel == null) {
			numeroLabel = new JLabel();
			numeroLabel.setText("Numero: ");

		}
		return numeroLabel;
	}

	private JTextField getNumeroTextField() {
		if (numeroTextField == null) {
			numeroTextField = new JTextField();
		}
		return numeroTextField;
	}

	private JLabel getBairroLabel() {
		if (bairroLabel == null) {
			bairroLabel = new JLabel();
			bairroLabel.setText("Bairro: ");

		}
		return bairroLabel;
	}

	private JTextField getBairroTextField() {
		if (bairroTextField == null) {
			bairroTextField = new JTextField();
		}
		return bairroTextField;
	}

	private JLabel getCidadeLabel() {
		if (cidadeLabel == null) {
			cidadeLabel = new JLabel();
			cidadeLabel.setText("Cidade: ");

		}
		return cidadeLabel;
	}

	private JTextField getCidadeTextField() {
		if (cidadeTextField == null) {
			cidadeTextField = new JTextField();
		}
		return cidadeTextField;
	}

	private JLabel getCepLabel() {
		if (cepLabel == null) {
			cepLabel = new JLabel();
			cepLabel.setText("CEP: ");

		}
		return cepLabel;
	}

	private JTextField getCepTextField() {
		if (cepTextField == null) {
			cepTextField = new JTextField();
		}
		return cepTextField;
	}

	private JLabel getTelefoneLabel() {
		if (telefoneLabel == null) {
			telefoneLabel = new JLabel();
			telefoneLabel.setText("Telefone: ");

		}
		return telefoneLabel;
	}

	private JFormattedTextField getTelefoneTextField() {
		if (telefoneTextField == null) {
			telefoneTextField = new JFormattedTextField(getFormatterTelefone());
		}
		return telefoneTextField;
	}

	private JLabel getCnpjCpfLabel() {
		if (cnpjCpfLabel == null) {
			cnpjCpfLabel = new JLabel();
			cnpjCpfLabel.setText("CNPJ/CPF: ");

		}
		return cnpjCpfLabel;
	}

	private JTextField getCnpjCpfTextField() {
		if (cnpjCpfTextField == null) {
			cnpjCpfTextField = new JTextField();
		}
		return cnpjCpfTextField;
	}

	private JLabel getIeRgLabel() {
		if (ieRgLabel == null) {
			ieRgLabel = new JLabel();
			ieRgLabel.setText("Inscri�ao/RG: ");

		}
		return ieRgLabel;
	}

	private JTextField getIeRgTextField() {
		if (ieRgTextField == null) {
			ieRgTextField = new JTextField();
		}
		return ieRgTextField;
	}

	private JLabel getEmailLabel() {
		if (emailLabel == null) {
			emailLabel = new JLabel();
			emailLabel.setText("E-mail: ");

		}
		return emailLabel;
	}

	private JTextField getEmailTextField() {
		if (emailTextField == null) {
			emailTextField = new JTextField();
		}
		return emailTextField;
	}

	private JLabel getDtcadastroLabel() {
		if (dtcadastroLabel == null) {
			dtcadastroLabel = new JLabel();
			dtcadastroLabel.setText("Data Cadastro: ");

		}
		return dtcadastroLabel;
	}

	private JDateChooser getDtcadstroTextField() {
		if (dtcadstroTextField == null) {
			dtcadstroTextField = new JDateChooser();
		}
		return dtcadstroTextField;
	}

	private GridBagConstraints getTipoLabelConstraints() {
		if (tipoLabelConstraints == null) {
			tipoLabelConstraints = createConstraintsPrototype();
			tipoLabelConstraints.gridx = 0;
			tipoLabelConstraints.gridy = 0;
		}
		return tipoLabelConstraints;
	}

	private GridBagConstraints getNomeLabelConstraints() {
		if (nomeLabelConstraints == null) {
			nomeLabelConstraints = createConstraintsPrototype();
			nomeLabelConstraints.gridx = 2;
			nomeLabelConstraints.gridy = 0;
		}
		return nomeLabelConstraints;
	}

	private GridBagConstraints getEnderecoLabelConstraints() {
		if (enderecoLabelConstraints == null) {
			enderecoLabelConstraints = createConstraintsPrototype();
			enderecoLabelConstraints.gridx = 0;
			enderecoLabelConstraints.gridy = 1;
		}
		return enderecoLabelConstraints;
	}

	private GridBagConstraints getNumeroLabelConstraints() {
		if (numeroLabelConstraints == null) {
			numeroLabelConstraints = createConstraintsPrototype();
			numeroLabelConstraints.gridx = 4;
			numeroLabelConstraints.gridy = 1;
		}
		return numeroLabelConstraints;
	}

	private GridBagConstraints getBairroLabelConstraints() {
		if (bairroLabelConstraints == null) {
			bairroLabelConstraints = createConstraintsPrototype();
			bairroLabelConstraints.gridx = 0;
			bairroLabelConstraints.gridy = 2;
		}
		return bairroLabelConstraints;
	}

	private GridBagConstraints getCidadeLabelConstraints() {
		if (cidadeLabelConstraints == null) {
			cidadeLabelConstraints = createConstraintsPrototype();
			cidadeLabelConstraints.gridx = 3;
			cidadeLabelConstraints.gridy = 2;
		}
		return cidadeLabelConstraints;
	}

	private GridBagConstraints getCepLabelConstraints() {
		if (cepLabelConstraints == null) {
			cepLabelConstraints = createConstraintsPrototype();
			cepLabelConstraints.gridx = 0;
			cepLabelConstraints.gridy = 3;
		}
		return cepLabelConstraints;
	}

	private GridBagConstraints getTelefoneLabelConstraints() {
		if (telefoneLabelConstraints == null) {
			telefoneLabelConstraints = createConstraintsPrototype();
			telefoneLabelConstraints.gridx = 3;
			telefoneLabelConstraints.gridy = 3;
		}
		return telefoneLabelConstraints;
	}

	private GridBagConstraints getCnpjCpfLabelConstraints() {
		if (cnpjCpfLabelConstraints == null) {
			cnpjCpfLabelConstraints = createConstraintsPrototype();
			cnpjCpfLabelConstraints.gridx = 0;
			cnpjCpfLabelConstraints.gridy = 4;
		}
		return cnpjCpfLabelConstraints;
	}

	private GridBagConstraints getIeRgLabelConstraints() {
		if (ieRgLabelConstraints == null) {
			ieRgLabelConstraints = createConstraintsPrototype();
			ieRgLabelConstraints.gridx = 3;
			ieRgLabelConstraints.gridy = 4;
		}
		return ieRgLabelConstraints;
	}

	private GridBagConstraints getEmailLabelConstraints() {
		if (emailLabelConstraints == null) {
			emailLabelConstraints = createConstraintsPrototype();
			emailLabelConstraints.gridx = 0;
			emailLabelConstraints.gridy = 5;
		}
		return emailLabelConstraints;
	}

	private GridBagConstraints getDtcadastroLabelConstraints() {
		if (dtcadastroLabelConstraints == null) {
			dtcadastroLabelConstraints = createConstraintsPrototype();
			dtcadastroLabelConstraints.gridx = 3;
			dtcadastroLabelConstraints.gridy = 5;
		}
		return dtcadastroLabelConstraints;
	}

	private GridBagConstraints getTipoComboBoxConstraints() {
		if (tipoComboBoxConstraints == null) {
			tipoComboBoxConstraints = createConstraintsPrototype();
			tipoComboBoxConstraints.gridx = 1;
			tipoComboBoxConstraints.gridy = 0;
		}

		return tipoComboBoxConstraints;
	}

	private GridBagConstraints getNomeTextFieldConstraints() {
		if (nomeTextFieldConstraints == null) {
			nomeTextFieldConstraints = createConstraintsPrototype();
			nomeTextFieldConstraints.gridx = 3;
			nomeTextFieldConstraints.gridy = 0;
			nomeTextFieldConstraints.gridwidth = 5;
		}
		return nomeTextFieldConstraints;
	}

	private GridBagConstraints getEnderecoTextFieldConstraints() {
		if (enderecoTextFieldConstraints == null) {
			enderecoTextFieldConstraints = createConstraintsPrototype();
			enderecoTextFieldConstraints.gridx = 1;
			enderecoTextFieldConstraints.gridy = 1;
			enderecoTextFieldConstraints.gridwidth = 3;
		}
		return enderecoTextFieldConstraints;
	}

	private GridBagConstraints getNumeroTextFieldConstraints() {
		if (numeroTextFieldConstraints == null) {
			numeroTextFieldConstraints = createConstraintsPrototype();
			numeroTextFieldConstraints.gridx = 5;
			numeroTextFieldConstraints.gridy = 1;
			numeroTextFieldConstraints.ipadx = 100;
		}
		return numeroTextFieldConstraints;
	}

	private GridBagConstraints getBairroTextFieldConstraints() {
		if (bairroTextFieldConstraints == null) {
			bairroTextFieldConstraints = createConstraintsPrototype();
			bairroTextFieldConstraints.gridx = 1;
			bairroTextFieldConstraints.gridy = 2;
			bairroTextFieldConstraints.gridwidth = 2;
			bairroTextFieldConstraints.ipadx = 100;
		}
		return bairroTextFieldConstraints;
	}

	private GridBagConstraints getCidadeTextFieldConstraints() {
		if (cidadeTextFieldConstraints == null) {
			cidadeTextFieldConstraints = createConstraintsPrototype();
			cidadeTextFieldConstraints.gridx = 4;
			cidadeTextFieldConstraints.gridy = 2;
			cidadeTextFieldConstraints.gridwidth = 2;
		}
		return cidadeTextFieldConstraints;
	}

	private GridBagConstraints getCepTextFieldConstraints() {
		if (cepTextFieldConstraints == null) {
			cepTextFieldConstraints = createConstraintsPrototype();
			cepTextFieldConstraints.gridx = 1;
			cepTextFieldConstraints.gridy = 3;
			cepTextFieldConstraints.gridwidth = 2;
		}
		return cepTextFieldConstraints;
	}

	private GridBagConstraints getTelefoneTextFieldConstraints() {
		if (telefoneTextFieldConstraints == null) {
			telefoneTextFieldConstraints = createConstraintsPrototype();
			telefoneTextFieldConstraints.gridx = 4;
			telefoneTextFieldConstraints.gridy = 3;
			telefoneTextFieldConstraints.gridwidth = 2;
		}
		return telefoneTextFieldConstraints;
	}

	private GridBagConstraints getCnpjCpfTextFieldConstraints() {
		if (cnpjCpfTextFieldConstraints == null) {
			cnpjCpfTextFieldConstraints = createConstraintsPrototype();
			cnpjCpfTextFieldConstraints.gridx = 1;
			cnpjCpfTextFieldConstraints.gridy = 4;
			cnpjCpfTextFieldConstraints.gridwidth = 2;
		}
		return cnpjCpfTextFieldConstraints;
	}

	private GridBagConstraints getIeRgTextFieldConstraints() {
		if (ieRgTextFieldConstraints == null) {
			ieRgTextFieldConstraints = createConstraintsPrototype();
			ieRgTextFieldConstraints.gridx = 4;
			ieRgTextFieldConstraints.gridy = 4;
			ieRgTextFieldConstraints.gridwidth = 2;
		}
		return ieRgTextFieldConstraints;
	}

	private GridBagConstraints getEmailTextFieldConstraints() {
		if (emailTextFieldConstraints == null) {
			emailTextFieldConstraints = createConstraintsPrototype();
			emailTextFieldConstraints.gridx = 1;
			emailTextFieldConstraints.gridy = 5;
			emailTextFieldConstraints.gridwidth = 2;
		}
		return emailTextFieldConstraints;
	}

	private GridBagConstraints getDtcadastroTextFieldConstraints() {
		if (dtcadastroTextFieldConstraints == null) {
			dtcadastroTextFieldConstraints = createConstraintsPrototype();
			dtcadastroTextFieldConstraints.gridx = 4;
			dtcadastroTextFieldConstraints.gridy = 5;
			dtcadastroTextFieldConstraints.gridwidth = 2;
		}
		return dtcadastroTextFieldConstraints;
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

	private MaskFormatter getFormatterTelefone() {
		try {
			MaskFormatter formatter = new MaskFormatter();
			formatter.setMask("(##)####-####");
			formatter.setPlaceholderCharacter('_');
			return formatter;
		} catch (ParseException e) {
			return new MaskFormatter();
		}
	}

	public ClienteDestinoTO getClienteDestinoTO() {
		if (clienteDestinoTO == null) {
			clienteDestinoTO = new ClienteDestinoTO();
		}

		clienteDestinoTO.setTipo((String) getTipoComboBox().getSelectedItem());
		clienteDestinoTO.setNome(getNomeTextField().getText());
		clienteDestinoTO.setEndereco(getEnderecoTextField().getText());
		clienteDestinoTO.setBairro(getBairroTextField().getText());
		clienteDestinoTO.setCidade(getCidadeTextField().getText());
		clienteDestinoTO.setCep(getCepTextField().getText());
		clienteDestinoTO.setTelefone(getTelefoneTextField().getText());
		clienteDestinoTO.setCnpjCpf(getCnpjCpfTextField().getText());
		clienteDestinoTO.setInscRg(getIeRgTextField().getText());
		clienteDestinoTO.setE_mail(getEmailTextField().getText());
		clienteDestinoTO.setDataCad(getDtcadstroTextField().getDate());

		if (!lernumero(clienteDestinoTO)) {
			return null;
		}
		return clienteDestinoTO;
	}

	public void setClienteDestinoTO(ClienteDestinoTO clienteDestino) {
		if (clienteDestino == null) {
			clienteDestino = new ClienteDestinoTO();
		}

		getIdTextField().setText(Integer.toString(clienteDestino.getId()));
		getTipoComboBox().setSelectedItem(clienteDestino.getTipo());
		getNomeTextField().setText(clienteDestino.getNome());
		getEnderecoTextField().setText(clienteDestino.getEndereco());
		getNumeroTextField().setText(
				Integer.toString(clienteDestino.getNumero()));
		getBairroTextField().setText(clienteDestino.getBairro());
		getCidadeTextField().setText(clienteDestino.getCidade());
		getCepTextField().setText(clienteDestino.getCep());
		getTelefoneTextField().setText(clienteDestino.getTelefone());
		getCnpjCpfTextField().setText(clienteDestino.getCnpjCpf());
		getIeRgTextField().setText(clienteDestino.getInscRg());
		getEmailTextField().setText(clienteDestino.getE_mail());
		getDtcadstroTextField().setDate(clienteDestino.getDataCad());

	}

	public ClienteDestinoTO getEditarClienteDestinoTO() {
		if (clienteDestinoTO == null) {
			clienteDestinoTO = new ClienteDestinoTO();
		}
		clienteDestinoTO.setId(Integer.parseInt(getIdTextField().getText()));
		clienteDestinoTO.setTipo((String) getTipoComboBox().getSelectedItem());
		clienteDestinoTO.setNome(getNomeTextField().getText());
		clienteDestinoTO.setEndereco(getEnderecoTextField().getText());
		clienteDestinoTO.setBairro(getBairroTextField().getText());
		clienteDestinoTO.setCidade(getCidadeTextField().getText());
		clienteDestinoTO.setCep(getCepTextField().getText());
		clienteDestinoTO.setTelefone(getTelefoneTextField().getText());
		clienteDestinoTO.setCnpjCpf(getCnpjCpfTextField().getText());
		clienteDestinoTO.setInscRg(getIeRgTextField().getText());
		clienteDestinoTO.setE_mail(getEmailTextField().getText());
		clienteDestinoTO.setDataCad(getDtcadstroTextField().getDate());

		if (!lernumero(clienteDestinoTO)) {
			return null;
		}
		return clienteDestinoTO;

	}

	private boolean lernumero(ClienteDestinoTO clienteDestinoTO) {

		String num = "";

		try {
			num = getNumeroTextField().getText();
			Integer numero = Integer.parseInt(num);
			clienteDestinoTO.setNumero(numero);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,
					"Favor � obrigat�rio preencher o campo numero da casa");
			return false;
		}
		return true;
	}

	public void addDadosClienteDest(DadosClienteDestino listener) {
		listeners.add(listener);
	}

	public void setData() {
		getCepTextField().setText("37550-000");
		getCidadeTextField().setText("Pouso Alegre");
		getNumeroTextField().setText("0");
		getDtcadstroTextField().setDate(new Date());
	}

}
