package edu.univas.projeto.tcc.view;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import edu.univas.projeto.tcc.listeners.ButtonsListener;
import edu.univas.projeto.tcc.listeners.DadosFrete;
import edu.univas.projeto.tcc.model.FreteTO;

public class FrameCadastroFrete extends JFrame {

	private static final long serialVersionUID = 2884354886849662451L;
	private PanelDadosFrete panelDadosFrete;
	private PanelButtons panelButtons;
	private TitledBorder titledBorder;

	private ArrayList<DadosFrete> listeners = new ArrayList<DadosFrete>();

	public FrameCadastroFrete() {
		super("Cadastro de Fretes");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		initialize();

		pack();

		setLocationRelativeTo(null);

	}

	private void initialize() {

		add(getPanelDadosFrete(), BorderLayout.CENTER);
		add(getPanelButtons(), BorderLayout.SOUTH);

	}

	private TitledBorder getTitledBorderDados() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory
				.createTitledBorder(loweredetched, "Dados ");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	private TitledBorder getTitledBorderButtons() {

		Border loweredetched = BorderFactory
				.createEtchedBorder(EtchedBorder.LOWERED);
		titledBorder = BorderFactory.createTitledBorder(loweredetched, "");
		titledBorder.setTitleJustification(TitledBorder.LEFT);

		return titledBorder;
	}

	public PanelDadosFrete getPanelDadosFrete() {
		if (panelDadosFrete == null) {
			panelDadosFrete = new PanelDadosFrete();
			panelDadosFrete.setBorder(getTitledBorderDados());
		}
		return panelDadosFrete;
	}

	private PanelButtons getPanelButtons() {
		if (panelButtons == null) {
			panelButtons = new PanelButtons();
			panelButtons.setBorder(getTitledBorderButtons());
			panelButtons.addButtonsListener(new ButtonsListener() {

				@Override
				public void cancelar() {
					for (DadosFrete listener : listeners) {
						listener.dadosCancelados();
					}

				}

				@Override
				public void gravar() {
					FreteTO freteTO = getPanelDadosFrete().getFreteTO();
					if (freteTO != null) {
						for (DadosFrete listener : listeners) {
							listener.dadosgravados(freteTO);
						}
					}

				}

			});
		}
		return panelButtons;
	}

	public void addDadosFrete(DadosFrete listener) {
		listeners.add(listener);
		getPanelDadosFrete().addDadosFrete(listener);
	}
}