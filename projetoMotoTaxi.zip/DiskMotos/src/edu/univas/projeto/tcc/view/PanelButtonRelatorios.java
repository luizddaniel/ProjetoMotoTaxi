package edu.univas.projeto.tcc.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.PesquisaButtonRelatorios;

public class PanelButtonRelatorios extends JPanel {

	private static final long serialVersionUID = 8692873537734120840L;

	private JLabel dtInicLabel;
	private JLabel dtFimLabel;
	private JButton fecharButton;
	private JButton gerarButton;
	private JDateChooser dtInicField;
	private JDateChooser dtFimField;
	private JButton listarButton;

	private GridBagConstraints dtInicLabelConstraints;
	private GridBagConstraints dtFimLabelConstraints;
	private GridBagConstraints fecharButtonConstraints;
	private GridBagConstraints listarButtonConstraints;
	private GridBagConstraints gerarButtonConstraints;
	private GridBagConstraints dtInicFieldConstraints;
	private GridBagConstraints dtFimFieldConstraints;

	private ArrayList<PesquisaButtonRelatorios> listeners = new ArrayList<PesquisaButtonRelatorios>();

	public PanelButtonRelatorios() {
		super();
		getDtFimField().setDate(new Date());
		getDtInicField().setDate(new Date());
		initialize();
	}

	private void initialize() {

		setLayout(new GridBagLayout());

		add(getDtInicLabel(), getDtInicLabelConstraints());
		add(getDtInicField(), getDtInicFieldConstraints());

		add(getDtFimLabel(), getDtFimLabelConstraints());
		add(getDtFimField(), getDtFimFieldConstraints());

		add(getGerarButton(), getGerarButtonConstraints());
		add(getFecharButton(), getFecharButtonConstraints());
		add(getListarButton(), getListarButtonConstraints());
	}

	private JButton getGerarButton() {
		if (gerarButton == null) {

			URL pathToImage = getClass().getResource(
					"/edu/univas/projeto/tcc/files/rela.png");
			gerarButton = new JButton("Gerar Relat�rio ", new ImageIcon(
					pathToImage));
			gerarButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {

					for (PesquisaButtonRelatorios listener : listeners) {
						listener.pesquisar(getDtInicField(), getDtFimField());
					}
				}
			});
		}

		return gerarButton;
	}

	private JButton getListarButton() {
		if (listarButton == null) {

			URL pathToImage = getClass().getResource(
					"/edu/univas/projeto/tcc/files/rela.png");
			listarButton = new JButton("Pesquisar ", new ImageIcon(pathToImage));
			listarButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// System.out.println("Data " + getDtInicField());
					for (PesquisaButtonRelatorios listener : listeners) {
						listener.pesquisarTale(getDtInicField(),
								getDtFimField());
					}
				}
			});
		}

		return listarButton;
	}

	private JDateChooser getDtInicField() {
		if (dtInicField == null) {
			dtInicField = new JDateChooser();
			dtInicField.setToolTipText("Coloque a data inicial para pesquisa");

		}
		return dtInicField;
	}

	private JDateChooser getDtFimField() {
		if (dtFimField == null) {
			dtFimField = new JDateChooser();
			dtFimField.setToolTipText("Coloque a data final para pesquisa");

		}
		return dtFimField;
	}

	private JButton getFecharButton() {
		if (fecharButton == null) {

			URL pathToImage = getClass().getResource(
					"/edu/univas/projeto/tcc/files/fechar.png");
			fecharButton = new JButton("Cancelar", new ImageIcon(pathToImage));
			fecharButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for (PesquisaButtonRelatorios listener : listeners) {
						listener.fechar();
					}
				}
			});
		}

		return fecharButton;
	}

	private JLabel getDtInicLabel() {
		if (dtInicLabel == null) {
			dtInicLabel = new JLabel();
			dtInicLabel.setText("Data Inicial ");
		}
		return dtInicLabel;
	}

	private JLabel getDtFimLabel() {
		if (dtFimLabel == null) {
			dtFimLabel = new JLabel();
			dtFimLabel.setText("Data Final ");
		}

		return dtFimLabel;
	}

	private GridBagConstraints getDtInicLabelConstraints() {
		if (dtInicLabelConstraints == null) {
			dtInicLabelConstraints = createConstraintsPrototype();
			dtInicLabelConstraints.gridx = 0;
			dtInicLabelConstraints.gridy = 0;
		}

		return dtInicLabelConstraints;
	}

	private GridBagConstraints getDtFimLabelConstraints() {
		if (dtFimLabelConstraints == null) {
			dtFimLabelConstraints = createConstraintsPrototype();
			dtFimLabelConstraints.gridx = 2;
			dtFimLabelConstraints.gridy = 0;

		}

		return dtFimLabelConstraints;
	}

	private GridBagConstraints getFecharButtonConstraints() {
		if (fecharButtonConstraints == null) {
			fecharButtonConstraints = createConstraintsPrototype();
			fecharButtonConstraints.gridx = 7;
			fecharButtonConstraints.gridy = 0;

		}

		return fecharButtonConstraints;
	}

	private GridBagConstraints getGerarButtonConstraints() {
		if (gerarButtonConstraints == null) {
			gerarButtonConstraints = createConstraintsPrototype();
			gerarButtonConstraints.gridx = 4;
			gerarButtonConstraints.gridy = 0;

		}

		return gerarButtonConstraints;
	}

	private GridBagConstraints getListarButtonConstraints() {
		if (listarButtonConstraints == null) {
			listarButtonConstraints = createConstraintsPrototype();
			listarButtonConstraints.gridx = 6;
			listarButtonConstraints.gridy = 0;

		}

		return listarButtonConstraints;
	}

	private GridBagConstraints getDtInicFieldConstraints() {
		if (dtInicFieldConstraints == null) {
			dtInicFieldConstraints = createConstraintsPrototype();
			dtInicFieldConstraints.gridx = 1;
			dtInicFieldConstraints.gridy = 0;
			dtInicFieldConstraints.ipadx = 15;

		}

		return dtInicFieldConstraints;
	}

	private GridBagConstraints getDtFimFieldConstraints() {
		if (dtFimFieldConstraints == null) {
			dtFimFieldConstraints = createConstraintsPrototype();
			dtFimFieldConstraints.gridx = 3;
			dtFimFieldConstraints.gridy = 0;
			dtFimFieldConstraints.ipadx = 15;

		}

		return dtFimFieldConstraints;
	}

	public void addButtonsRelatorio(PesquisaButtonRelatorios listener) {
		if (listener != null) {
			listeners.add(listener);
		}
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

}
