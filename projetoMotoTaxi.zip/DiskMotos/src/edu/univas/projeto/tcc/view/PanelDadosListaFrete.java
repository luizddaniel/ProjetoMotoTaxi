package edu.univas.projeto.tcc.view;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import edu.univas.projeto.tcc.listeners.ConsultaFrete;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;
import edu.univas.projeto.tcc.model.FreteTO;

public class PanelDadosListaFrete extends JPanel {

	private static final long serialVersionUID = -4830920684384899652L;

	private ArrayList<ConsultaFrete> listeners = new ArrayList<ConsultaFrete>();

	private JTable table;
	private JScrollPane scrolltable;
	private DefaultTableModel tableModel;
	private GridBagConstraints scrollTableConstraints;

	public PanelDadosListaFrete() {
		super();
		initialize();
	}

	private void initialize() {
		setLayout(new GridBagLayout());

		add(getScrolltable(), getScrollTableConstraints());
	}

	private JTable getTable() {
		if (table == null) {
			table = new JTable();
			table.setAutoCreateRowSorter(true);

			table.setModel(getTableModel());

//			TableColumn col7 = table.getColumnModel().getColumn(7);
//			col7.setCellRenderer(new DateRenderer());
//			TableColumn col6 = table.getColumnModel().getColumn(6);
//			col6.setCellRenderer(new DateRenderer());
		}
		return table;
	}

//	static class DateRenderer extends JButton implements TableCellRenderer {
//		DateFormat formatter = new SimpleDateFormat("dd/mm");
//
//		public DateRenderer() {
//			super();
//		}
//
//		public void setValue(Object value) {
//			setText((value == null) ? "" : formatter.format(value));
//		}
//
//		@Override
//		public Component getTableCellRendererComponent(JTable table,
//				Object value, boolean isSelected, boolean hasFocus,
//				int rowIndex, int vColIndex) {
//			setText(value.toString());// (value == null) ? "" :
//			// formatter.format(value));
//
//			return this;
//		}
//
//	}
//
//	class ButtonEditor extends JButton implements TableCellEditor {
//		public ButtonEditor() {
//			super("Button");
//		}
//
//		public Component getTableCellEditorComponent(JTable table,
//				Object value, boolean isSelected, int row, int column) {
//			buttonPressed(table, row, column);
//			return this;
//		}
//
//		private void buttonPressed(JTable table, int row, int column) {
//			JOptionPane.showMessageDialog(table, "Pressed at " + row + "x"
//					+ column);
//		}
//
//		@Override
//		public void addCellEditorListener(CellEditorListener arg0) {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public void cancelCellEditing() {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public Object getCellEditorValue() {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//		public boolean isCellEditable(EventObject anEvent) {
//			return true;
//		}
//
//		@Override
//		public void removeCellEditorListener(CellEditorListener l) {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public boolean shouldSelectCell(EventObject anEvent) {
//			// TODO Auto-generated method stub
//			return false;
//		}
//
//		@Override
//		public boolean stopCellEditing() {
//			// TODO Auto-generated method stub
//			return false;
//		}
//	}

	private DefaultTableModel getTableModel() {
		if (tableModel == null) {
			tableModel = new DefaultTableModel() {

				private static final long serialVersionUID = 1L;

				public boolean isCellEditable(int rowIndex, int columnIndex) {
//					if (columnIndex == 7) {
//						return true;
//					}
					return false;
				}

			};
		}

		tableModel.setColumnIdentifiers(new String[] { "Codigo", "N� Frete",
				"Destino", "Motoqueiro", "Hora Liga��o", "Hora Saida",
				"Hora Chegada", "Data", "Valor"

		});

		return tableModel;
	}

	public void setFreteTable(ArrayList<FreteTO> freteTO) {
		for (FreteTO frete : freteTO) {
			String[] linha = new String[] { Integer.toString(frete.getId()),
					Integer.toString(frete.getNumFrete()), frete.getDestino(),
					frete.getMotoq(), frete.getHoraLig(), frete.getHoraSaida(),
					frete.getHoraCheg(), apresentarData(frete),
					Float.toString(frete.getValor()) };
			getTableModel().addRow(linha);
			//TableColumn col7 = table.getColumnModel().getColumn(7);
			//col7.setCellRenderer(new DateRenderer());
			//col7.setCellEditor(new ButtonEditor());
			getTable().repaint();
		}
	}

	public void limparTable() {
		getTableModel().setNumRows(0);
	}

	public void setFreteTableModel(FreteTO frete) {
		// for (FreteTO frete : freteTO) {
		String[] linha = new String[] { Integer.toString(frete.getId()),
				Integer.toString(frete.getNumFrete()), frete.getDestino(),
				frete.getMotoq(), frete.getHoraLig(), frete.getHoraSaida(),
				frete.getHoraCheg(), apresentarData(frete),
				Float.toString(frete.getValor()) };
		getTableModel().addRow(linha);
		getTable().repaint();
		// }
	}

	private String apresentarData(FreteTO frete) {

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

		Date dtnasc = null;

		dtnasc = frete.getData();
		String dtnasc1 = format.format(dtnasc);

		return dtnasc1;
	}

	private JScrollPane getScrolltable() {
		if (scrolltable == null) {
			scrolltable = new JScrollPane();
			scrolltable.setViewportView(getTable());
			scrolltable.setPreferredSize(new Dimension(0, 0));

		}
		return scrolltable;
	}

	private GridBagConstraints getScrollTableConstraints() {
		if (scrollTableConstraints == null) {
			scrollTableConstraints = createConstraintsPrototype();
			scrollTableConstraints.gridx = 0;
			scrollTableConstraints.gridy = 0;
			scrollTableConstraints.gridwidth = 1;
			scrollTableConstraints.ipady = 300;
			scrollTableConstraints.ipadx = 750;
		}
		return scrollTableConstraints;
	}

	public void addClienteTable(ClienteDestinoTO clienteDestino) {
		String[] linha = new String[] {
				Integer.toString(clienteDestino.getId()),
				clienteDestino.getNome(), clienteDestino.getEndereco(),
				Integer.toString(clienteDestino.getNumero()),
				clienteDestino.getBairro(), clienteDestino.getCidade(),
				clienteDestino.getCep(), clienteDestino.getTelefone(),
				clienteDestino.getE_mail() };
		getTableModel().addRow(linha);
	}

	private GridBagConstraints createConstraintsPrototype() {

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.insets = new Insets(3, 3, 3, 3);

		return gbc;
	}

	public void addConsultaFrete(ConsultaFrete listener) {
		listeners.add(listener);
	}
}
