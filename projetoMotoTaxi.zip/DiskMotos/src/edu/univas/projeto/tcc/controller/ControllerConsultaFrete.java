package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;
import java.util.Date;

import javax.swing.JOptionPane;

import edu.univas.projeto.tcc.listeners.ConsultaFrete;
import edu.univas.projeto.tcc.model.DAOException;
import edu.univas.projeto.tcc.model.FreteDAO;
import edu.univas.projeto.tcc.model.FreteTO;
import edu.univas.projeto.tcc.view.FrameConsultaFrete;

public class ControllerConsultaFrete {

	private FreteDAO freteDAO;
	private FrameConsultaFrete frameConsultaFrete;

	public ControllerConsultaFrete(FreteDAO freteDAO) {
		this.freteDAO = freteDAO;
	}

	public void listarFretes() {

		try {
			ArrayList<FreteTO> fretes = freteDAO.listarFretes();
			frameConsultaFrete = new FrameConsultaFrete();
			frameConsultaFrete.limpaDadosFrete();
			frameConsultaFrete.setDadosFrete(fretes);
		} catch (DAOException e) {
			e.printStackTrace();
		}

		frameConsultaFrete.addConsultaFrete(new ConsultaFrete() {

			@Override
			public void cancelar() {
				frameConsultaFrete.dispose();

			}

			@Override
			public void editar(String codigo) {
				ControllerEditarFrete frete = new ControllerEditarFrete(
						freteDAO, frameConsultaFrete);
				try {
					if (!codigo.equals("")) {
						FreteTO freteTO = freteDAO.buscarFrete(codigo);
						if (freteTO.getId() != null) {
							frete.editarCadastro(freteTO);
						}
					} else {
						JOptionPane
								.showMessageDialog(null,
										"Favor preencher campo com o c�digo para editar!");
					}
				} catch (DAOException e) {
					JOptionPane.showMessageDialog(null, "C�digo Inexistente!");
					e.printStackTrace();
				}

			}

			@Override
			public void excluir(String codigo) {
				try {
					if (JOptionPane.showConfirmDialog(null,
							"Voc� Deseja realmente excluir o registro de c�digo "
									+ codigo + "?", "Sistema Disk Motos",
							JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
						freteDAO.excluirFrete(codigo);
					}
					relacaoTela();
				} catch (DAOException e) {
					e.printStackTrace();
				}

			}

			@Override
			public void fechar() {
				frameConsultaFrete.dispose();

			}

			@Override
			public void incluir() {
				ControllerCadastroFrete frete = new ControllerCadastroFrete(
						freteDAO, frameConsultaFrete);
				frete.criarNovoCadastro();

			}

			@Override
			public void listarTudo() {

				try {
					ArrayList<FreteTO> fretes = freteDAO.listarTudo();
					frameConsultaFrete.limpaDadosFrete();
					frameConsultaFrete.setDadosFrete(fretes);

				} catch (DAOException e) {
					e.printStackTrace();
				}

			}

			@Override
			public void relacaoTela() {
				try {
					ArrayList<FreteTO> fretes = freteDAO.listarFretes();
					frameConsultaFrete.limpaDadosFrete();
					frameConsultaFrete.setDadosFrete(fretes);
					// frameConsultaFrete.setVisible(true);
				} catch (DAOException e) {
					e.printStackTrace();
				}

			}

			@Override
			public void pesquisar(Date data, String pesq1, String pesq2,
					Integer pesq3) {
				try {
					if ((data == null) && (pesq1.equals(""))
							&& (pesq2.equals("")) && (pesq3 == null)) {
						JOptionPane.showMessageDialog(null,
								"Favor preencher algum campo para pesquisar!");
					} else {

						ArrayList<FreteTO> fretes = freteDAO.pesquisarFrete(
								data, pesq1, pesq2, pesq3);
						frameConsultaFrete.limpaDadosFrete();
						frameConsultaFrete.setDadosFrete(fretes);
					}
				} catch (DAOException e) {
					e.printStackTrace();

				}
			}

		});
		frameConsultaFrete.setResizable(false);
		frameConsultaFrete.setLocationRelativeTo(null);
		frameConsultaFrete.setVisible(true);

	}
}
