package edu.univas.projeto.tcc.controller;

import javax.swing.JOptionPane;

import edu.univas.projeto.tcc.listeners.DadosLogin;
import edu.univas.projeto.tcc.model.UsuarioTO;
import edu.univas.projeto.tcc.view.LoginFrame;

public class ControllerLogin {

	private LoginFrame loginFrame;

	public void login() {
		loginFrame = new LoginFrame();
		loginFrame.addLoginListener(new DadosLogin() {

			@Override
			public void dadosLogin(UsuarioTO usuario) {
				if (usuario.getLogin().equals("admin")
						&& usuario.getSenha().equals("1234")) {
					loginFrame.setVisible(false);
					new Runner().main();
				} else {
					JOptionPane.showMessageDialog(null,
							"Login ou senha inv�lida");
					loginFrame.dispose();
					new ControllerLogin().login();
				}
			}
		});
		loginFrame.setVisible(true);
	}
}
