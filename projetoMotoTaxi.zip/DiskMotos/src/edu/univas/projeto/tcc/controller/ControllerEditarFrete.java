package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import edu.univas.projeto.tcc.listeners.DadosFrete;
import edu.univas.projeto.tcc.model.DAOException;
import edu.univas.projeto.tcc.model.FreteDAO;
import edu.univas.projeto.tcc.model.FreteTO;
import edu.univas.projeto.tcc.view.FrameConsultaFrete;
import edu.univas.projeto.tcc.view.FrameEditarFrete;

public class ControllerEditarFrete {

	private FreteDAO freteDAO;
	private FrameEditarFrete frameEditarFrete;
	private FrameConsultaFrete frameConsultaFrete;

	public ControllerEditarFrete(FreteDAO freteDAO,
			FrameConsultaFrete frameConsultaFrete) {
		this.freteDAO = freteDAO;
		this.frameConsultaFrete = frameConsultaFrete;
	}

	public void editarCadastro(FreteTO freteTO) {

		frameEditarFrete = new FrameEditarFrete();
		frameEditarFrete.getPanelDadosFrete().setFreteTO(freteTO);
		String hora = freteTO.getHoraSaida();
		if(freteTO.getValor() == 0 && hora.equals("__:__")){
			frameEditarFrete.getPanelDadosFrete().setDataHoraSaida();
		}else if(freteTO.getValor() == 0){
		frameEditarFrete.getPanelDadosFrete().setDataHoras();
		}	
		frameEditarFrete.addDadosEdicaoFrete(new DadosFrete() {

			@Override
			public void dadosCancelados() {
				frameEditarFrete.dispose();

			}

			@Override
			public void dadosgravados(FreteTO freteTO) {

				editarFrete(freteTO);
				frameEditarFrete.dispose();
				try {
					ArrayList<FreteTO> fretes = freteDAO.listarFretes();
					frameConsultaFrete.limpaDadosFrete();
					frameConsultaFrete.setDadosFrete(fretes);
				} catch (DAOException e) {
					e.printStackTrace();
				}

			}

		});
		frameEditarFrete.setResizable(false);
		frameEditarFrete.setLocationRelativeTo(null);
		frameEditarFrete.setVisible(true);
	}

	private void editarFrete(FreteTO freteTO) {

		try {
			freteDAO.editarFrete(freteTO);
		} catch (DAOException e) {
			JOptionPane.showMessageDialog(null, "Ocorreu o seguinte erro: "
					+ e.getMessage());
			e.printStackTrace();
		}
	}
}
