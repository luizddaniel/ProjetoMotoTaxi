package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import edu.univas.projeto.tcc.listeners.DadosMotoqueiro;
import edu.univas.projeto.tcc.model.DAOException;
import edu.univas.projeto.tcc.model.MotoqueiroDAO;
import edu.univas.projeto.tcc.model.MotoqueiroTO;
import edu.univas.projeto.tcc.view.FrameCadastroMotoqueiro;
import edu.univas.projeto.tcc.view.FrameConsultaMotoqueiro;

public class ControllerCadastroMotoqueiro {

	private MotoqueiroDAO motoqueiroDAO;
	private FrameCadastroMotoqueiro frameCadastroMotoqueiro;
	private FrameConsultaMotoqueiro frameConsultaMotoqueiro;

	public ControllerCadastroMotoqueiro(MotoqueiroDAO motoqueiroDAO,
			FrameConsultaMotoqueiro frameConsultaMotoqueiro) {
		this.motoqueiroDAO = motoqueiroDAO;
		this.frameConsultaMotoqueiro = frameConsultaMotoqueiro;
	}

	public void criarNovoCadastro() {
		frameCadastroMotoqueiro = new FrameCadastroMotoqueiro();
		frameCadastroMotoqueiro.getPanelDadosMotoqueiro().setData();
		frameCadastroMotoqueiro.addDadosMotoqueiro(new DadosMotoqueiro() {

			@Override
			public void dadosCancelados() {
				frameCadastroMotoqueiro.dispose();
			}

			@Override
			public void dadosgravados(MotoqueiroTO motoqueiroTO) {

				if (motoqueiroTO.getNumMotoq() == null
						|| motoqueiroTO.getNumero() == null) {
					JOptionPane
							.showMessageDialog(null,
									"Favor � obrigat�rio preencher o campo numero do motoqueiro e o n�mero da casa");

				} else {
					inserirMotoqueiro(motoqueiroTO);
					frameCadastroMotoqueiro.dispose();
				}
				try {
					ArrayList<MotoqueiroTO> motoqueiros = motoqueiroDAO
							.listarMotoqueiros();
					frameConsultaMotoqueiro.limpaTable();
					frameConsultaMotoqueiro.setDadosMotoqueiro(motoqueiros);
				} catch (DAOException e) {

					e.printStackTrace();
				}

			}

		});
		frameCadastroMotoqueiro.setResizable(false);
		frameCadastroMotoqueiro.setLocationRelativeTo(null);
		frameCadastroMotoqueiro.setVisible(true);
	}

	private void inserirMotoqueiro(MotoqueiroTO motoqueiroTO) {

		try {
			motoqueiroDAO.cadastrarMotoqueiro(motoqueiroTO);
		} catch (DAOException e) {
			JOptionPane.showMessageDialog(null, "Ocorreu o seguinte erro: "
					+ e.getMessage());
			e.printStackTrace();
		}
	}
}
