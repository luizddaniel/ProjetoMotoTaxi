package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import edu.univas.projeto.tcc.listeners.DadosFrete;
import edu.univas.projeto.tcc.model.DAOException;
import edu.univas.projeto.tcc.model.FreteDAO;
import edu.univas.projeto.tcc.model.FreteTO;
import edu.univas.projeto.tcc.view.FrameCadastroFrete;
import edu.univas.projeto.tcc.view.FrameConsultaFrete;

public class ControllerCadastroFrete {
	private FreteDAO freteDAO;
	private FrameCadastroFrete frameCadastroFrete;
	private FrameConsultaFrete frameConsultaFrete;

	public ControllerCadastroFrete(FreteDAO freteDAO,
			FrameConsultaFrete frameConsultaFrete) {
		this.freteDAO = freteDAO;
		this.frameConsultaFrete = frameConsultaFrete;
	}

	public void criarNovoCadastro() {
		frameCadastroFrete = new FrameCadastroFrete();
		frameCadastroFrete.getPanelDadosFrete().setDataHoras();
		frameCadastroFrete.addDadosFrete(new DadosFrete() {

			@Override
			public void dadosCancelados() {
				frameCadastroFrete.dispose();
			}

			@Override
			public void dadosgravados(FreteTO freteTO) {
				inserirFrete(freteTO);
				frameCadastroFrete.dispose();
				try {
					ArrayList<FreteTO> fretes = freteDAO.listarFretes();
					frameConsultaFrete.limpaDadosFrete();
					frameConsultaFrete.setDadosFrete(fretes);
				} catch (DAOException e) {
					e.printStackTrace();
				}
			}

		});
		frameCadastroFrete.setResizable(false);
		frameCadastroFrete.setLocationRelativeTo(null);
		frameCadastroFrete.setVisible(true);
	}

	private void inserirFrete(FreteTO frete) {

		try {
			freteDAO.cadastrarFrete(frete);
		} catch (DAOException e) {
			JOptionPane.showMessageDialog(null, "Ocorreu o seguinte erro: "
					+ e.getMessage());
			e.printStackTrace();
		}
	}
}
