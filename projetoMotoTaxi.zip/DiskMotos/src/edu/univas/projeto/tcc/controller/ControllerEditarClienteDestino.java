package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import edu.univas.projeto.tcc.listeners.DadosClienteDestino;
import edu.univas.projeto.tcc.model.ClienteDestinoDAO;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;
import edu.univas.projeto.tcc.model.DAOException;
import edu.univas.projeto.tcc.view.FrameConsultaClienteDestino;
import edu.univas.projeto.tcc.view.FrameEditarClienteDestino;

public class ControllerEditarClienteDestino {

	private ClienteDestinoDAO clienteDestinoDAO;
	private FrameEditarClienteDestino frameEditarClienteDestino;
	private FrameConsultaClienteDestino frameConsultaClienteDestino;

	public ControllerEditarClienteDestino(
			ClienteDestinoDAO clienteDestinoDAO,
			FrameConsultaClienteDestino frameConsultaClienteDestino) {
		this.clienteDestinoDAO = clienteDestinoDAO;
		this.frameConsultaClienteDestino = frameConsultaClienteDestino;
	}

	public void editarCadastro(ClienteDestinoTO clienteDestinoTO) {
		frameEditarClienteDestino = new FrameEditarClienteDestino();
		frameEditarClienteDestino.getPanelDadosClienteDestino()
				.setClienteDestinoTO(clienteDestinoTO);
		frameEditarClienteDestino
				.addDadosEdicaoFrete(new DadosClienteDestino() {

					@Override
					public void dadosCancelados() {
						frameEditarClienteDestino.dispose();

					}

					@Override
					public void dadosgravados(
							ClienteDestinoTO clienteDestinoTO) {
						editarClienteDestino(clienteDestinoTO);
						frameEditarClienteDestino.dispose();
						try {
							ArrayList<ClienteDestinoTO> clientes = clienteDestinoDAO
									.listarClientesDestinoTudo();
							frameConsultaClienteDestino
									.limpaDadosClienteDestino();
							frameConsultaClienteDestino
									.setDadosClienteDestino(clientes);

						} catch (DAOException e) {
							e.printStackTrace();
						}
					}

				});
		frameEditarClienteDestino.setResizable(false);
		frameEditarClienteDestino.setLocationRelativeTo(null);
		frameEditarClienteDestino.setVisible(true);
	}

	private void editarClienteDestino(ClienteDestinoTO clienteDestinoTO) {

		try {
			clienteDestinoDAO.editarClienteDestino(clienteDestinoTO);
		} catch (DAOException e) {
			JOptionPane.showMessageDialog(null, "Ocorreu o seguinte erro: "
					+ e.getMessage());
			e.printStackTrace();
		}
	}

}
