package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import edu.univas.projeto.tcc.listeners.DadosClienteDestino;
import edu.univas.projeto.tcc.model.ClienteDestinoDAO;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;

import edu.univas.projeto.tcc.model.DAOException;
import edu.univas.projeto.tcc.view.FrameCadastroClienteDestino;
import edu.univas.projeto.tcc.view.FrameConsultaClienteDestino;

public class ControllerCadastroClienteDestino {

	private ClienteDestinoDAO clienteDestinoDAO;
	private FrameCadastroClienteDestino frameCadastroClienteDestino;
	private FrameConsultaClienteDestino frameConsultaClienteDestino;

	public ControllerCadastroClienteDestino(
			ClienteDestinoDAO clienteDestinoDAO,
			FrameConsultaClienteDestino frameConsultaClienteDestino) {
		this.clienteDestinoDAO = clienteDestinoDAO;
		this.frameConsultaClienteDestino = frameConsultaClienteDestino;
	}

	public void criarNovoCadastro() {
		frameCadastroClienteDestino = new FrameCadastroClienteDestino();
		frameCadastroClienteDestino.getPanelDadosClienteDestino().setData();
		frameCadastroClienteDestino
				.addDadosClienteDestino(new DadosClienteDestino() {

					@Override
					public void dadosCancelados() {
						frameCadastroClienteDestino.dispose();
					}

					@Override
					public void dadosgravados(
							ClienteDestinoTO clienteDestinoTO) {
						inserirClienteDest(clienteDestinoTO);
						frameCadastroClienteDestino.dispose();
						try {
							ArrayList<ClienteDestinoTO> clientes = clienteDestinoDAO
									.listarClientesDestinoTudo();
							frameConsultaClienteDestino
									.limpaDadosClienteDestino();
							frameConsultaClienteDestino
									.setDadosClienteDestino(clientes);

						} catch (DAOException e) {
							e.printStackTrace();
						}

					}

				});
		frameCadastroClienteDestino.setResizable(false);
		frameCadastroClienteDestino.setLocationRelativeTo(null);
		frameCadastroClienteDestino.setVisible(true);
	}

	private void inserirClienteDest(ClienteDestinoTO clienteDestino) {

		try {
			clienteDestinoDAO.cadastrar(clienteDestino);
		} catch (DAOException e) {
			JOptionPane.showMessageDialog(null, "Ocorreu o seguinte erro: "
					+ e.getMessage());
			e.printStackTrace();
		}
	}

}
