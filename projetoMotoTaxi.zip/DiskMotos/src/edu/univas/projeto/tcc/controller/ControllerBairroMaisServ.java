package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.ListaRelatorio;
import edu.univas.projeto.tcc.model.ClienteDestinoDAO;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;
import edu.univas.projeto.tcc.view.FrameRelatorioBairroMaisServ;

public class ControllerBairroMaisServ {

	private ClienteDestinoDAO cliDestDAO;
	private FrameRelatorioBairroMaisServ frameRelBairro;

	public ControllerBairroMaisServ(ClienteDestinoDAO cliDestDAO) {
		this.cliDestDAO = cliDestDAO;
	}

	public void listarBairroMaisServSolic() {
		try {
			ArrayList<ClienteDestinoTO> cliDest = cliDestDAO
					.listarBairroMaisSolicServNoDia();
			frameRelBairro = new FrameRelatorioBairroMaisServ();
			frameRelBairro.setRelatorioBairro(cliDest);
		} catch (Exception e) {
			e.printStackTrace();
		}
		frameRelBairro.addRelatorioBairro(new ListaRelatorio() {

			@Override
			public void fechar() {
				frameRelBairro.dispose();

			}

			@Override
			public void listar(JDateChooser dtInic, JDateChooser dtFim) {
				
				
				
				try {
					
					Map<String, Date> parameters = new HashMap<String, Date>();
					parameters.put("dataInic",dtInic.getDate());
					parameters.put("dataFim", dtFim.getDate());
					JasperDesign design = JRXmlLoader
							.load("C:/Moto/relatorio/RelBairroMaisSolic.jrxml");
					JasperReport report = JasperCompileManager
							.compileReport(design);
					JasperPrint print = JasperFillManager.fillReport(report,
							parameters, ConnectionBanco.getConnection());
					String reportIn = "C:/Moto/relatorio/RelBairroMaisSolic";
					JasperExportManager.exportReportToPdfFile(print, reportIn
							+ ".pdf");

					JasperPrint printReport = JasperFillManager.fillReport(
							reportIn + ".jasper", parameters, ConnectionBanco
									.getConnection());

					JasperViewer.viewReport(printReport, false);

				} catch (Exception e) {
					System.out.println("Relatorio gerado");
				}

			}

			@Override
			public void listarTable(JDateChooser dtInic, JDateChooser dtFim) {
				try {
					ArrayList<ClienteDestinoTO> motqs = cliDestDAO
							.listarBairroMaisSolicServ(dtInic, dtFim);
					frameRelBairro.limpaDadosTable();
					frameRelBairro.setRelatorioBairro(motqs);
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		});
		frameRelBairro.setVisible(true);
	}

}
