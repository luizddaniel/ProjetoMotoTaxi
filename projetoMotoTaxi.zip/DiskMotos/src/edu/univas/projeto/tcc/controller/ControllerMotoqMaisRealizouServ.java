package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.ListaRelatorio;
import edu.univas.projeto.tcc.model.MotoqueiroDAO;
import edu.univas.projeto.tcc.model.MotoqueiroTO;
import edu.univas.projeto.tcc.view.FrameRelatoriosMotoqMaisRealizouServ;

public class ControllerMotoqMaisRealizouServ {

	private MotoqueiroDAO motoqueiroDAO;
	private FrameRelatoriosMotoqMaisRealizouServ frameMaisRealizouServ;

	public ControllerMotoqMaisRealizouServ(MotoqueiroDAO motoqDAO) {
		this.motoqueiroDAO = motoqDAO;
	}

	public void listarMotoqMaisRealizouServ() {
		try {
			ArrayList<MotoqueiroTO> motqs = motoqueiroDAO
					.listarMotoqueiroMaisServNoDia();
			frameMaisRealizouServ = new FrameRelatoriosMotoqMaisRealizouServ();
			frameMaisRealizouServ.setRelatorioQtdeServPorMotoq(motqs);
		} catch (Exception e) {
			e.printStackTrace();
		}
		frameMaisRealizouServ.addRelatorioMotoq(new ListaRelatorio() {

			@Override
			public void fechar() {
				frameMaisRealizouServ.dispose();

			}

			@Override
			public void listar(JDateChooser dtInic, JDateChooser dtFim) {

				try {
					Map<String, Date> parameters = new HashMap<String, Date>();
					parameters.put("dataInic", dtInic.getDate());
					parameters.put("dataFim", dtFim.getDate());
					JasperDesign design = JRXmlLoader
							.load("C:/Moto/relatorio/RelQtdServPorMot.jrxml");
					JasperReport report = JasperCompileManager
							.compileReport(design);
					JasperPrint print = JasperFillManager.fillReport(report,
							parameters, ConnectionBanco.getConnection());
					String reportIn = "C:/Moto/relatorio/RelQtdServPorMot";
					JasperExportManager.exportReportToPdfFile(print, reportIn
							+ ".pdf");

					JasperPrint printReport = JasperFillManager.fillReport(
							reportIn + ".jasper", parameters, ConnectionBanco
									.getConnection());

					JasperViewer.viewReport(printReport, false);

				} catch (Exception e) {

				}

			}

			@Override
			public void listarTable(JDateChooser dtInic, JDateChooser dtFim) {
				try {
					ArrayList<MotoqueiroTO> motqs = motoqueiroDAO
							.listarMotoqueiroMaisServ(dtInic, dtFim);
					frameMaisRealizouServ.limpaDadosTable();
					frameMaisRealizouServ.setRelatorioQtdeServPorMotoq(motqs);
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		});
		frameMaisRealizouServ.setVisible(true);
	}
}
