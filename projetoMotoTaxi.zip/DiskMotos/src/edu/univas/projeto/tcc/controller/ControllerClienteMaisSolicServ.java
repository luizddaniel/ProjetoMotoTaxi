package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.ListaRelatorio;
import edu.univas.projeto.tcc.model.ClienteDestinoDAO;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;
import edu.univas.projeto.tcc.view.FrameRelatorioClienteMaisSolicServico;

public class ControllerClienteMaisSolicServ {

	private ClienteDestinoDAO clienteDAO;
	private FrameRelatorioClienteMaisSolicServico frameCliMaisSolicServ;

	public ControllerClienteMaisSolicServ(ClienteDestinoDAO clienteDAO) {
		this.clienteDAO = clienteDAO;
	}

	public void listarMotoqVlrTotalServ() {
		try {
			ArrayList<ClienteDestinoTO> clientes = clienteDAO
					.listarCliMaisSolicServNoDia();
			frameCliMaisSolicServ = new FrameRelatorioClienteMaisSolicServico();
			frameCliMaisSolicServ.setRelatorioClientes(clientes);
		} catch (Exception e) {
			e.printStackTrace();
		}
		frameCliMaisSolicServ.addRelatorioMotoq(new ListaRelatorio() {

			@Override
			public void fechar() {
				frameCliMaisSolicServ.dispose();

			}

			@Override
			public void listar(JDateChooser dtInic, JDateChooser dtFim) {
				try {
					Map<String, Date> parameters = new HashMap<String, Date>();
					parameters.put("dataInic", dtInic.getDate());
					parameters.put("dataFim", dtFim.getDate());
					JasperDesign design = JRXmlLoader
							.load("C:/Moto/relatorio/RelCliMaisSolServ.jrxml");
					JasperReport report = JasperCompileManager
							.compileReport(design);
					JasperPrint print = JasperFillManager.fillReport(report,
							parameters, ConnectionBanco.getConnection());
					String reportIn = "C:/Moto/relatorio/RelCliMaisSolServ";
					JasperExportManager.exportReportToPdfFile(print, reportIn
							+ ".pdf");

					JasperPrint printReport = JasperFillManager.fillReport(
							reportIn + ".jasper", parameters, ConnectionBanco
									.getConnection());

					JasperViewer.viewReport(printReport, false);

				} catch (Exception e) {
					System.out.println("Relatorio gerado");
				}

			}

			@Override
			public void listarTable(JDateChooser dtInic, JDateChooser dtFim) {
				try {
					ArrayList<ClienteDestinoTO> motqs = clienteDAO
							.listarClienteMaisSolicServ(dtInic, dtFim);
					frameCliMaisSolicServ.limpaDadosTable();
					frameCliMaisSolicServ.setRelatorioClientes(motqs);
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		});
		frameCliMaisSolicServ.setVisible(true);
	}
}
