package edu.univas.projeto.tcc.controller;

import edu.univas.projeto.tcc.listeners.MenuListener;
import edu.univas.projeto.tcc.model.ClienteDestinoDAO;
import edu.univas.projeto.tcc.model.FreteDAO;
import edu.univas.projeto.tcc.model.MotoqueiroDAO;
import edu.univas.projeto.tcc.view.FramePrincipal;

public class ControllerPrincipal {

	private MotoqueiroDAO motoqueiroDAO;
	private ClienteDestinoDAO clienteDestinoDAO;
	private FreteDAO freteDAO;
	private FramePrincipal principal;

	public ControllerPrincipal(ClienteDestinoDAO clienteDestinoDAO,
			MotoqueiroDAO motoqueiroDAO, FreteDAO freteDAO) {
		this.motoqueiroDAO = motoqueiroDAO;
		this.clienteDestinoDAO = clienteDestinoDAO;
		this.freteDAO = freteDAO;
	}

	public void showFramePrincipal() {

		principal = new FramePrincipal();
		principal.addMenuListener(new MenuListener() {

			@Override
			public void cadastrarCliDest() {
				ControllerConsultaClienteDestino cliente = new ControllerConsultaClienteDestino(
						clienteDestinoDAO);
				cliente.listarCliente_Destino();
			}

			@Override
			public void cadastrarFrete() {
				ControllerConsultaFrete frete = new ControllerConsultaFrete(
						freteDAO);
				frete.listarFretes();

			}

			@Override
			public void cadastrarMot() {
				ControllerConsultaMotoqueiro motoqueiro = new ControllerConsultaMotoqueiro(
						motoqueiroDAO);
				motoqueiro.listarMotoqueiros();

			}

			@Override
			public void relBairroMaisSolicServ() {
				ControllerBairroMaisServ controllerBairroMaisServ = new ControllerBairroMaisServ(
						clienteDestinoDAO);
				controllerBairroMaisServ.listarBairroMaisServSolic();

			}

			@Override
			public void relCliMaiSolicServ() {
				ControllerClienteMaisSolicServ controllerClienteMaisSolicServ = new ControllerClienteMaisSolicServ(
						clienteDestinoDAO);
				controllerClienteMaisSolicServ.listarMotoqVlrTotalServ();

			}

			@Override
			public void relEpcAnoMaisServ() {
				ControllerQtdEpocaAno controllerQtdEpocaAno = new ControllerQtdEpocaAno(
						freteDAO);
				controllerQtdEpocaAno.listarFreteEpocaAno();

			}

			@Override
			public void relMotMaisServ() {
				ControllerVlrTotalFreteMotoq freteMotoq = new ControllerVlrTotalFreteMotoq(
						freteDAO);
				freteMotoq.listarMotoqVlrTotalServ();

			}

			@Override
			public void relQtdServSolic() {
				ControllerMotoqMaisRealizouServ controllerMotoqMaisRealizouServ = new ControllerMotoqMaisRealizouServ(
						motoqueiroDAO);
				controllerMotoqMaisRealizouServ.listarMotoqMaisRealizouServ();

			}

		});
		principal.setLocationRelativeTo(null);
		principal.setVisible(true);
	}
}
