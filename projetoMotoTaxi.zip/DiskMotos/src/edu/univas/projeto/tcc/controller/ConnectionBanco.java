package edu.univas.projeto.tcc.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import edu.univas.projeto.tcc.model.DAOException;

public class ConnectionBanco {
	public static Connection getConnection() throws DAOException {
		Connection conn = null;
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			conn = DriverManager
					.getConnection(
							"jdbc:hsqldb:file:C:/hsqldb-2.2.5/hsqldb/data/diskmoto",
							"SA", "");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return conn;
	}
}






