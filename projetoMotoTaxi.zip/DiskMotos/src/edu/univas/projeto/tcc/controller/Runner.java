package edu.univas.projeto.tcc.controller;

import edu.univas.projeto.tcc.model.ClienteDestinoDAO;
import edu.univas.projeto.tcc.model.FreteDAO;
import edu.univas.projeto.tcc.model.MotoqueiroDAO;

public class Runner {
	public static void main(String[] args) {
		new ControllerLogin().login();
	}

	public void main() {
		new ControllerPrincipal(new ClienteDestinoDAO(), new MotoqueiroDAO(),
				new FreteDAO()).showFramePrincipal();
	}

}