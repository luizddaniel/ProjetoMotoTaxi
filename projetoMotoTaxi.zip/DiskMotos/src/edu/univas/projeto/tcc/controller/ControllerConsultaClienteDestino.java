package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;
import java.util.Date;

import javax.swing.JOptionPane;

import edu.univas.projeto.tcc.listeners.ConsultaClienteDestino;
import edu.univas.projeto.tcc.model.ClienteDestinoDAO;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;
import edu.univas.projeto.tcc.model.DAOException;
import edu.univas.projeto.tcc.view.FrameConsultaClienteDestino;

public class ControllerConsultaClienteDestino {

	private ClienteDestinoDAO clienteDestinoDAO;
	private FrameConsultaClienteDestino frameConsultaClienteDestino;

	public ControllerConsultaClienteDestino(ClienteDestinoDAO clienteDestinoDAO) {
		this.clienteDestinoDAO = clienteDestinoDAO;
	}

	public void listarCliente_Destino() {

		try {
			ArrayList<ClienteDestinoTO> clientes = clienteDestinoDAO
					.listarClientesDestinoTudo();
			frameConsultaClienteDestino = new FrameConsultaClienteDestino();
			frameConsultaClienteDestino.limpaDadosClienteDestino();
			frameConsultaClienteDestino.setDadosClienteDestino(clientes);

		} catch (DAOException e) {
			e.printStackTrace();
		}
		frameConsultaClienteDestino
				.addConsultaClienteDestino(new ConsultaClienteDestino() {

					@Override
					public void cancelar() {
						frameConsultaClienteDestino.dispose();

					}

					@Override
					public void editar(String codigo) {
						ControllerEditarClienteDestino clienteDestino = new ControllerEditarClienteDestino(
								clienteDestinoDAO, frameConsultaClienteDestino);
						try {
							if (!codigo.equals("")) {
								ClienteDestinoTO clienteDestinoTO = clienteDestinoDAO
										.buscarClienteDestino(codigo);
								if (!clienteDestinoTO.getId().equals(null)) {
									clienteDestino
											.editarCadastro(clienteDestinoTO);
								}
							} else {
								JOptionPane
										.showMessageDialog(null,
												"Favor preencher campo com o c�digo para editar!");
							}
						} catch (DAOException e) {
							JOptionPane.showMessageDialog(null,
									"C�digo Inexistente!");
							e.printStackTrace();
						}

					}

					@Override
					public void excluir(String codigo) {
						try {
							if (JOptionPane.showConfirmDialog(null,
									"Voc� Deseja realmente excluir o registro de c�digo "
											+ codigo + "?",
									"Sistema Disk Motos",
									JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
								clienteDestinoDAO.excluirDestino(codigo);
							}
							listarTudo();

						} catch (DAOException e) {
							e.printStackTrace();
						}

					}

					@Override
					public void fechar() {
						frameConsultaClienteDestino.dispose();

					}

					@Override
					public void incluir() {
						ControllerCadastroClienteDestino cliente = new ControllerCadastroClienteDestino(
								clienteDestinoDAO, frameConsultaClienteDestino);
						cliente.criarNovoCadastro();

					}

					@Override
					public void listarTudo() {
						try {
							ArrayList<ClienteDestinoTO> clientes = clienteDestinoDAO
									.listarClientesDestinoTudo();
							frameConsultaClienteDestino
									.limpaDadosClienteDestino();
							frameConsultaClienteDestino
									.setDadosClienteDestino(clientes);

						} catch (DAOException e) {
							e.printStackTrace();
						}

					}

					@Override
					public void relacaoTela() {
						try {
							ArrayList<ClienteDestinoTO> clientes = clienteDestinoDAO
									.listarClientesDestinoDia();
							frameConsultaClienteDestino
									.limpaDadosClienteDestino();
							frameConsultaClienteDestino
									.setDadosClienteDestino(clientes);

						} catch (DAOException e) {
							e.printStackTrace();
						}
					}

					@Override
					public void pesquisar(Date data, String pesq1,
							String pesq2, Integer pesq3) {
						try {
							if ((data == null) && (pesq1.equals(""))
									&& (pesq2.equals("")) && (pesq3 == null)) {
								JOptionPane
										.showMessageDialog(null,
												"Favor preencher algum campo para pesquisar!");
							} else {
								ArrayList<ClienteDestinoTO> clientes = clienteDestinoDAO
										.pesquisarClientesDestino(data, pesq1,
												pesq2, pesq3);
								frameConsultaClienteDestino
										.limpaDadosClienteDestino();
								frameConsultaClienteDestino
										.setDadosClienteDestino(clientes);
							}
						} catch (DAOException e) {
							e.printStackTrace();
						}
					}

				});
		frameConsultaClienteDestino.setResizable(false);
		frameConsultaClienteDestino.setLocationRelativeTo(null);
		frameConsultaClienteDestino.setVisible(true);

	}

}
