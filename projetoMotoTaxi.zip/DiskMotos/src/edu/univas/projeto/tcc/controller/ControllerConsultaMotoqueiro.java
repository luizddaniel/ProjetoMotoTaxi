package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;
import java.util.Date;

import javax.swing.JOptionPane;

import edu.univas.projeto.tcc.listeners.ConsultaMotoqueiro;
import edu.univas.projeto.tcc.model.DAOException;
import edu.univas.projeto.tcc.model.MotoqueiroDAO;
import edu.univas.projeto.tcc.model.MotoqueiroTO;
import edu.univas.projeto.tcc.view.FrameConsultaMotoqueiro;

public class ControllerConsultaMotoqueiro {

	private MotoqueiroDAO motoqueiroDAO;
	private FrameConsultaMotoqueiro frameConsultaMotoqueiro;

	public ControllerConsultaMotoqueiro(MotoqueiroDAO motoqueiroDAO) {
		this.motoqueiroDAO = motoqueiroDAO;
	}

	public void listarMotoqueiros() {

		try {
			ArrayList<MotoqueiroTO> motoqueiros = motoqueiroDAO
					.listarMotoqueiros();
			frameConsultaMotoqueiro = new FrameConsultaMotoqueiro();
			frameConsultaMotoqueiro.limpaTable();
			frameConsultaMotoqueiro.setDadosMotoqueiro(motoqueiros);
		} catch (DAOException e) {

			e.printStackTrace();
		}

		frameConsultaMotoqueiro.addConsultaMotoqueiro(new ConsultaMotoqueiro() {

			@Override
			public void cancelar() {
				frameConsultaMotoqueiro.dispose();

			}

			@Override
			public void editar(String codigo) {
				ControllerEditarMotoqueiro frete = new ControllerEditarMotoqueiro(
						motoqueiroDAO, frameConsultaMotoqueiro);
				try {
					if (!codigo.equals("")) {
						MotoqueiroTO motoqueiroTO = motoqueiroDAO
								.buscarMotoqueiro(codigo);
						if (motoqueiroTO.getId() != null) {
							frete.editarCadastro(motoqueiroTO);
						}
					} else {
						JOptionPane
								.showMessageDialog(null,
										"Favor preencher campo com o c�digo para editar!");

					}
				} catch (DAOException e) {
					JOptionPane.showMessageDialog(null, "C�digo Inexistente!");
					e.printStackTrace();
				}
			}

			@Override
			public void excluir(String codigo) {
				try {
					if (JOptionPane.showConfirmDialog(null,
							"Voc� Deseja realmente excluir o registro de c�digo "
									+ codigo + "?", "Sistema Disk Motos",
							JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
						motoqueiroDAO.excluirMotoqueiro(codigo);
					}
					listarTudo();
				} catch (DAOException e) {
					e.printStackTrace();
				}

			}

			@Override
			public void fechar() {
				frameConsultaMotoqueiro.dispose();

			}

			@Override
			public void incluir() {
				ControllerCadastroMotoqueiro motoqueiro = new ControllerCadastroMotoqueiro(
						motoqueiroDAO, frameConsultaMotoqueiro);
				motoqueiro.criarNovoCadastro();

			}

			@Override
			public void listarTudo() {
				try {
					ArrayList<MotoqueiroTO> motoqueiros = motoqueiroDAO
							.listarMotoqueiros();
					frameConsultaMotoqueiro.limpaTable();
					frameConsultaMotoqueiro.setDadosMotoqueiro(motoqueiros);
				} catch (DAOException e) {

					e.printStackTrace();
				}

			}

			@Override
			public void relacaoTela() {
				try {
					ArrayList<MotoqueiroTO> motoqueiros = motoqueiroDAO
							.listarMotoqueirosDia();
					frameConsultaMotoqueiro.limpaTable();
					frameConsultaMotoqueiro.setDadosMotoqueiro(motoqueiros);
				} catch (DAOException e) {

					e.printStackTrace();
				}

			}

			@Override
			public void pesquisar(Date data, String pesq1, String pesq2,
					Integer pesq3) {
				try {
					if ((data == null) && (pesq1.equals(""))
							&& (pesq2.equals("")) && (pesq3 == null)) {
						JOptionPane.showMessageDialog(null,
								"Favor preencher algum campo para pesquisar!");
					} else {

						ArrayList<MotoqueiroTO> motoqueiros = motoqueiroDAO
								.pesquisarMotoqueiro(data, pesq1, pesq2, pesq3);
						frameConsultaMotoqueiro.limpaTable();
						frameConsultaMotoqueiro.setDadosMotoqueiro(motoqueiros);
					}
				} catch (DAOException e) {

					e.printStackTrace();
				}
			}

		});
		frameConsultaMotoqueiro.setResizable(false);
		frameConsultaMotoqueiro.setLocationRelativeTo(null);
		frameConsultaMotoqueiro.setVisible(true);

	}
}
