package edu.univas.projeto.tcc.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import com.toedter.calendar.JDateChooser;

import edu.univas.projeto.tcc.listeners.ListaRelatorio;
import edu.univas.projeto.tcc.model.FreteDAO;
import edu.univas.projeto.tcc.model.FreteTO;
import edu.univas.projeto.tcc.view.FrameRelatorioQuantdServEpoca;

public class ControllerQtdEpocaAno {

	private FreteDAO freteDAO;
	private FrameRelatorioQuantdServEpoca frameEpocaAno;

	public ControllerQtdEpocaAno(FreteDAO freteDAO) {
		this.freteDAO = freteDAO;
	}

	public void listarFreteEpocaAno() {
		try {
			ArrayList<FreteTO> fretes = freteDAO.listarFretesEpocaAnoDia();
			frameEpocaAno = new FrameRelatorioQuantdServEpoca();
			frameEpocaAno.setRelatorioFrete(fretes);
		} catch (Exception e) {
			e.printStackTrace();
		}
		frameEpocaAno.addRelatorioFretes(new ListaRelatorio() {

			@Override
			public void fechar() {
				frameEpocaAno.dispose();

			}

			@Override
			public void listar(JDateChooser dtInic, JDateChooser dtFim) {
				try {
					Map<String, Date> parameters = new HashMap<String, Date>();
					parameters.put("dataInic", dtInic.getDate());
					parameters.put("dataFim", dtFim.getDate());
					JasperDesign design = JRXmlLoader
							.load("C:/Moto/relatorio/RelEpocaMaisSolicServ.jrxml");
					JasperReport report = JasperCompileManager
							.compileReport(design);
					JasperPrint print = JasperFillManager.fillReport(report,
							parameters, ConnectionBanco.getConnection());
					String reportIn = "C:/Moto/relatorio/RelEpocaMaisSolicServ";
					JasperExportManager.exportReportToPdfFile(print, reportIn
							+ ".pdf");

					JasperPrint printReport = JasperFillManager.fillReport(
							reportIn + ".jasper", parameters, ConnectionBanco
									.getConnection());

					JasperViewer.viewReport(printReport, false);

				} catch (Exception e) {

				}

			}

			@Override
			public void listarTable(JDateChooser dtInic, JDateChooser dtFim) {
				try {
					ArrayList<FreteTO> fretes = freteDAO.listarFretesEpocaAno(
							dtInic, dtFim);
					frameEpocaAno.limpaDadosTable();
					frameEpocaAno.setRelatorioFrete(fretes);
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		});
		frameEpocaAno.setVisible(true);
	}
}
