package edu.univas.teste.tcc.cliente.destino;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

import junit.framework.TestCase;
import edu.univas.projeto.tcc.model.ClienteDestinoTO;

public class ClienteDestinoTeste extends TestCase {

	private ClienteDestinoTO clienteDestino;

	protected void setUp() throws Exception {
		super.setUp();
		clienteDestino = new ClienteDestinoTO();
	}

	public void testId() {
		int result;
		clienteDestino.setId(1);
		result = clienteDestino.getId();
		assertEquals(1, result);
	}

	public void testNome() {
		String result;
		clienteDestino.setNome("Luiz Fernando");
		result = clienteDestino.getNome();
		assertEquals("Luiz Fernando", result);
	}

	public void testTipo() {
		String result;
		clienteDestino.setTipo("Destino");
		result = clienteDestino.getTipo();
		assertEquals("Destino", result);
	}

	public void testEndereco() {
		String result;
		clienteDestino.setEndereco("Rua Dr. Paulino Pereira da Silva");
		result = clienteDestino.getEndereco();
		assertEquals("Rua Dr. Paulino Pereira da Silva", result);
	}

	public void testNumero() {
		int result;
		clienteDestino.setNumero(25);
		result = clienteDestino.getNumero();
		assertEquals(25, result);
	}

	public void testBairro() {
		String result;
		clienteDestino.setBairro("Centro");
		result = clienteDestino.getBairro();
		assertEquals("Centro", result);
	}

	public void testCidade() {
		String result;
		clienteDestino.setCidade("Pouso Alegre");
		result = clienteDestino.getCidade();
		assertEquals("Pouso Alegre", result);
	}

	public void testCep() {
		String result;
		clienteDestino.setCep("37550000");
		result = clienteDestino.getCep();
		assertEquals("37550000", result);
	}

	public void testTelefone() {
		String result;
		clienteDestino.setTelefone("3534237316");
		result = clienteDestino.getTelefone();
		assertEquals("3534237316", result);
	}

	public void testCnpjCpf() {
		String result;
		clienteDestino.setCnpjCpf("055.244.676-97");
		result = clienteDestino.getCnpjCpf();
		assertEquals("055.244.676-97", result);
	}

	public void testIeRg() {
		String result;
		clienteDestino.setInscRg("mg-11.610.733");
		result = clienteDestino.getInscRg();
		assertEquals("mg-11.610.733", result);
	}

	public void testEmail() {
		String result;
		clienteDestino.setE_mail("luizddaniel@hotmail.com");
		result = clienteDestino.getE_mail();
		assertEquals("luizddaniel@hotmail.com", result);
	}

	public void testData() {
		String result;
		lerData(clienteDestino);
		result = apresentarData(clienteDestino);
		assertEquals("11/08/2011", result);
	}

	private boolean lerData(ClienteDestinoTO cliente_destino) {

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String data = "";
		try {
			data = "11/08/2011";
			Date dtcad = formatter.parse(data);
			cliente_destino.setDataCad(dtcad);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "O valor informado " + data
					+ " n�o � v�lido como data.\n Informe uma data correta!");
			return false;
		}
		return true;
	}

	private String apresentarData(ClienteDestinoTO cliente_destino) {

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		String dtnasc1;
		Date dtc = null;
		try {
			dtc = cliente_destino.getDataCad();
			dtnasc1 = format.format(dtc);

		} catch (Exception e) {
			return null;
		}
		return dtnasc1;
	}

}
